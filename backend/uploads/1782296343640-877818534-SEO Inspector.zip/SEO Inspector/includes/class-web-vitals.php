<?php
/**
 * SEO Inspector Core Web Vitals Manager
 * Architecture Hardening: Implements transient caching, manual refresh, scheduled refresh,
 * and prevents unnecessary PageSpeed Insights API calls.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Web_Vitals {

    public static function init() {
        // Scheduled cron job for daily updates
        if ( ! wp_next_scheduled( 'si_cwv_daily_sync' ) ) {
            wp_schedule_event( time(), 'daily', 'si_cwv_daily_sync' );
        }
        add_action( 'si_cwv_daily_sync', array( __CLASS__, 'fetch_cwv_data' ) );

        // AJAX handler for manual refresh
        add_action( 'wp_ajax_si_refresh_cwv', array( __CLASS__, 'ajax_manual_refresh' ) );
    }

    /**
     * AJAX handler to manually refresh Web Vitals.
     */
    public static function ajax_manual_refresh() {
        check_ajax_referer( 'si_cwv_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        // Check if a refresh was recently performed to prevent manual spam
        if ( get_transient( 'si_cwv_refresh_lock' ) ) {
            wp_send_json_error( 'Please wait before refreshing again.' );
        }
        set_transient( 'si_cwv_refresh_lock', true, 5 * MINUTE_IN_SECONDS ); // 5-minute cooldown

        $results = self::fetch_cwv_data( true ); // true = force refresh
        if ( is_wp_error( $results ) ) {
            wp_send_json_error( $results->get_error_message() );
        }

        wp_send_json_success( $results );
    }

    /**
     * Fetches Web Vitals from the PageSpeed API or from Transient Cache
     */
    public static function fetch_cwv_data( $force = false ) {
        $transient_key = 'si_cwv_data';
        
        if ( ! $force ) {
            $cached = get_transient( $transient_key );
            if ( false !== $cached ) {
                return $cached; // Return cached data
            }
        }

        $home_url = home_url();
        $api_key = get_option( 'si_pagespeed_api_key', '' );
        
        // Return dummy/fallback if API not set up for testing purposes
        if ( empty( $api_key ) ) {
            $data = array(
                'LCP' => '2.5s',
                'FID' => '100ms',
                'CLS' => '0.1',
                'FCP' => '1.8s',
                'Score' => 85,
                'status' => 'Needs API Key'
            );
            // Cache for 24 hours
            set_transient( $transient_key, $data, 24 * HOUR_IN_SECONDS );
            return $data;
        }

        // Call the PageSpeed API
        $api_url = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=" . urlencode( $home_url ) . "&key=" . $api_key;
        $response = wp_remote_get( $api_url, array( 'timeout' => 30 ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $body = wp_remote_retrieve_body( $response );
        $json = json_decode( $body, true );

        if ( ! isset( $json['lighthouseResult'] ) ) {
            return new WP_Error( 'api_error', 'Invalid API Response' );
        }

        $metrics = $json['lighthouseResult']['audits'];
        
        $data = array(
            'LCP' => isset( $metrics['largest-contentful-paint']['displayValue'] ) ? $metrics['largest-contentful-paint']['displayValue'] : 'N/A',
            'FID' => isset( $metrics['max-potential-fid']['displayValue'] ) ? $metrics['max-potential-fid']['displayValue'] : 'N/A',
            'CLS' => isset( $metrics['cumulative-layout-shift']['displayValue'] ) ? $metrics['cumulative-layout-shift']['displayValue'] : 'N/A',
            'FCP' => isset( $metrics['first-contentful-paint']['displayValue'] ) ? $metrics['first-contentful-paint']['displayValue'] : 'N/A',
            'Score' => isset( $json['lighthouseResult']['categories']['performance']['score'] ) ? $json['lighthouseResult']['categories']['performance']['score'] * 100 : 0,
            'status' => 'Success'
        );

        // Cache the successful result for 24 hours
        set_transient( $transient_key, $data, 24 * HOUR_IN_SECONDS );

        return $data;
    }
}
