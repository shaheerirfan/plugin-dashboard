<?php
/**
 * SI_Crawl_Optimization
 *
 * Removes bloat from WordPress that wastes crawl budget and leaks tech information.
 * Mirrors Yoast's "Crawl Settings" feature set.
 *
 * Toggles stored under:  si_crawl_*  options.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Crawl_Optimization {

    // -----------------------------------------------------------------------
    // Option defaults – each key maps 1-to-1 to a checkbox in the UI
    // -----------------------------------------------------------------------
    private static array $defaults = [
        // Head cleanup
        'remove_generator'         => 1,  // <meta name="generator" …>
        'remove_rsd_link'          => 1,  // Really Simple Discovery link
        'remove_wlw_link'          => 1,  // Windows Live Writer manifest
        'remove_shortlink'         => 1,  // <link rel="shortlink" …>
        'remove_rest_api_links'    => 1,  // <link rel="https://api.w.org/" …>
        'remove_adjacent_rel'      => 0,  // prev/next pagination links
        'remove_feed_links'        => 0,  // <link rel="alternate" type="application/rss+xml" …>
        // Script / style cleanup
        'remove_emoji_scripts'     => 1,  // wp-emoji-release.min.js + DNS-prefetch
        'remove_oembed_scripts'    => 0,  // wp-embed.min.js
        // Feed cleanup
        'remove_comment_feeds'     => 1,  // post comment feeds (?feed=comments-rss2)
        'remove_extra_rss_links'   => 1,  // category / author feed links
        // Header extras
        'remove_x_pingback_header' => 1,  // X-Pingback HTTP response header
        'remove_powered_by_header' => 1,  // X-Powered-By HTTP response header
    ];

    // -----------------------------------------------------------------------
    public static function init(): void {
        add_action( 'init', [ __CLASS__, 'apply_cleanups' ] );
        add_action( 'wp_ajax_si_save_crawl_settings', [ __CLASS__, 'ajax_save' ] );
    }

    // -----------------------------------------------------------------------
    // Apply all enabled cleanup hooks
    // -----------------------------------------------------------------------
    public static function apply_cleanups(): void {
        $opts = self::get_options();

        /* ── HEAD CLEANUP ─────────────────────────────────────────────── */
        if ( $opts['remove_generator'] ) {
            remove_action( 'wp_head', 'wp_generator' );
            add_filter( 'the_generator', '__return_empty_string' );
        }
        if ( $opts['remove_rsd_link'] ) {
            remove_action( 'wp_head', 'rsd_link' );
        }
        if ( $opts['remove_wlw_link'] ) {
            remove_action( 'wp_head', 'wlwmanifest_link' );
        }
        if ( $opts['remove_shortlink'] ) {
            remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
        }
        if ( $opts['remove_rest_api_links'] ) {
            remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
            remove_action( 'template_redirect', 'rest_output_link_header', 11 );
        }
        if ( $opts['remove_adjacent_rel'] ) {
            remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
        }
        if ( $opts['remove_feed_links'] ) {
            remove_action( 'wp_head', 'feed_links', 2 );
            remove_action( 'wp_head', 'feed_links_extra', 3 );
        }

        /* ── SCRIPT / STYLE CLEANUP ────────────────────────────────────── */
        if ( $opts['remove_emoji_scripts'] ) {
            remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
            remove_action( 'wp_print_styles', 'print_emoji_styles' );
            remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
            remove_action( 'admin_print_styles', 'print_emoji_styles' );
            remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
            remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
            remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
            add_filter( 'tiny_mce_plugins', [ __CLASS__, 'remove_tinymce_emoji' ] );
            add_filter( 'wp_resource_hints', [ __CLASS__, 'remove_emoji_dns_prefetch' ], 10, 2 );
        }
        if ( $opts['remove_oembed_scripts'] ) {
            remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
            remove_action( 'wp_head', 'wp_oembed_add_host_js' );
        }

        /* ── FEED CLEANUP ──────────────────────────────────────────────── */
        if ( $opts['remove_comment_feeds'] ) {
            add_filter( 'feed_links_show_comments_feed', '__return_false' );
        }
        if ( $opts['remove_extra_rss_links'] ) {
            remove_action( 'wp_head', 'feed_links_extra', 3 );
        }

        /* ── HTTP HEADER CLEANUP ───────────────────────────────────────── */
        if ( $opts['remove_x_pingback_header'] ) {
            add_filter( 'xmlrpc_enabled', '__return_false' );
            remove_action( 'wp_head', 'xmlrpc_rsd_link' );
            add_filter( 'wp_headers', [ __CLASS__, 'strip_pingback_header' ] );
        }
        if ( $opts['remove_powered_by_header'] ) {
            add_filter( 'wp_headers', [ __CLASS__, 'strip_powered_by_header' ] );
            // For PHP-level header (non-buffered environments)
            header_remove( 'X-Powered-By' );
        }
    }

    // -----------------------------------------------------------------------
    // Helper callbacks
    // -----------------------------------------------------------------------
    public static function remove_tinymce_emoji( array $plugins ): array {
        return array_diff( $plugins, [ 'wpemoji' ] );
    }

    public static function remove_emoji_dns_prefetch( array $urls, string $relation_type ): array {
        if ( 'dns-prefetch' === $relation_type ) {
            $urls = array_filter( $urls, fn( $url ) => strpos( $url, 'https://s.w.org/images/core/emoji' ) === false );
        }
        return $urls;
    }

    public static function strip_pingback_header( array $headers ): array {
        unset( $headers['X-Pingback'] );
        return $headers;
    }

    public static function strip_powered_by_header( array $headers ): array {
        unset( $headers['X-Powered-By'] );
        return $headers;
    }

    // -----------------------------------------------------------------------
    // Option helpers
    // -----------------------------------------------------------------------
    public static function get_options(): array {
        $saved = get_option( 'si_crawl_settings', [] );
        if ( ! is_array( $saved ) ) {
            $saved = [];
        }
        return array_merge( self::$defaults, $saved );
    }

    // -----------------------------------------------------------------------
    // AJAX: Save settings
    // -----------------------------------------------------------------------
    public static function ajax_save(): void {
        check_ajax_referer( 'si_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $new = [];
        foreach ( array_keys( self::$defaults ) as $key ) {
            $new[ $key ] = isset( $_POST[ $key ] ) ? 1 : 0;
        }
        update_option( 'si_crawl_settings', $new );

        wp_send_json_success( 'Crawl optimisation settings saved.' );
    }

    // -----------------------------------------------------------------------
    // Admin submenu page renderer
    // -----------------------------------------------------------------------
    public static function render_page(): void {
        $opts = self::get_options();
        ?>
        <div id="si-crawl-page" class="si-page-wrap">
            <header class="si-page-header">
                <h1>Crawl Optimization</h1>
                <p>Remove WordPress bloat to conserve crawl budget, reduce page weight, and hide technical fingerprints from bots.</p>
            </header>

            <form id="si-crawl-form" class="si-card-grid" style="display:grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                <?php wp_nonce_field( 'si_nonce', '_ajax_nonce' ); ?>

                <!-- Column 1 -->
                <div class="si-settings-card">
                    <h3>Head Cleanup</h3>
                    <p style="color:var(--si-gray);font-size:.9rem;margin-bottom:16px;">These tags add nothing for visitors but waste bot resources and leak server information.</p>
                    <?php self::toggle( $opts, 'remove_generator', 'WordPress Generator Tag', 'Hides &lt;meta name="generator"&gt; revealing your WP version.' ); ?>
                    <?php self::toggle( $opts, 'remove_rsd_link', 'RSD Link (XML-RPC Discovery)', 'Removes &lt;link rel="EditURI"&gt; used by old blog clients.' ); ?>
                    <?php self::toggle( $opts, 'remove_wlw_link', 'Windows Live Writer Manifest', 'Removes wlwmanifest.xml reference — no modern tool needs this.' ); ?>
                    <?php self::toggle( $opts, 'remove_shortlink', 'Shortlink Tag', 'Removes the &lt;link rel="shortlink"&gt; duplicate URL signal.' ); ?>
                    <?php self::toggle( $opts, 'remove_rest_api_links', 'REST API Discovery Links', 'Hides &lt;link rel="https://api.w.org/"&gt; to reduce attack surface.' ); ?>
                    <?php self::toggle( $opts, 'remove_adjacent_rel', 'Prev/Next Pagination Links', 'Removes rel="prev" / rel="next" links (Google ignores them anyway).' ); ?>
                    <?php self::toggle( $opts, 'remove_feed_links', 'RSS Feed Links', 'Removes all automatic RSS &lt;link&gt; tags from the head.' ); ?>
                </div>

                <!-- Column 2 -->
                <div class="si-settings-card">
                    <h3>Scripts & Feeds</h3>
                    <p style="color:var(--si-gray);font-size:.9rem;margin-bottom:16px;">Reduce unnecessary JS, DNS prefetch, and feed endpoints that inflate page weight.</p>
                    <?php self::toggle( $opts, 'remove_emoji_scripts', 'Emoji Scripts & DNS Prefetch', 'Removes the emoji detection script, inline styles, and s.w.org DNS prefetch.' ); ?>
                    <?php self::toggle( $opts, 'remove_oembed_scripts', 'oEmbed / Embed Script', 'Removes wp-embed.min.js loaded on every page.' ); ?>
                    <?php self::toggle( $opts, 'remove_comment_feeds', 'Post Comment Feeds', 'Suppresses per-post comment RSS feeds (?feed=comments-rss2).' ); ?>
                    <?php self::toggle( $opts, 'remove_extra_rss_links', 'Category & Author RSS Links', 'Removes extra RSS &lt;link&gt; tags for archives and authors.' ); ?>

                    <h3 style="margin-top:24px;">HTTP Headers</h3>
                    <p style="color:var(--si-gray);font-size:.9rem;margin-bottom:16px;">Strip server information from HTTP response headers.</p>
                    <?php self::toggle( $opts, 'remove_x_pingback_header', 'X-Pingback Header', 'Removes the xmlrpc.php endpoint reference header.' ); ?>
                    <?php self::toggle( $opts, 'remove_powered_by_header', 'X-Powered-By Header', 'Hides the PHP version from HTTP response headers.' ); ?>
                </div>

                <!-- Save bar (full width) -->
                <div style="grid-column: 1 / -1; display:flex; align-items:center; gap:16px; padding-top:8px;">
                    <button type="button" id="si-save-crawl-btn" class="button button-primary" style="height:42px;padding:0 28px;border-radius:8px;font-weight:600;">
                        Save Crawl Settings
                    </button>
                    <span id="si-crawl-msg" style="font-size:.9rem;font-weight:600;display:none;"></span>
                </div>
            </form>
        </div>

        <script>
        (function($){
            $('#si-save-crawl-btn').on('click', function(){
                var data = { action: 'si_save_crawl_settings', _ajax_nonce: '<?php echo wp_create_nonce("si_nonce"); ?>' };
                $('#si-crawl-form input[type=checkbox]').each(function(){
                    if ($(this).is(':checked')) data[$(this).attr('name')] = 1;
                });
                $.post(ajaxurl, data, function(r){
                    var $msg = $('#si-crawl-msg');
                    $msg.show().removeClass('si-success si-error');
                    if (r.success) {
                        $msg.addClass('si-success').text('✓ ' + r.data);
                    } else {
                        $msg.addClass('si-error').text('✗ ' + (r.data || 'Save failed'));
                    }
                    setTimeout(function(){ $msg.fadeOut(); }, 3500);
                });
            });
        })(jQuery);
        </script>
        <?php
    }

    // -----------------------------------------------------------------------
    // Renders a single toggle row
    // -----------------------------------------------------------------------
    private static function toggle( array $opts, string $key, string $label, string $desc ): void {
        $checked = ! empty( $opts[ $key ] ) ? 'checked' : '';
        $id      = 'si_crawl_' . $key;
        echo '<div class="si-toggle-row">';
        echo '<div class="si-toggle-text">';
        echo '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $label ) . '</strong></label>';
        echo '<span class="si-toggle-desc">' . wp_kses_post( $desc ) . '</span>';
        echo '</div>';
        echo '<label class="si-switch">';
        echo '<input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" ' . $checked . '>';
        echo '<span class="si-slider"></span>';
        echo '</label>';
        echo '</div>';
    }
}
