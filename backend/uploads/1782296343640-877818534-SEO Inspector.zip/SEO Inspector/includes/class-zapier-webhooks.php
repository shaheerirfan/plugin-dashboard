<?php
/**
 * SEO Inspector Zapier Webhooks
 * Triggers a webhook payload when a post is updated with SEO metadata.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Zapier_Webhooks {
    public static function init() {
        // We use transition_post_status or save_post to hook into SEO changes.
        // It's safer to use our own meta-box save action or just standard save_post at low priority.
        add_action( 'save_post', array( __CLASS__, 'trigger_webhook' ), 99, 3 );
        
        // Settings for Webhook URL
        add_action( 'admin_menu', array( __CLASS__, 'add_submenu' ), 20 );
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
    }

    public static function add_submenu() {
        add_submenu_page(
            'seo-inspector',
            'Zapier Integration',
            'Zapier Webhooks',
            'manage_options',
            'si-zapier',
            array( __CLASS__, 'render_page' )
        );
    }

    public static function register_settings() {
        register_setting( 'si_zapier_settings_group', 'si_zapier_webhook_url', 'esc_url_raw' );
        register_setting( 'si_zapier_settings_group', 'si_zapier_enabled', 'sanitize_text_field' );
    }

    public static function render_page() {
        ?>
        <div class="wrap si-page-wrap">
            <h1>Zapier Webhook Integration</h1>
            <p>Automatically trigger workflows in Zapier (or Make/Integromat, n8n, etc.) whenever a post is updated or published.</p>
            
            <div class="si-settings-card" style="max-width: 600px; margin-top: 20px;">
                <form method="post" action="options.php">
                    <?php settings_fields( 'si_zapier_settings_group' ); ?>
                    
                    <div class="si-mb-field" style="margin-bottom: 20px;">
                        <label style="display: flex; align-items: center; gap: 10px;">
                            <input type="checkbox" name="si_zapier_enabled" value="1" <?php checked( 1, get_option( 'si_zapier_enabled' ), true ); ?> />
                            <strong>Enable Webhook Triggers</strong>
                        </label>
                    </div>

                    <div class="si-mb-field" style="margin-bottom: 20px;">
                        <label for="si_zapier_webhook_url" style="font-weight: 600; display: block; margin-bottom: 6px;">Webhook URL</label>
                        <input type="url" name="si_zapier_webhook_url" id="si_zapier_webhook_url" value="<?php echo esc_attr( get_option( 'si_zapier_webhook_url' ) ); ?>" class="regular-text" placeholder="https://hooks.zapier.com/hooks/catch/..." style="width: 100%;">
                        <p class="description">Paste the Catch Hook URL provided by Zapier.</p>
                    </div>

                    <?php submit_button(); ?>
                </form>
            </div>
        </div>
        <?php
    }

    public static function trigger_webhook( $post_id, $post, $update ) {
        // Prevent running on autosaves, revisions, or unauthorized user action
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        if ( get_option( 'si_zapier_enabled' ) != '1' ) return;
        $webhook_url = get_option( 'si_zapier_webhook_url' );
        if ( empty( $webhook_url ) ) return;

        // Collect the payload data
        $payload = array(
            'post_id'          => $post_id,
            'post_title'       => $post->post_title,
            'post_url'         => get_permalink( $post_id ),
            'post_status'      => $post->post_status,
            'post_date'        => $post->post_date,
            'seo_title'        => get_post_meta( $post_id, '_si_seo_title', true ),
            'meta_description' => get_post_meta( $post_id, '_si_meta_description', true ),
            'focus_keywords'   => get_post_meta( $post_id, '_si_focus_keywords', true ),
            'is_cornerstone'   => get_post_meta( $post_id, '_si_is_cornerstone', true ),
            'author_id'        => $post->post_author,
            'author_name'      => get_the_author_meta( 'display_name', $post->post_author ),
            'event'            => $update ? 'post_updated' : 'post_created'
        );

        // Schedule as async event so it doesn't block the UI save
        wp_schedule_single_event( time(), 'si_async_webhook_trigger', array( $webhook_url, $payload ) );
    }

    /**
     * Called by WP-Cron to actually fire the webhook safely in the background.
     */
    public static function async_webhook_fire( $webhook_url, $payload ) {
        wp_remote_post( $webhook_url, array(
            'headers'   => array( 'Content-Type' => 'application/json' ),
            'body'      => wp_json_encode( $payload ),
            'timeout'   => 5,
            'blocking'  => false // We don't care about the response
        ));
    }
}

// Hook for the scheduled event
add_action( 'si_async_webhook_trigger', array( 'SI_Zapier_Webhooks', 'async_webhook_fire' ), 10, 2 );
