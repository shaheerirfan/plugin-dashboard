<?php
/**
 * SI_SEO_Workouts
 *
 * Guided, task-driven SEO improvement panels modelled on Yoast Premium's
 * "Workouts" feature.  Two workouts are provided:
 *
 *   1. Orphaned Content  – posts with zero internal in-links.
 *   2. Cornerstone Cleanup – cornerstone pages that lack enough internal links.
 *
 * All heavy lifting happens server-side via AJAX so the admin panel stays fast.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_SEO_Workouts {

    // -----------------------------------------------------------------------
    public static function init(): void {
        add_action( 'wp_ajax_si_workouts_orphaned',     [ __CLASS__, 'ajax_orphaned' ] );
        add_action( 'wp_ajax_si_workouts_cornerstone',  [ __CLASS__, 'ajax_cornerstone' ] );
        add_action( 'wp_ajax_si_workouts_save_cornerstone', [ __CLASS__, 'ajax_save_cornerstone' ] );
        add_action( 'save_post', [ __CLASS__, 'maybe_clear_cache' ] );
    }

    // -----------------------------------------------------------------------
    // Admin page renderer
    // -----------------------------------------------------------------------
    public static function render_page(): void {
        $nonce = wp_create_nonce( 'si_nonce' );
        ?>
        <div id="si-workouts-page" class="si-page-wrap">
            <header class="si-page-header">
                <h1>SEO Workouts</h1>
                <p>Step-by-step routines to fix common structural SEO problems across your content.</p>
            </header>

            <!-- Tab Nav -->
            <nav class="si-tab-nav" style="display:flex;gap:12px;margin-bottom:28px;">
                <button class="si-tab-btn si-tab-active" data-tab="orphaned">
                    <span class="dashicons dashicons-editor-unlink" style="vertical-align:middle;margin-right:4px;"></span>
                    Orphaned Content
                </button>
                <button class="si-tab-btn" data-tab="cornerstone">
                    <span class="dashicons dashicons-star-filled" style="vertical-align:middle;margin-right:4px;"></span>
                    Cornerstone Cleanup
                </button>
            </nav>

            <!-- ── ORPHANED CONTENT ─────────────────────────────────── -->
            <div id="si-tab-orphaned" class="si-tab-panel">
                <div class="si-settings-card" style="max-width:900px;">
                    <h3>Orphaned Content Workout</h3>
                    <p style="color:var(--si-gray);">
                        Orphaned content is published content that no other page on your site links to.
                        Google rarely ranks pages it cannot reach from your navigation or other internal links.
                    </p>
                    <p style="font-size:.9rem;color:var(--si-gray);">
                        <strong>How to fix:</strong> Add at least one internal link from a related post or your cornerstone content to each orphaned page listed below.
                    </p>
                    <button id="si-run-orphaned-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>">
                        Scan for Orphaned Content
                    </button>
                    <div id="si-orphaned-loading" style="display:none;margin-top:16px;">
                        <span class="si-spinner"></span> Scanning all published posts and pages…
                    </div>
                    <div id="si-orphaned-results" style="margin-top:24px;"></div>
                </div>
            </div>

            <!-- ── CORNERSTONE CLEANUP ──────────────────────────────── -->
            <div id="si-tab-cornerstone" class="si-tab-panel" style="display:none;">
                <div class="si-settings-card" style="max-width:900px;">
                    <h3>Cornerstone Cleanup Workout</h3>
                    <p style="color:var(--si-gray);">
                        Cornerstone content is your most important content. Mark posts as cornerstone then build
                        a strong internal link structure pointing to them.
                    </p>
                    <p style="font-size:.9rem;color:var(--si-gray);">
                        <strong>Goal:</strong> Each cornerstone page should be linked to from at least <strong>5 other pages</strong> on your site.
                    </p>
                    <button id="si-run-cornerstone-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>">
                        Analyse Cornerstone Content
                    </button>
                    <div id="si-cornerstone-loading" style="display:none;margin-top:16px;">
                        <span class="si-spinner"></span> Analysing cornerstone pages…
                    </div>
                    <div id="si-cornerstone-results" style="margin-top:24px;"></div>
                </div>
            </div>
        </div>

        <script>
        (function($){
            // Tab switching
            $('.si-tab-btn').on('click', function(){
                $('.si-tab-btn').removeClass('si-tab-active');
                $(this).addClass('si-tab-active');
                var tab = $(this).data('tab');
                $('.si-tab-panel').hide();
                $('#si-tab-' + tab).show();
            });

            // ── Orphaned Content ────────────────────────────────────
            $('#si-run-orphaned-btn').on('click', function(){
                var nonce = $(this).data('nonce');
                $('#si-orphaned-loading').show();
                $('#si-orphaned-results').html('');
                $.post(ajaxurl, { action: 'si_workouts_orphaned', _ajax_nonce: nonce }, function(r){
                    $('#si-orphaned-loading').hide();
                    if (!r.success) {
                        $('#si-orphaned-results').html('<p class="si-error">Error: ' + (r.data || 'Unknown') + '</p>');
                        return;
                    }
                    var posts = r.data;
                    if (!posts.length) {
                        $('#si-orphaned-results').html('<div class="si-workout-success"><span class="dashicons dashicons-yes-alt"></span> Great news — no orphaned content found!</div>');
                        return;
                    }
                    var html = '<p style="font-weight:600;margin-bottom:12px;">' + posts.length + ' orphaned post(s) found:</p>';
                    html += '<div class="si-workout-table">';
                    html += '<div class="si-workout-row si-workout-head"><span>Post Title</span><span>Type</span><span>In-Links</span><span>Action</span></div>';
                    $.each(posts, function(i, p){
                        html += '<div class="si-workout-row">';
                        html += '<span><a href="' + p.permalink + '" target="_blank">' + si_esc(p.title) + '</a></span>';
                        html += '<span><code>' + si_esc(p.type) + '</code></span>';
                        html += '<span><strong style="color:#e53e3e;">0</strong></span>';
                        html += '<span><a href="' + p.edit_url + '" class="button button-small">Edit &amp; Add Links</a></span>';
                        html += '</div>';
                    });
                    html += '</div>';
                    $('#si-orphaned-results').html(html);
                });
            });

            // ── Cornerstone ─────────────────────────────────────────
            $('#si-run-cornerstone-btn').on('click', function(){
                var nonce = $(this).data('nonce');
                $('#si-cornerstone-loading').show();
                $('#si-cornerstone-results').html('');
                $.post(ajaxurl, { action: 'si_workouts_cornerstone', _ajax_nonce: nonce }, function(r){
                    $('#si-cornerstone-loading').hide();
                    if (!r.success) {
                        $('#si-cornerstone-results').html('<p class="si-error">Error: ' + (r.data || 'Unknown') + '</p>');
                        return;
                    }
                    var pages = r.data;
                    if (!pages.length) {
                        $('#si-cornerstone-results').html('<div class="si-workout-info"><span class="dashicons dashicons-info"></span> No posts marked as cornerstone content yet. Edit any post and enable the Cornerstone toggle in the SEO Inspector meta box.</div>');
                        return;
                    }
                    var html = '<div class="si-workout-table">';
                    html += '<div class="si-workout-row si-workout-head"><span>Cornerstone Post</span><span>In-Links</span><span>Status</span><span>Action</span></div>';
                    $.each(pages, function(i, p){
                        var statusClass = p.in_links >= 5 ? 'si-badge-good' : (p.in_links >= 2 ? 'si-badge-ok' : 'si-badge-bad');
                        var statusTxt   = p.in_links >= 5 ? '✓ Good' : (p.in_links >= 2 ? '⚠ Needs more' : '✗ Too few');
                        html += '<div class="si-workout-row">';
                        html += '<span><a href="' + p.permalink + '" target="_blank">' + si_esc(p.title) + '</a></span>';
                        html += '<span><strong>' + p.in_links + '</strong></span>';
                        html += '<span><span class="si-badge ' + statusClass + '">' + statusTxt + '</span></span>';
                        html += '<span><a href="' + p.edit_url + '" class="button button-small">Edit Post</a></span>';
                        html += '</div>';
                    });
                    html += '</div>';
                    $('#si-cornerstone-results').html(html);
                });
            });

            function si_esc(str){ return $('<div>').text(str).html(); }
        })(jQuery);
        </script>
        <?php
    }

    // -----------------------------------------------------------------------
    // AJAX: Orphaned Content scan
    // Returns posts that have ZERO inbound internal links tracked in si_link_counts
    // -----------------------------------------------------------------------
    public static function ajax_orphaned(): void {
        check_ajax_referer( 'si_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        // Pull all published posts + pages
        $all_posts = get_posts( [
            'post_type'      => [ 'post', 'page' ],
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
        ] );

        $orphaned = [];

        foreach ( $all_posts as $post_id ) {
            // Count internal inbound links using SI_Link_Counter data
            $inbound = self::count_inbound_links( $post_id );

            if ( $inbound === 0 ) {
                $orphaned[] = [
                    'id'        => $post_id,
                    'title'     => get_the_title( $post_id ),
                    'type'      => get_post_type( $post_id ),
                    'permalink' => get_permalink( $post_id ),
                    'edit_url'  => get_edit_post_link( $post_id, 'raw' ),
                ];
            }
        }

        wp_send_json_success( $orphaned );
    }

    // -----------------------------------------------------------------------
    // AJAX: Cornerstone analysis
    // -----------------------------------------------------------------------
    public static function ajax_cornerstone(): void {
        check_ajax_referer( 'si_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $cornerstone_posts = get_posts( [
            'post_type'      => [ 'post', 'page' ],
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'meta_query'     => [
                [
                    'key'     => '_si_is_cornerstone',
                    'value'   => '1',
                    'compare' => '=',
                ],
            ],
        ] );

        $results = [];
        foreach ( $cornerstone_posts as $post_id ) {
            $results[] = [
                'id'        => $post_id,
                'title'     => get_the_title( $post_id ),
                'permalink' => get_permalink( $post_id ),
                'edit_url'  => get_edit_post_link( $post_id, 'raw' ),
                'in_links'  => self::count_inbound_links( $post_id ),
            ];
        }

        // Sort by in_links ASC so weakest cornerstone pages appear first
        usort( $results, fn( $a, $b ) => $a['in_links'] <=> $b['in_links'] );

        wp_send_json_success( $results );
    }

    // -----------------------------------------------------------------------
    // Count inbound internal links for a given post
    // Uses SI_Link_Counter's stored link map if available, otherwise scans content
    // -----------------------------------------------------------------------
    private static function count_inbound_links( int $post_id ): int {
        // SI_Link_Counter stores outbound links per post as '_si_link_data'.
        // We need the inverse: how many OTHER posts link TO $post_id.
        $target_url  = get_permalink( $post_id );
        $target_path = wp_parse_url( $target_url, PHP_URL_PATH );

        // Quick cache per request
        static $link_cache = null;
        if ( $link_cache === null ) {
            $link_cache = [];
            $all = get_posts( [
                'post_type'      => [ 'post', 'page' ],
                'post_status'    => 'publish',
                'posts_per_page' => 500,
                'fields'         => 'ids',
            ] );
            foreach ( $all as $pid ) {
                $data = get_post_meta( $pid, '_si_link_data', true );
                if ( is_array( $data ) ) {
                    foreach ( $data as $link ) {
                        $path = wp_parse_url( $link['url'] ?? '', PHP_URL_PATH );
                        if ( $path ) {
                            $link_cache[ $path ][] = $pid;
                        }
                    }
                }
            }
        }

        return count( $link_cache[ $target_path ] ?? [] );
    }

    // -----------------------------------------------------------------------
    public static function maybe_clear_cache( int $post_id ): void {
        // Nothing stored statically across requests, so nothing to clear.
        // Placeholder for future Redis/transient cache invalidation.
    }
}
