<?php
/**
 * SEO Inspector Migration Tool Class
 * Handles importing meta settings from competitor SEO plugins.
 */

class SI_Migration {
    public static function init() {
        add_action( 'wp_ajax_si_run_migration', array( __CLASS__, 'run_migration' ) );
    }

    public static function run_migration() {
        check_ajax_referer( 'si_nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $plugin = isset( $_POST['plugin'] ) ? sanitize_text_field( $_POST['plugin'] ) : '';
        if ( ! in_array( $plugin, array( 'yoast', 'rankmath', 'auto' ) ) ) {
            wp_send_json_error( 'Invalid plugin selected.' );
        }

        // Get all public post types (posts, pages, custom post types)
        $args = array(
            'public'   => true,
            '_builtin' => false
        );
        $output = 'names';
        $operator = 'and';
        $post_types = get_post_types( $args, $output, $operator ); 
        $post_types['post'] = 'post';
        $post_types['page'] = 'page';

        $query_args = array(
            'post_type'      => array_keys($post_types),
            'post_status'    => 'publish',
            'posts_per_page' => -1, // Get all
            'fields'         => 'ids',
        );

        $query = new WP_Query( $query_args );
        $count = 0;

        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post_id ) {
                $updated = self::migrate_post_meta( $post_id, $plugin );
                if ( $updated ) {
                    $count++;
                }
            }
        }

        if ( $count === 0 ) {
            wp_send_json_success( '0 posts migrated. Either no competitor data was found, or your SEO Inspector fields are already populated.' );
        } else {
            wp_send_json_success( sprintf( 'Successfully migrated SEO data for %d posts/pages.', $count ) );
        }
    }

    private static function migrate_post_meta( $post_id, $plugin ) {
        $updated = false;

        $map = array();

        if ( $plugin === 'auto' ) {
            $all_meta = get_post_meta( $post_id );
            $found_competitor = '';
            
            // Check footprints
            foreach ( $all_meta as $key => $values ) {
                if ( strpos( $key, '_yoast_' ) !== false ) { $found_competitor = 'yoast'; break; }
                elseif ( strpos( $key, 'rank_math_' ) !== false ) { $found_competitor = 'rankmath'; break; }
                elseif ( strpos( $key, '_aioseo' ) !== false ) { $found_competitor = 'aioseo'; break; }
                elseif ( strpos( $key, '_seopress_' ) !== false ) { $found_competitor = 'seopress'; break; }
                elseif ( strpos( $key, 'sq_' ) !== false && isset($all_meta['sq_title']) ) { $found_competitor = 'squirrly'; break; }
                elseif ( strpos( $key, '_su_title' ) !== false ) { $found_competitor = 'smartcrawl'; break; }
            }

            $plugin = ! empty( $found_competitor ) ? $found_competitor : 'generic';
        }

        if ( $plugin === 'yoast' ) {
            $map = array(
                '_yoast_wpseo_title'                => '_si_seo_title',
                '_yoast_wpseo_metadesc'             => '_si_meta_description',
                '_yoast_wpseo_focuskw'              => '_si_focus_keywords',
                '_yoast_wpseo_canonical'            => '_si_canonical_url',
                '_yoast_wpseo_opengraph-title'      => '_si_fb_title',
                '_yoast_wpseo_opengraph-description'=> '_si_fb_desc',
                '_yoast_wpseo_twitter-title'        => '_si_tw_title',
                '_yoast_wpseo_twitter-description'  => '_si_tw_desc',
            );
            
            // Handle Yoast Robots
            $noindex = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
            $old_robots = get_post_meta( $post_id, '_si_robots', true );
            if ( empty( $old_robots ) && $noindex == '1' ) {
                update_post_meta( $post_id, '_si_robots', array( 'noindex' ) );
                $updated = true;
            }

        } elseif ( $plugin === 'rankmath' ) {
            $map = array(
                'rank_math_title'                => '_si_seo_title',
                'rank_math_description'          => '_si_meta_description',
                'rank_math_focus_keyword'        => '_si_focus_keywords',
                'rank_math_canonical_url'        => '_si_canonical_url',
                'rank_math_facebook_title'       => '_si_fb_title',
                'rank_math_facebook_description' => '_si_fb_desc',
                'rank_math_twitter_title'        => '_si_tw_title',
                'rank_math_twitter_description'  => '_si_tw_desc',
            );
            
            // Handle RankMath Robots
            $robots_raw = get_post_meta( $post_id, 'rank_math_robots', true );
            if ( ! empty( $robots_raw ) && is_array( $robots_raw ) ) {
                $old_robots = get_post_meta( $post_id, '_si_robots', true );
                if ( empty( $old_robots ) ) {
                    update_post_meta( $post_id, '_si_robots', $robots_raw );
                    $updated = true;
                }
            }
        } elseif ( $plugin === 'aioseo' ) {
            $map = array(
                '_aioseo_title'                => '_si_seo_title',
                '_aioseop_title'               => '_si_seo_title',
                '_aioseo_description'          => '_si_meta_description',
                '_aioseop_description'         => '_si_meta_description',
                '_aioseo_keywords'             => '_si_focus_keywords',
                '_aioseop_keywords'            => '_si_focus_keywords',
                '_aioseo_facebook_title'       => '_si_fb_title',
                '_aioseo_facebook_description' => '_si_fb_desc',
                '_aioseo_twitter_title'        => '_si_tw_title',
                '_aioseo_twitter_description'  => '_si_tw_desc',
            );
        } elseif ( $plugin === 'seopress' ) {
            $map = array(
                '_seopress_titles_title'       => '_si_seo_title',
                '_seopress_titles_desc'        => '_si_meta_description',
                '_seopress_analysis_target_kw' => '_si_focus_keywords',
                '_seopress_social_fb_title'    => '_si_fb_title',
                '_seopress_social_fb_desc'     => '_si_fb_desc',
                '_seopress_social_twitter_title'=> '_si_tw_title',
                '_seopress_social_twitter_desc'=> '_si_tw_desc',
            );
        } elseif ( $plugin === 'generic' ) {
            $map = array(
                '_meta_title'      => '_si_seo_title',
                'seo_title'        => '_si_seo_title',
                '_seo_title'       => '_si_seo_title',
                'title_tag'        => '_si_seo_title',
                '_meta_description'=> '_si_meta_description',
                'meta_desc'        => '_si_meta_description',
                '_seo_desc'        => '_si_meta_description',
                'focus_keyword'    => '_si_focus_keywords',
                '_focus_keyword'   => '_si_focus_keywords',
                'meta_keywords'    => '_si_focus_keywords',
            );
        }

        foreach ( $map as $old_key => $new_key ) {
            $old_value = get_post_meta( $post_id, $old_key, true );
            if ( ! empty( $old_value ) ) {
                // Check if target is empty so we don't overwrite
                $current_value = get_post_meta( $post_id, $new_key, true );
                if ( empty( $current_value ) ) {
                    update_post_meta( $post_id, $new_key, $old_value );
                    $updated = true;
                }
            }
        }

        return $updated;
    }
}
