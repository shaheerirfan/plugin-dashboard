<?php
/**
 * SI_Import_Export
 *
 * JSON-based full-system backup and restore for SEO Inspector.
 * Exports every option key owned by the plugin plus all redirect rules.
 * Import validates the JSON envelope before writing anything to the DB.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Import_Export {

    /** Every option key the plugin owns */
    private static array $option_keys = [
        'si_gsc_id',
        'si_ga_id',
        'si_twitter_id',
        'si_og_image',
        'si_sitemap_post_types',
        'si_crawl_settings',
        'si_sa_settings',          // Search Appearance global settings
        'si_redirects',            // Redirect rules array
        'si_robots_custom',        // Custom robots.txt content
        'si_indexnow_enabled',     // IndexNow status flag
        'si_indexnow_key',         // IndexNow verification key
    ];

    public static function init(): void {
        add_action( 'wp_ajax_si_export_settings',  [ __CLASS__, 'ajax_export' ] );
        add_action( 'wp_ajax_si_import_settings',  [ __CLASS__, 'ajax_import' ] );
    }

    // -----------------------------------------------------------------------
    // Admin page
    // -----------------------------------------------------------------------
    public static function render_page(): void {
        $nonce = wp_create_nonce( 'si_nonce' );
        ?>
        <div id="si-import-export-page" class="si-page-wrap">
            <header class="si-page-header">
                <h1>Import / Export</h1>
                <p>Back up all SEO Inspector settings to a JSON file, or restore from a previous backup.</p>
            </header>

            <div class="si-card-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:24px;max-width:1000px;">

                <!-- EXPORT -->
                <div class="si-settings-card">
                    <h3>Export Settings</h3>
                    <p style="color:var(--si-gray);margin-bottom:20px;">
                        Downloads a <code>.json</code> file containing all plugin settings, redirects,
                        Search Appearance configuration, and crawl optimisation toggles.
                        Keep this file safe — it can fully restore your SEO setup.
                    </p>
                    <ul style="font-size:.85rem;color:var(--si-gray);margin:0 0 20px 16px;">
                        <li>Global settings (GA, GSC, Twitter, OG image)</li>
                        <li>Search Appearance templates</li>
                        <li>Sitemap post-type selection</li>
                        <li>All redirect rules</li>
                        <li>Crawl optimisation toggles</li>
                    </ul>
                    <button id="si-export-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>">
                        <span class="dashicons dashicons-download" style="vertical-align:middle;margin-right:4px;"></span>
                        Download Backup JSON
                    </button>
                    <span id="si-export-msg" style="display:none;margin-left:12px;font-size:.9rem;"></span>
                </div>

                <!-- IMPORT -->
                <div class="si-settings-card">
                    <h3>Import Settings</h3>
                    <p style="color:var(--si-gray);margin-bottom:20px;">
                        Upload a previously exported <code>.json</code> backup to restore your full SEO
                        configuration. <strong>Existing settings will be overwritten.</strong>
                    </p>
                    <div class="si-mb-field" style="margin-bottom:16px;">
                        <label for="si-import-file" style="font-weight:600;display:block;margin-bottom:6px;">
                            Select backup file (.json)
                        </label>
                        <input type="file" id="si-import-file" accept=".json" style="display:block;width:100%;padding:8px;border:1px dashed #cbd5e1;border-radius:8px;background:#f8fafc;cursor:pointer;">
                    </div>
                    <div style="display:flex;align-items:center;gap:12px;">
                        <button id="si-import-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>" disabled>
                            <span class="dashicons dashicons-upload" style="vertical-align:middle;margin-right:4px;"></span>
                            Restore from Backup
                        </button>
                        <span id="si-import-msg" style="font-size:.9rem;font-weight:600;display:none;"></span>
                    </div>

                    <!-- Progress indicator -->
                    <div id="si-import-progress" style="display:none;margin-top:16px;">
                        <div style="height:6px;background:#e2e8f0;border-radius:4px;overflow:hidden;">
                            <div id="si-import-bar" style="height:100%;width:0%;background:var(--si-primary);transition:width .4s ease;border-radius:4px;"></div>
                        </div>
                        <p id="si-import-status" style="font-size:.85rem;color:var(--si-gray);margin-top:8px;"></p>
                    </div>
                </div>

                <!-- Danger Zone -->
                <div class="si-settings-card" style="grid-column:1/-1;border:1px solid #fed7d7;background:#fff5f5;">
                    <h3 style="color:#c53030;">⚠ Reset All Settings</h3>
                    <p style="color:var(--si-gray);margin-bottom:16px;">
                        Permanently delete all SEO Inspector options from the database.
                        This cannot be undone. Export a backup first.
                    </p>
                    <button id="si-reset-btn" class="button" style="background:#e53e3e;color:#fff;border-color:#c53030;" data-nonce="<?php echo esc_attr( $nonce ); ?>">
                        Reset Everything
                    </button>
                    <span id="si-reset-msg" style="display:none;margin-left:12px;font-size:.9rem;font-weight:600;"></span>
                </div>
            </div>
        </div>

        <script>
        (function($){

            // ── Enable import button when file selected ────────────
            $('#si-import-file').on('change', function(){
                $('#si-import-btn').prop('disabled', !this.files.length);
            });

            // ── EXPORT ─────────────────────────────────────────────
            $('#si-export-btn').on('click', function(){
                var nonce = $(this).data('nonce');
                $('#si-export-msg').show().removeClass('si-success si-error').text('Preparing export…');
                $.post(ajaxurl, { action: 'si_export_settings', _ajax_nonce: nonce }, function(r){
                    if (!r.success) {
                        $('#si-export-msg').addClass('si-error').text('✗ ' + (r.data||'Export failed'));
                        return;
                    }
                    // Trigger file download in browser
                    var json = JSON.stringify(r.data, null, 2);
                    var blob = new Blob([json], { type: 'application/json' });
                    var a    = document.createElement('a');
                    a.href   = URL.createObjectURL(blob);
                    a.download = 'seo-inspector-backup-' + new Date().toISOString().slice(0,10) + '.json';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    $('#si-export-msg').addClass('si-success').text('✓ Backup downloaded!');
                    setTimeout(function(){ $('#si-export-msg').fadeOut(); }, 4000);
                }).fail(function(){
                    $('#si-export-msg').addClass('si-error').text('✗ Server error');
                });
            });

            // ── IMPORT ─────────────────────────────────────────────
            $('#si-import-btn').on('click', function(){
                var file  = $('#si-import-file')[0].files[0];
                var nonce = $(this).data('nonce');
                if (!file) return;

                var reader = new FileReader();
                reader.onload = function(e){
                    var raw;
                    try { raw = JSON.parse(e.target.result); }
                    catch(err){
                        $('#si-import-msg').show().addClass('si-error').text('✗ Invalid JSON file');
                        return;
                    }

                    $('#si-import-progress').show();
                    $('#si-import-bar').css('width','30%');
                    $('#si-import-status').text('Uploading settings…');
                    $('#si-import-msg').hide();

                    $.post(ajaxurl, {
                        action:      'si_import_settings',
                        _ajax_nonce: nonce,
                        payload:     JSON.stringify(raw)
                    }, function(r){
                        $('#si-import-bar').css('width','100%');
                        setTimeout(function(){
                            $('#si-import-progress').hide();
                            $('#si-import-bar').css('width','0%');
                        }, 800);

                        $('#si-import-msg').show().removeClass('si-success si-error');
                        if (r.success) {
                            $('#si-import-msg').addClass('si-success').text('✓ Import successful! Reloading…');
                            setTimeout(function(){ location.reload(); }, 1800);
                        } else {
                            $('#si-import-msg').addClass('si-error').text('✗ ' + (r.data||'Import failed'));
                        }
                    }).fail(function(){
                        $('#si-import-progress').hide();
                        $('#si-import-msg').show().addClass('si-error').text('✗ Server error during import');
                    });
                };
                reader.readAsText(file);
            });

            // ── RESET ──────────────────────────────────────────────
            $('#si-reset-btn').on('click', function(){
                if (!confirm('Are you absolutely sure? This will delete ALL SEO Inspector settings from the database.')) return;
                var nonce = $(this).data('nonce');
                $.post(ajaxurl, { action: 'si_import_settings', _ajax_nonce: nonce, payload: JSON.stringify({ __reset: true }) }, function(r){
                    $('#si-reset-msg').show().removeClass('si-success si-error');
                    if (r.success) {
                        $('#si-reset-msg').addClass('si-success').text('✓ All settings reset. Reloading…');
                        setTimeout(function(){ location.reload(); }, 1800);
                    } else {
                        $('#si-reset-msg').addClass('si-error').text('✗ ' + (r.data||'Reset failed'));
                    }
                });
            });

        })(jQuery);
        </script>
        <?php
    }

    // -----------------------------------------------------------------------
    // AJAX: Export
    // -----------------------------------------------------------------------
    public static function ajax_export(): void {
        check_ajax_referer( 'si_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $data = [
            '__version'   => '1.0',
            '__plugin'    => 'seo-inspector',
            '__exported'  => gmdate( 'c' ),
            '__site'      => home_url(),
            'options'     => [],
        ];

        foreach ( self::$option_keys as $key ) {
            $data['options'][ $key ] = get_option( $key );
        }

        wp_send_json_success( $data );
    }

    // -----------------------------------------------------------------------
    // AJAX: Import  (also handles __reset)
    // -----------------------------------------------------------------------
    public static function ajax_import(): void {
        check_ajax_referer( 'si_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $raw = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '';
        if ( empty( $raw ) ) {
            wp_send_json_error( 'No payload received.' );
        }

        $payload = json_decode( $raw, true );
        if ( ! is_array( $payload ) ) {
            wp_send_json_error( 'Invalid JSON payload.' );
        }

        // ── RESET mode ──────────────────────────────────────────────
        if ( ! empty( $payload['__reset'] ) ) {
            foreach ( self::$option_keys as $key ) {
                delete_option( $key );
            }
            wp_send_json_success( 'All settings have been reset.' );
        }

        // ── IMPORT mode ─────────────────────────────────────────────
        if ( empty( $payload['__plugin'] ) || $payload['__plugin'] !== 'seo-inspector' ) {
            wp_send_json_error( 'This backup was not created by SEO Inspector.' );
        }

        if ( empty( $payload['options'] ) || ! is_array( $payload['options'] ) ) {
            wp_send_json_error( 'Backup file contains no option data.' );
        }

        $imported = 0;
        $allowed  = array_flip( self::$option_keys );

        foreach ( $payload['options'] as $key => $value ) {
            // Only import keys we own — never write arbitrary option names
            if ( ! isset( $allowed[ $key ] ) ) {
                continue;
            }
            // Sanitise based on expected type
            if ( is_array( $value ) ) {
                // Redirect array: deep sanitise URLs and text
                if ( $key === 'si_redirects' ) {
                    $value = self::sanitise_redirects( $value );
                } else {
                    $value = array_map( 'sanitize_text_field', $value );
                }
                update_option( $key, $value );
            } elseif ( is_string( $value ) ) {
                update_option( $key, sanitize_text_field( $value ) );
            } elseif ( is_null( $value ) ) {
                delete_option( $key );
            }
            $imported++;
        }

        wp_send_json_success( sprintf( 'Successfully imported %d settings.', $imported ) );
    }

    // -----------------------------------------------------------------------
    private static function sanitise_redirects( $rules ): array {
        if ( ! is_array( $rules ) ) {
            return [];
        }
        $clean = [];
        foreach ( $rules as $rule ) {
            if ( ! is_array( $rule ) ) {
                continue;
            }
            $clean[] = [
                'from'    => isset( $rule['from'] )    ? sanitize_text_field( $rule['from'] )  : '',
                'to'      => isset( $rule['to'] )      ? esc_url_raw( $rule['to'] )             : '',
                'type'    => isset( $rule['type'] )    ? (int) $rule['type']                    : 301,
                'is_regex'=> ! empty( $rule['is_regex'] ),
                'note'    => isset( $rule['note'] )    ? sanitize_text_field( $rule['note'] )   : '',
            ];
        }
        return $clean;
    }
}
