<?php
/**
 * SEO Inspector AI Helpers
 * Architecture Hardening: Implements provider health monitoring, rate limiting,
 * error logging, and automatic local-provider fallback.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

interface SI_AI_Provider_Interface {
    public function generate_text( $prompt, $system_instruction );
    public function get_provider_name();
}

class SI_AI_Manager {
    
    // Rate limit: Max 10 requests per minute
    private static $max_requests_per_minute = 10;
    
    public static function get_provider() {
        $provider_name = get_option( 'si_ai_provider', 'local' );
        
        // Return active provider based on option
        switch ( $provider_name ) {
            case 'gemini':
                return new SI_AI_Provider_Gemini();
            case 'openai':
                return new SI_AI_Provider_OpenAI();
            case 'anthropic':
                return new SI_AI_Provider_Anthropic();
            default:
                return new SI_AI_Provider_Local();
        }
    }

    public static function generate_meta( $post_id, $type = 'title' ) {
        if ( ! self::check_rate_limit() ) {
            self::log_error( 'system', 'Rate limit exceeded.' );
            $provider = new SI_AI_Provider_Local(); // Fallback to local
        } else {
            $provider = self::get_provider();
            // Check health
            if ( ! self::check_provider_health( $provider->get_provider_name() ) ) {
                self::log_error( $provider->get_provider_name(), 'Provider marked as unhealthy. Falling back to local.' );
                $provider = new SI_AI_Provider_Local();
            }
        }
        
        try {
            $start = microtime(true);
            $prompt = "Generate $type for post ID $post_id";
            $result = $provider->generate_text( $prompt, 'You are an SEO expert.' );
            $time_taken = microtime(true) - $start;
            
            self::log_usage( $provider->get_provider_name(), $time_taken );
            return $result;
        } catch ( Exception $e ) {
            self::log_error( $provider->get_provider_name(), $e->getMessage() );
            self::mark_provider_unhealthy( $provider->get_provider_name() );
            
            // Automatic local-provider fallback
            $local = new SI_AI_Provider_Local();
            return $local->generate_text( $prompt, 'You are an SEO expert.' );
        }
    }

    private static function check_rate_limit() {
        $transient_key = 'si_ai_rate_limit';
        $requests = get_transient( $transient_key );
        if ( false === $requests ) {
            set_transient( $transient_key, 1, 60 );
            return true;
        }
        if ( $requests >= self::$max_requests_per_minute ) {
            return false;
        }
        set_transient( $transient_key, $requests + 1, 60 );
        return true;
    }

    private static function check_provider_health( $provider_name ) {
        if ( $provider_name === 'local' ) return true;
        return get_transient( 'si_ai_health_' . $provider_name ) !== 'failing';
    }

    private static function mark_provider_unhealthy( $provider_name ) {
        if ( $provider_name === 'local' ) return;
        set_transient( 'si_ai_health_' . $provider_name, 'failing', 5 * MINUTE_IN_SECONDS ); // Fail for 5 mins
    }

    private static function log_usage( $provider_name, $time_taken ) {
        $logs = get_option( 'si_ai_usage_logs', array() );
        $logs[] = array(
            'time'     => current_time('mysql'),
            'provider' => $provider_name,
            'duration' => $time_taken
        );
        if ( count($logs) > 100 ) array_shift($logs); // Keep last 100
        update_option( 'si_ai_usage_logs', $logs, false );
    }

    private static function log_error( $provider_name, $error_message ) {
        $logs = get_option( 'si_ai_error_logs', array() );
        $logs[] = array(
            'time'     => current_time('mysql'),
            'provider' => $provider_name,
            'error'    => sanitize_text_field( $error_message )
        );
        if ( count($logs) > 50 ) array_shift($logs); // Keep last 50
        update_option( 'si_ai_error_logs', $logs, false );
    }
}

class SI_AI_Provider_Gemini implements SI_AI_Provider_Interface {
    public function generate_text( $prompt, $system_instruction ) { return 'Gemini Response'; }
    public function get_provider_name() { return 'gemini'; }
}

class SI_AI_Provider_OpenAI implements SI_AI_Provider_Interface {
    public function generate_text( $prompt, $system_instruction ) { return 'OpenAI Response'; }
    public function get_provider_name() { return 'openai'; }
}

class SI_AI_Provider_Anthropic implements SI_AI_Provider_Interface {
    public function generate_text( $prompt, $system_instruction ) { return 'Anthropic Response'; }
    public function get_provider_name() { return 'anthropic'; }
}

class SI_AI_Provider_Local implements SI_AI_Provider_Interface {
    public function generate_text( $prompt, $system_instruction ) {
        return 'Local Rule-Based Fallback Generated Content.';
    }
    public function get_provider_name() { return 'local'; }
}
