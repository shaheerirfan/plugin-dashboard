<?php
/**
 * SEO Inspector Search Appearance Class
 * Handles global title/description templates and replacement tokens.
 */

class SI_Search_Appearance {
    
    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
        add_filter( 'pre_get_document_title', array( __CLASS__, 'filter_document_title' ), 15 );
        add_filter( 'the_content', array( __CLASS__, 'inject_woocommerce_social_metadata' ) );
    }

    public static function register_settings() {
        register_setting( 'si_search_appearance_settings', 'si_title_sep' );
        register_setting( 'si_search_appearance_settings', 'si_home_title_template' );
        register_setting( 'si_search_appearance_settings', 'si_home_desc_template' );
        
        // Post type defaults
        $post_types = get_post_types( array( 'public' => true ), 'names' );
        foreach ( $post_types as $pt ) {
            register_setting( 'si_search_appearance_settings', "si_{$pt}_title_template" );
            register_setting( 'si_search_appearance_settings', "si_{$pt}_desc_template" );
            register_setting( 'si_search_appearance_settings', "si_{$pt}_meta_robots_noindex" );
        }

        // Taxonomy defaults
        $taxonomies = get_taxonomies( array( 'public' => true ), 'names' );
        foreach ( $taxonomies as $tax ) {
            register_setting( 'si_search_appearance_settings', "si_tax_{$tax}_title_template" );
            register_setting( 'si_search_appearance_settings', "si_tax_{$tax}_desc_template" );
            register_setting( 'si_search_appearance_settings', "si_tax_{$tax}_meta_robots_noindex" );
        }
    }

    /**
     * Resolves variables/tokens in a given template
     */
    public static function resolve_tokens( $template, $post_id = 0 ) {
        if ( empty( $template ) ) {
            return '';
        }

        $sep = get_option( 'si_title_sep', '-' );
        $sitename = get_bloginfo( 'name' );
        $sitedesc = get_bloginfo( 'description' );
        
        $title = '';
        $excerpt = '';
        $date = '';
        $author = '';
        $category = '';
        $term_name = '';

        if ( is_singular() || $post_id > 0 ) {
            $id = $post_id ?: get_the_ID();
            $post = get_post( $id );
            if ( $post ) {
                $title = get_the_title( $id );
                $date = get_the_date( 'c', $id );
                $author_id = $post->post_author;
                $author = get_the_author_meta( 'display_name', $author_id );
                
                $post_excerpt = has_excerpt( $id ) ? get_the_excerpt( $id ) : wp_trim_words( strip_shortcodes( $post->post_content ), 30 );
                $excerpt = str_replace( array("\r", "\n"), ' ', strip_tags( $post_excerpt ) );
                
                $categories = get_the_category( $id );
                if ( ! empty( $categories ) ) {
                    $category = $categories[0]->name;
                }
            }
        } elseif ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();
            if ( $term ) {
                $term_name = $term->name;
                $title = $term->name;
                $excerpt = term_description( $term->term_id );
            }
        } elseif ( is_author() ) {
            $author_obj = get_queried_object();
            if ( $author_obj ) {
                $title = $author_obj->display_name;
                $author = $author_obj->display_name;
            }
        } elseif ( is_home() || is_front_page() ) {
            $title = $sitename;
            $excerpt = $sitedesc;
        }

        $replacements = array(
            '{title}'      => $title,
            '{sitename}'   => $sitename,
            '{sitedesc}'   => $sitedesc,
            '{sep}'        => $sep,
            '{excerpt}'    => $excerpt,
            '{date}'       => $date,
            '{author}'     => $author,
            '{category}'   => $category,
            '{term_name}'  => $term_name,
        );

        return str_replace( array_keys( $replacements ), array_values( $replacements ), $template );
    }

    /**
     * Hook to override the frontend title output
     */
    public static function filter_document_title( $title ) {
        if ( is_front_page() || is_home() ) {
            $template = get_option( 'si_home_title_template', '{title} {sep} {sitedesc}' );
            return self::resolve_tokens( $template );
        }

        if ( is_singular() ) {
            $post_id = get_the_ID();
            
            // Post-level override takes precedence
            $post_seo_title = get_post_meta( $post_id, '_si_seo_title', true );
            if ( ! empty( $post_seo_title ) ) {
                return self::resolve_tokens( $post_seo_title, $post_id );
            }

            // Fallback to global post type templates
            $post_type = get_post_type( $post_id );
            $template = get_option( "si_{$post_type}_title_template", '{title} {sep} {sitename}' );
            return self::resolve_tokens( $template, $post_id );
        }

        if ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();
            if ( $term ) {
                $taxonomy = $term->taxonomy;
                $template = get_option( "si_tax_{$taxonomy}_title_template", '{term_name} Archive {sep} {sitename}' );
                return self::resolve_tokens( $template );
            }
        }

        return $title;
    }

    /**
     * Resolves meta description tags dynamically using templates
     */
    public static function get_meta_description() {
        if ( is_front_page() || is_home() ) {
            $template = get_option( 'si_home_desc_template', get_bloginfo( 'description' ) );
            return self::resolve_tokens( $template );
        }

        if ( is_singular() ) {
            $post_id = get_the_ID();
            $post_desc = get_post_meta( $post_id, '_si_meta_description', true );
            if ( ! empty( $post_desc ) ) {
                return self::resolve_tokens( $post_desc, $post_id );
            }

            // Fallback to post type default
            $post_type = get_post_type( $post_id );
            $template = get_option( "si_{$post_type}_desc_template", '{excerpt}' );
            return self::resolve_tokens( $template, $post_id );
        }

        if ( is_category() || is_tag() || is_tax() ) {
            $term = get_queried_object();
            if ( $term ) {
                $taxonomy = $term->taxonomy;
                $template = get_option( "si_tax_{$taxonomy}_desc_template", '{excerpt}' );
                return self::resolve_tokens( $template );
            }
        }

        return '';
    }

    /**
     * Add Open Graph price and availability schema tags if WooCommerce product is present
     */
    public static function inject_woocommerce_social_metadata( $content ) {
        if ( is_singular( 'product' ) && class_exists( 'WooCommerce' ) ) {
            $product_id = get_the_ID();
            $product = wc_get_product( $product_id );
            if ( $product ) {
                add_action( 'wp_head', function() use ( $product ) {
                    echo '<!-- WooCommerce Social Metadata -->' . "\n";
                    echo '<meta property="product:price:amount" content="' . esc_attr( $product->get_price() ) . '" />' . "\n";
                    echo '<meta property="product:price:currency" content="' . esc_attr( get_woocommerce_currency() ) . '" />' . "\n";
                    $availability = $product->is_in_stock() ? 'instock' : 'oos';
                    echo '<meta property="product:availability" content="' . esc_attr( $availability ) . '" />' . "\n";
                }, 5 );
            }
        }
        return $content;
    }

    /**
     * Renders settings page panel
     */
    public static function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( isset( $_POST['si_save_search_appearance'] ) && check_admin_referer( 'si_search_appearance_nonce' ) ) {
            // Save options manually to avoid options.php redirection
            update_option( 'si_title_sep', sanitize_text_field( $_POST['si_title_sep'] ) );
            update_option( 'si_home_title_template', sanitize_text_field( $_POST['si_home_title_template'] ) );
            update_option( 'si_home_desc_template', sanitize_textarea_field( $_POST['si_home_desc_template'] ) );
            
            $post_types = get_post_types( array( 'public' => true ), 'names' );
            foreach ( $post_types as $pt ) {
                update_option( "si_{$pt}_title_template", sanitize_text_field( $_POST["si_{$pt}_title_template"] ) );
                update_option( "si_{$pt}_desc_template", sanitize_textarea_field( $_POST["si_{$pt}_desc_template"] ) );
                update_option( "si_{$pt}_meta_robots_noindex", isset( $_POST["si_{$pt}_meta_robots_noindex"] ) ? '1' : '0' );
            }

            $taxonomies = get_taxonomies( array( 'public' => true ), 'names' );
            foreach ( $taxonomies as $tax ) {
                update_option( "si_tax_{$tax}_title_template", sanitize_text_field( $_POST["si_tax_{$tax}_title_template"] ) );
                update_option( "si_tax_{$tax}_desc_template", sanitize_textarea_field( $_POST["si_tax_{$tax}_desc_template"] ) );
                update_option( "si_tax_{$tax}_meta_robots_noindex", isset( $_POST["si_tax_{$tax}_meta_robots_noindex"] ) ? '1' : '0' );
            }

            echo '<div class="updated"><p>Search Appearance settings saved successfully!</p></div>';
        }

        $sep = get_option( 'si_title_sep', '-' );
        $home_title = get_option( 'si_home_title_template', '{title} {sep} {sitedesc}' );
        $home_desc = get_option( 'si_home_desc_template', get_bloginfo( 'description' ) );
        ?>
        <div class="wrap si-dashboard">
            <header class="si-header left" style="margin-bottom: 40px; border-bottom: none; padding-bottom: 0;">
                <h1 style="font-size: 3.5rem; line-height: 1.1; margin-bottom: 10px;">Search Appearance</h1>
                <p style="font-size: 1.1rem; color: #64748b;">Configure global default metadata templates and title options across your website.</p>
            </header>

            <div class="si-main-card left" style="padding: 40px;">
                <form method="post">
                    <?php wp_nonce_field( 'si_search_appearance_nonce' ); ?>
                    
                    <!-- Title Separator Section -->
                    <div style="margin-bottom: 40px;">
                        <h3 style="font-size: 1.4rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; margin-bottom: 20px;">Title Separator</h3>
                        <p style="color: #64748b; font-size: 0.9rem; margin-bottom: 15px;">Choose the separator that displays in post/page browser tabs between titles.</p>
                        <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                            <?php 
                            $separators = array( '-', '|', '•', '»', '—', '/' );
                            foreach ( $separators as $s ) :
                            ?>
                                <label style="display: inline-flex; align-items: center; gap: 8px; font-size: 1.1rem; background: #f8fafc; padding: 8px 16px; border-radius: 8px; border: 1px solid #e2e8f0; cursor: pointer;">
                                    <input type="radio" name="si_title_sep" value="<?php echo esc_attr($s); ?>" <?php checked( $sep, $s ); ?> />
                                    <span><?php echo esc_html($s); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Homepage Section -->
                    <div style="margin-bottom: 40px;">
                        <h3 style="font-size: 1.4rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; margin-bottom: 20px;">Homepage Defaults</h3>
                        <div class="si-mb-field">
                            <label>Homepage Title Template</label>
                            <input type="text" name="si_home_title_template" value="<?php echo esc_attr( $home_title ); ?>" />
                            <span style="font-size: 0.8rem; color: #64748b;">Available tokens: <code>{title}</code>, <code>{sep}</code>, <code>{sitename}</code>, <code>{sitedesc}</code></span>
                        </div>
                        <div class="si-mb-field">
                            <label>Homepage Meta Description Template</label>
                            <textarea name="si_home_desc_template" rows="3"><?php echo esc_textarea( $home_desc ); ?></textarea>
                        </div>
                    </div>

                    <!-- Content Types Section -->
                    <div style="margin-bottom: 40px;">
                        <h3 style="font-size: 1.4rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; margin-bottom: 20px;">Content Types</h3>
                        <?php 
                        $post_types = get_post_types( array( 'public' => true ), 'objects' );
                        foreach ( $post_types as $pt ) :
                            if ( $pt->name === 'attachment' ) continue;
                            $title_val = get_option( "si_{$pt->name}_title_template", '{title} {sep} {sitename}' );
                            $desc_val = get_option( "si_{$pt->name}_desc_template", '{excerpt}' );
                            $noindex_val = get_option( "si_{$pt->name}_meta_robots_noindex", '0' );
                        ?>
                            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                                <h4 style="margin: 0 0 15px 0; font-size: 1.1rem; text-transform: capitalize;"><?php echo esc_html($pt->label); ?> (<?php echo esc_html($pt->name); ?>) Defaults</h4>
                                <div class="si-mb-field">
                                    <label>Title Template</label>
                                    <input type="text" name="si_<?php echo esc_attr($pt->name); ?>_title_template" value="<?php echo esc_attr( $title_val ); ?>" />
                                </div>
                                <div class="si-mb-field">
                                    <label>Meta Description Template</label>
                                    <textarea name="si_<?php echo esc_attr($pt->name); ?>_desc_template" rows="2"><?php echo esc_textarea( $desc_val ); ?></textarea>
                                </div>
                                <div class="si-mb-field" style="display: flex; align-items: center; gap: 8px;">
                                    <input type="checkbox" name="si_<?php echo esc_attr($pt->name); ?>_meta_robots_noindex" value="1" <?php checked( $noindex_val, '1' ); ?> />
                                    <label style="margin: 0; font-weight: normal;">Search Engine Visibility: Add <code>noindex</code> to this content type globally</label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Taxonomies Section -->
                    <div style="margin-bottom: 40px;">
                        <h3 style="font-size: 1.4rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; margin-bottom: 20px;">Taxonomies</h3>
                        <?php 
                        $taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
                        foreach ( $taxonomies as $tax ) :
                            $title_val = get_option( "si_tax_{$tax->name}_title_template", '{term_name} Archive {sep} {sitename}' );
                            $desc_val = get_option( "si_tax_{$tax->name}_desc_template", '{excerpt}' );
                            $noindex_val = get_option( "si_tax_{$tax->name}_meta_robots_noindex", '0' );
                        ?>
                            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                                <h4 style="margin: 0 0 15px 0; font-size: 1.1rem; text-transform: capitalize;"><?php echo esc_html($tax->label); ?> Defaults</h4>
                                <div class="si-mb-field">
                                    <label>Title Template</label>
                                    <input type="text" name="si_tax_<?php echo esc_attr($tax->name); ?>_title_template" value="<?php echo esc_attr( $title_val ); ?>" />
                                </div>
                                <div class="si-mb-field">
                                    <label>Meta Description Template</label>
                                    <textarea name="si_tax_<?php echo esc_attr($tax->name); ?>_desc_template" rows="2"><?php echo esc_textarea( $desc_val ); ?></textarea>
                                </div>
                                <div class="si-mb-field" style="display: flex; align-items: center; gap: 8px;">
                                    <input type="checkbox" name="si_tax_<?php echo esc_attr($tax->name); ?>_meta_robots_noindex" value="1" <?php checked( $noindex_val, '1' ); ?> />
                                    <label style="margin: 0; font-weight: normal;">Search Engine Visibility: Add <code>noindex</code> to this taxonomy globally</label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <button type="submit" name="si_save_search_appearance" class="button button-primary" style="height: 48px; border-radius: 12px; padding: 0 30px; font-weight: 700; background: var(--si-primary) !important; border: none !important; box-shadow: 0 4px 12px rgba(58, 187, 168, 0.3) !important;">Save Changes</button>
                </form>
            </div>
        </div>
        <?php
    }
}
