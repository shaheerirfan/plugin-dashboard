<?php
/**
 * SEO Inspector Link Counter
 * Tracks incoming and outgoing internal links to identify orphaned content.
 */

class SI_Link_Counter {

    public static function init() {
        // Track links on save and trash
        add_action( 'save_post', array( __CLASS__, 'process_links_on_save' ), 10, 2 );
        add_action( 'trashed_post', array( __CLASS__, 'process_links_on_trash' ) );
        add_action( 'untrashed_post', array( __CLASS__, 'process_links_on_restore' ) );

        // Add columns to posts/pages lists
        $post_types = array( 'post', 'page' );
        foreach ( $post_types as $pt ) {
            add_filter( "manage_{$pt}_posts_columns", array( __CLASS__, 'add_columns' ) );
            add_action( "manage_{$pt}_posts_custom_column", array( __CLASS__, 'render_columns' ), 10, 2 );
            add_filter( "manage_edit-{$pt}_sortable_columns", array( __CLASS__, 'sortable_columns' ) );
        }

        // Add quick filter for orphaned content
        add_action( 'restrict_manage_posts', array( __CLASS__, 'add_orphaned_filter' ) );
        add_filter( 'pre_get_posts', array( __CLASS__, 'filter_orphaned_posts' ) );

        // Recalculate tools
        add_action( 'admin_notices', array( __CLASS__, 'admin_notice_recalculate' ) );
        add_action( 'wp_ajax_si_recalculate_links', array( __CLASS__, 'ajax_recalculate_links' ) );
        add_action( 'admin_footer', array( __CLASS__, 'recalculate_script' ) );
    }

    /**
     * Process internal links when a post is saved.
     */
    public static function process_links_on_save( $post_id, $post = null ) {
        if ( ! $post ) {
            $post = get_post( $post_id );
        }

        // Ignore autosaves, revisions, and non-published posts for accurate linking
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( $post->post_status !== 'publish' ) {
            // If it was published and is now something else, we should treat it like a trash event
            $old_status = isset( $_POST['original_post_status'] ) ? $_POST['original_post_status'] : '';
            if ( $old_status === 'publish' ) {
                self::process_links_on_trash( $post_id );
            }
            return;
        }

        // Get the post content
        $content = $post->post_content;
        
        // Find all hrefs
        preg_match_all( '/<a\s+[^>]*href=["\']([^"\']+)["\']/i', $content, $matches );
        $links = $matches[1];

        $site_url = home_url();
        $site_host = parse_url( $site_url, PHP_URL_HOST );
        
        $linked_post_ids = array();
        $external_links_count = 0;

        foreach ( $links as $link ) {
            // Ignore anchor links or mailto
            if ( strpos( $link, '#' ) === 0 || strpos( $link, 'mailto:' ) === 0 || strpos( $link, 'javascript:' ) === 0 ) continue;

            // Check if it's an internal link
            if ( strpos( $link, $site_url ) === 0 || strpos( $link, '/' ) === 0 ) {
                // Try to get post ID from URL
                $linked_id = url_to_postid( $link );
                
                // Don't count self-links
                if ( $linked_id && $linked_id !== $post_id ) {
                    $linked_post_ids[] = $linked_id;
                }
            } else {
                // External link
                $external_links_count++;
            }
        }

        // Deduplicate linked IDs (multiple links to the same post count as 1 incoming link connection)
        $linked_post_ids = array_unique( $linked_post_ids );

        // Get the old linked IDs to figure out what changed
        $old_linked_ids = get_post_meta( $post_id, '_si_linked_to', true );
        if ( ! is_array( $old_linked_ids ) ) $old_linked_ids = array();

        $added_links = array_diff( $linked_post_ids, $old_linked_ids );
        $removed_links = array_diff( $old_linked_ids, $linked_post_ids );

        // Update the current post's outgoing and external data
        update_post_meta( $post_id, '_si_linked_to', $linked_post_ids );
        update_post_meta( $post_id, '_si_outgoing_links', count( $linked_post_ids ) );
        update_post_meta( $post_id, '_si_external_links', $external_links_count );

        // Increment incoming counts for new links
        foreach ( $added_links as $id ) {
            $current_incoming = (int) get_post_meta( $id, '_si_incoming_links', true );
            update_post_meta( $id, '_si_incoming_links', $current_incoming + 1 );
        }

        // Decrement incoming counts for removed links
        foreach ( $removed_links as $id ) {
            $current_incoming = (int) get_post_meta( $id, '_si_incoming_links', true );
            update_post_meta( $id, '_si_incoming_links', max( 0, $current_incoming - 1 ) );
        }
    }

    /**
     * Remove incoming link counts when a post is trashed or unpublished
     */
    public static function process_links_on_trash( $post_id ) {
        $old_linked_ids = get_post_meta( $post_id, '_si_linked_to', true );
        if ( ! is_array( $old_linked_ids ) ) return;

        foreach ( $old_linked_ids as $id ) {
            $current_incoming = (int) get_post_meta( $id, '_si_incoming_links', true );
            update_post_meta( $id, '_si_incoming_links', max( 0, $current_incoming - 1 ) );
        }
        
        // We do not clear _si_linked_to so we can restore it if untrashed
        update_post_meta( $post_id, '_si_was_trashed', '1' );
    }

    /**
     * Restore incoming link counts when a post is untrashed
     */
    public static function process_links_on_restore( $post_id ) {
        $was_trashed = get_post_meta( $post_id, '_si_was_trashed', true );
        if ( ! $was_trashed ) return;

        $old_linked_ids = get_post_meta( $post_id, '_si_linked_to', true );
        if ( ! is_array( $old_linked_ids ) ) return;

        foreach ( $old_linked_ids as $id ) {
            $current_incoming = (int) get_post_meta( $id, '_si_incoming_links', true );
            update_post_meta( $id, '_si_incoming_links', $current_incoming + 1 );
        }
        
        delete_post_meta( $post_id, '_si_was_trashed' );
    }

    /* --- List Table Columns --- */

    public static function add_columns( $columns ) {
        $columns['si_incoming_links'] = '<span class="dashicons dashicons-admin-links" title="Incoming Internal Links"></span> IN';
        $columns['si_outgoing_links'] = '<span class="dashicons dashicons-external" title="Outgoing Internal Links"></span> OUT';
        $columns['si_external_links'] = '<span class="dashicons dashicons-external" style="color:#d63638;" title="External Links"></span> EXT';
        return $columns;
    }

    public static function render_columns( $column_name, $post_id ) {
        if ( $column_name === 'si_incoming_links' ) {
            $incoming = get_post_meta( $post_id, '_si_incoming_links', true );
            if ( $incoming === '' ) $incoming = '0';
            
            if ( $incoming == '0' ) {
                echo '<strong style="color: #d63638;" title="Orphaned Content! No other posts link to this.">0</strong>';
            } else {
                echo '<strong>' . esc_html( $incoming ) . '</strong>';
            }
        }
        
        if ( $column_name === 'si_outgoing_links' ) {
            $outgoing = get_post_meta( $post_id, '_si_outgoing_links', true );
            if ( $outgoing === '' ) $outgoing = '0';
            echo esc_html( $outgoing );
        }

        if ( $column_name === 'si_external_links' ) {
            $external = get_post_meta( $post_id, '_si_external_links', true );
            if ( $external === '' ) $external = '0';
            echo esc_html( $external );
        }
    }

    public static function sortable_columns( $columns ) {
        $columns['si_incoming_links'] = 'si_incoming_links';
        $columns['si_outgoing_links'] = 'si_outgoing_links';
        $columns['si_external_links'] = 'si_external_links';
        return $columns;
    }

    /* --- Filter for Orphaned Content --- */

    public static function add_orphaned_filter( $post_type ) {
        if ( in_array( $post_type, array( 'post', 'page' ) ) ) {
            $selected = isset( $_GET['si_orphaned'] ) ? $_GET['si_orphaned'] : '';
            ?>
            <select name="si_orphaned">
                <option value="">All SEO Content</option>
                <option value="1" <?php selected( $selected, '1' ); ?>>Orphaned Content (0 Incoming Links)</option>
            </select>
            <?php
        }
    }

    public static function filter_orphaned_posts( $query ) {
        global $pagenow;
        if ( is_admin() && $pagenow === 'edit.php' && isset( $_GET['si_orphaned'] ) && $_GET['si_orphaned'] === '1' && $query->is_main_query() ) {
            $meta_query = $query->get( 'meta_query' );
            if ( ! is_array( $meta_query ) ) {
                $meta_query = array();
            }
            
            // Look for posts with 0 incoming links or where the meta key doesn't even exist yet
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key' => '_si_incoming_links',
                    'value' => '0',
                    'compare' => '='
                ),
                array(
                    'key' => '_si_incoming_links',
                    'compare' => 'NOT EXISTS'
                )
            );
            
            $query->set( 'meta_query', $meta_query );
        }
    }

    /* --- Recalculate Tools --- */

    public static function admin_notice_recalculate() {
        global $pagenow;
        if ( $pagenow !== 'edit.php' ) return;

        $has_run = get_option( 'si_initial_link_scan_done' );
        if ( ! $has_run ) {
            ?>
            <div class="notice notice-info is-dismissible" id="si-recalc-notice">
                <p><strong>SEO Inspector:</strong> Your IN, OUT, and EXT link columns are currently showing 0 because your posts haven't been scanned yet. <button type="button" class="button button-primary" id="si-run-link-scan">Scan Links Now</button></p>
            </div>
            <?php
        }
    }

    public static function recalculate_script() {
        global $pagenow;
        if ( $pagenow !== 'edit.php' ) return;
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('#si-run-link-scan').on('click', function() {
                var $btn = $(this);
                $btn.prop('disabled', true).text('Scanning posts (0%)...');
                
                function processBatch(page) {
                    $.post(ajaxurl, {
                        action: 'si_recalculate_links',
                        nonce: '<?php echo wp_create_nonce("si_recalculate_nonce"); ?>',
                        paged: page
                    }, function(response) {
                        if (response.success) {
                            if (response.data.has_more) {
                                var percentage = Math.round((response.data.current_page / response.data.total_pages) * 100);
                                $btn.text('Scanning posts (' + percentage + '%)...');
                                processBatch(response.data.current_page + 1);
                            } else {
                                $btn.text('Done!');
                                setTimeout(function(){ location.reload(); }, 1000);
                            }
                        } else {
                            alert('An error occurred. Try refreshing the page.');
                            $btn.prop('disabled', false).text('Scan Links Now');
                        }
                    }).fail(function() {
                        alert('A network error occurred. Try refreshing the page.');
                        $btn.prop('disabled', false).text('Scan Links Now');
                    });
                }
                
                processBatch(1);
            });
        });
        </script>
        <?php
    }

    public static function ajax_recalculate_links() {
        check_ajax_referer( 'si_recalculate_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $paged = isset( $_POST['paged'] ) ? max( 1, intval( $_POST['paged'] ) ) : 1;
        $posts_per_page = 50;

        global $wpdb;

        // Only clear meta on the first batch to avoid double counting
        if ( $paged === 1 ) {
            $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_si_incoming_links'" );
        }

        $query = new WP_Query( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged,
            'fields'         => 'ids'
        ));

        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post_id ) {
                self::process_links_on_save( $post_id );
            }
        }

        $has_more = $paged < $query->max_num_pages;
        
        if ( ! $has_more ) {
            update_option( 'si_initial_link_scan_done', '1' );
        }

        wp_send_json_success( array(
            'current_page' => $paged,
            'total_pages'  => max( 1, $query->max_num_pages ),
            'has_more'     => $has_more
        ));
    }
}
