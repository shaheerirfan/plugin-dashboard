<?php
/**
 * SEO Inspector Analytics Dashboard Class
 * Displays GSC/GA data in a premium UI.
 */

class SI_Analytics_Dashboard {
    public static function init() {
        // Menu registered centrally in seo-inspector.php
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    public static function render_analytics_page() {
        ?>
        <div id="si-dashboard">
            <header class="si-header left" style="margin-bottom: 40px; border-bottom: none; padding-bottom: 0;">
                <h1 style="font-size: 3.5rem; line-height: 1.1; margin-bottom: 10px;">Search Analytics & Web Vitals</h1>
                <p style="font-size: 1.1rem; color: #64748b;">Track your site performance across Google Search Console and Core Web Vitals.</p>
            </header>

            <!-- Core Web Vitals Section -->
            <?php 
            require_once ABSOLUTE_PATH . 'includes/class-web-vitals.php';
            $cwv_data = SI_Web_Vitals::fetch_cwv_data();
            $cwv_score = isset($cwv_data['Score']) ? $cwv_data['Score'] : 0;
            $cwv_color = $cwv_score >= 90 ? '#10b981' : ($cwv_score >= 50 ? '#f59e0b' : '#ef4444');
            ?>
            <div class="si-main-card left" style="margin-bottom: 40px; border-top: 4px solid <?php echo $cwv_color; ?>;">
                <h3>Core Web Vitals</h3>
                <?php if ( isset( $cwv_data['status'] ) && $cwv_data['status'] === 'Needs API Key' ) : ?>
                    <p><em>Please configure your PageSpeed API key in settings to fetch real data. Showing placeholder values.</em></p>
                <?php endif; ?>
                
                <div style="display: flex; gap: 30px; align-items: center; margin-top: 20px;">
                    <div style="text-align: center; width: 150px;">
                        <div style="font-size: 3.5rem; font-weight: 800; color: <?php echo $cwv_color; ?>;"><?php echo esc_html( $cwv_score ); ?></div>
                        <div style="font-size: 0.9rem; color: #64748b; font-weight: bold; text-transform: uppercase;">Performance Score</div>
                    </div>
                    <div style="flex-grow: 1; display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div style="background: #f8fafc; padding: 15px; border-radius: 8px;">
                            <div style="font-size: 0.8rem; color: #64748b; text-transform: uppercase;">Largest Contentful Paint (LCP)</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #0f172a;"><?php echo esc_html( $cwv_data['LCP'] ?? 'N/A' ); ?></div>
                        </div>
                        <div style="background: #f8fafc; padding: 15px; border-radius: 8px;">
                            <div style="font-size: 0.8rem; color: #64748b; text-transform: uppercase;">First Input Delay (FID)</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #0f172a;"><?php echo esc_html( $cwv_data['FID'] ?? 'N/A' ); ?></div>
                        </div>
                        <div style="background: #f8fafc; padding: 15px; border-radius: 8px;">
                            <div style="font-size: 0.8rem; color: #64748b; text-transform: uppercase;">Cumulative Layout Shift (CLS)</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #0f172a;"><?php echo esc_html( $cwv_data['CLS'] ?? 'N/A' ); ?></div>
                        </div>
                        <div style="background: #f8fafc; padding: 15px; border-radius: 8px;">
                            <div style="font-size: 0.8rem; color: #64748b; text-transform: uppercase;">First Contentful Paint (FCP)</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #0f172a;"><?php echo esc_html( $cwv_data['FCP'] ?? 'N/A' ); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metrics Overview -->
            <div class="si-analytics-metrics">
                <div class="si-metric-card">
                    <span class="si-metric-label">Total Clicks</span>
                    <span class="si-metric-value">12.4K</span>
                    <span class="si-metric-change up">+14.2%</span>
                </div>
                <div class="si-metric-card">
                    <span class="si-metric-label">Total Impressions</span>
                    <span class="si-metric-value">450K</span>
                    <span class="si-metric-change up">+8.5%</span>
                </div>
                <div class="si-metric-card">
                    <span class="si-metric-label">Avg. CTR</span>
                    <span class="si-metric-value">2.8%</span>
                    <span class="si-metric-change down">-0.4%</span>
                </div>
                <div class="si-metric-card">
                    <span class="si-metric-label">Avg. Position</span>
                    <span class="si-metric-value">14.2</span>
                    <span class="si-metric-change up">+2.1</span>
                </div>
            </div>

            <!-- Charts Section -->
            <div class="si-main-card left" style="padding:30px;">
                <h3 style="margin-top:0;">Performance Over Time</h3>
                <canvas id="si-performance-chart" height="100"></canvas>
            </div>

            <div class="si-analytics-secondary-grid">
                <!-- Top Queries -->
                <div class="si-main-card left">
                    <h3>Top Keywords</h3>
                    <table class="si-premium-table">
                        <thead><tr><th>Keyword</th><th>Clicks</th><th style="width: 80px; text-align: right !important;">Pos.</th></tr></thead>
                        <tbody>
                            <tr><td>real estate studio</td><td>1,240</td><td style="text-align: right !important;">1.2</td></tr>
                            <tr><td>modern home design</td><td>850</td><td style="text-align: right !important;">3.4</td></tr>
                            <tr><td>luxury penthouses</td><td>620</td><td style="text-align: right !important;">4.1</td></tr>
                            <tr><td>property inspector wp</td><td>410</td><td style="text-align: right !important;">2.8</td></tr>
                        </tbody>
                    </table>
                </div>
                <!-- Top Pages -->
                <div class="si-main-card left">
                    <h3>Top Performing Pages</h3>
                    <table class="si-premium-table">
                        <thead><tr><th>Page URI</th><th>Clicks</th><th style="width: 80px; text-align: right !important;">CTR</th></tr></thead>
                        <tbody>
                            <tr><td>/home-office-trends/</td><td>1,420</td><td style="text-align: right !important;">4.2%</td></tr>
                            <tr><td>/best-real-estate-tips/</td><td>1,100</td><td style="text-align: right !important;">3.8%</td></tr>
                            <tr><td>/contact-us/</td><td>950</td><td style="text-align: right !important;">5.1%</td></tr>
                            <tr><td>/properties/list/</td><td>820</td><td style="text-align: right !important;">2.9%</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public static function enqueue_assets( $hook ) {
        if ( 'seo-inspector_page_si-analytics' !== $hook ) return;

        wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '4.4.1', true );
        wp_enqueue_style( 'si-analytics-styles', plugins_url( '../assets/css/styles.css', __FILE__ ), array(), time() );
        wp_enqueue_script( 'si-analytics-js', plugins_url( '../assets/js/analytics.js', __FILE__ ), array( 'chart-js', 'jquery' ), time(), true );
    }
}
