<?php
/**
 * SEO Inspector Link Suggestions
 * Provides AI-based / Keyword-based internal linking suggestions.
 */

class SI_Link_Suggestions {
    public static function init() {
        add_action( 'wp_ajax_si_get_link_suggestions', array( __CLASS__, 'get_suggestions' ) );
    }

    public static function get_suggestions() {
        check_ajax_referer( 'si_meta_box_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( 'Unauthorized' );
        }

        $post_id = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;
        $keywords_raw = isset( $_POST['keywords'] ) ? sanitize_text_field( $_POST['keywords'] ) : '';
        $title = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';

        // Extract words from keywords and title
        $search_terms = array_filter( explode( ',', $keywords_raw ) );
        if ( empty( $search_terms ) && ! empty( $title ) ) {
            // Very basic stopword removal for title fallback
            $stopwords = array('the','a','an','and','or','but','in','on','at','to','for','with','by','about','like','through','over','before','between','after','since','without','under','within','along','following','across','behind','beyond','plus','except','but','up','out','around','down','off','above','near');
            $words = explode( ' ', strtolower( $title ) );
            $filtered = array_diff( $words, $stopwords );
            $search_terms = array_filter( $filtered, function($w) { return strlen($w) > 3; } );
        }

        if ( empty( $search_terms ) ) {
            wp_send_json_success( array() );
        }

        global $wpdb;
        
        // Build a robust LIKE query for multiple terms
        $where_clauses = array();
        foreach ( $search_terms as $term ) {
            $like = '%' . $wpdb->esc_like( trim( $term ) ) . '%';
            // Search in title, content, or our focus keywords meta
            $where_clauses[] = $wpdb->prepare( "(p.post_title LIKE %s OR p.post_content LIKE %s OR pm.meta_value LIKE %s)", $like, $like, $like );
        }

        $where_sql = implode( ' OR ', $where_clauses );

        $query = "
            SELECT DISTINCT p.ID, p.post_title 
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON (p.ID = pm.post_id AND pm.meta_key = '_si_focus_keywords')
            WHERE p.post_type IN ('post', 'page')
            AND p.post_status = 'publish'
            AND p.ID != %d
            AND ($where_sql)
            ORDER BY p.post_date DESC
            LIMIT 5
        ";

        $results = $wpdb->get_results( $wpdb->prepare( $query, $post_id ) );

        $suggestions = array();
        if ( $results ) {
            foreach ( $results as $r ) {
                $suggestions[] = array(
                    'id'    => $r->ID,
                    'title' => $r->post_title,
                    'url'   => get_permalink( $r->ID )
                );
            }
        }

        wp_send_json_success( $suggestions );
    }
}
