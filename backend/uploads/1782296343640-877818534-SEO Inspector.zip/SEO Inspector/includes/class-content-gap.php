<?php
/**
 * SEO Inspector Content Gap Analyzer
 * Analyzes existing focus keywords and uses AI to suggest missing topics.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Content_Gap {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_submenu' ), 20 );
        add_action( 'wp_ajax_si_analyze_content_gap', array( __CLASS__, 'ajax_analyze_gap' ) );
    }

    public static function add_submenu() {
        add_submenu_page(
            'seo-inspector',
            'Content Gap',
            'Content Gap',
            'manage_options',
            'si-content-gap',
            array( __CLASS__, 'render_page' )
        );
    }

    public static function render_page() {
        $nonce = wp_create_nonce( 'si_content_gap_nonce' );
        ?>
        <div class="wrap si-page-wrap">
            <h1>Content Gap Analyzer (AI)</h1>
            <p>We analyze your site's current focus keywords and use AI to identify semantic gaps—topics your competitors might be ranking for that you are missing.</p>

            <div class="si-settings-card" style="max-width: 800px; margin-top: 20px;">
                <button id="si-start-gap-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>">
                    <span class="dashicons dashicons-lightbulb" style="vertical-align: middle;"></span> Find Missing Topics
                </button>
                
                <div id="si-gap-results" style="display:none; margin-top: 30px; background: #f8fafc; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0; line-height: 1.6; color: #334155;">
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#si-start-gap-btn').on('click', function() {
                var $btn = $(this);
                var nonce = $btn.data('nonce');
                
                var originalText = $btn.html();
                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 2s linear infinite; vertical-align: middle;"></span> Analyzing Site...');
                $('#si-gap-results').hide().empty();
                
                $.post(ajaxurl, {
                    action: 'si_analyze_content_gap',
                    nonce: nonce
                }, function(response) {
                    if (response.success) {
                        $('#si-gap-results').html(response.data.replace(/\n/g, '<br>')).slideDown();
                    } else {
                        alert('Error: ' + response.data);
                    }
                }).fail(function() {
                    alert('Server communication error.');
                }).always(function() {
                    $btn.prop('disabled', false).html(originalText);
                });
            });
        });
        </script>
        <?php
    }

    public static function ajax_analyze_gap() {
        check_ajax_referer( 'si_content_gap_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        global $wpdb;
        $query = "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_si_focus_keywords' AND meta_value != '' LIMIT 50";
        $results = $wpdb->get_col( $query );
        
        $keywords = array_filter( array_unique( $results ) );
        if ( empty( $keywords ) ) {
            wp_send_json_error( 'Not enough focus keywords found on your site to analyze a content gap. Please optimize some posts first.' );
        }

        $context = implode( ', ', $keywords );
        $prompt = "You are an expert SEO strategist. Here are the main SEO keywords this website is currently targeting: \n\n" . $context . "\n\nAnalyze this semantic cluster. Identify the overarching niche, and suggest 10 high-value, low-competition 'Content Gaps' (topics or keywords) that this website is missing but absolutely should write about to build topical authority. Format the output nicely.";

        require_once ABSOLUTE_PATH . 'includes/class-ai-helpers.php';
        $provider = SI_AI_Manager::get_provider();

        $response = $provider->generate_text( $prompt, 'You are an expert SEO strategist.' );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( $response->get_error_message() );
        }

        wp_send_json_success( $response );
    }
}
