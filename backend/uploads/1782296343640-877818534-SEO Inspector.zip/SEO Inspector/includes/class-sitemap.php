<?php
/**
 * SEO Inspector Sitemap Class
 * Dynamically generates paginated XML sitemaps for posts, taxonomies, authors, and images.
 */

class SI_Sitemap {
    public static function init() {
        add_action( 'init', array( __CLASS__, 'add_rewrite_rules' ) );
        add_filter( 'query_vars', array( __CLASS__, 'add_query_vars' ) );
        add_action( 'template_redirect', array( __CLASS__, 'render_sitemap' ) );
    }

    public static function add_rewrite_rules() {
        add_rewrite_rule( 'sitemap_index\.xml$', 'index.php?si_sitemap=index', 'top' );
        add_rewrite_rule( 'sitemap\.xml$', 'index.php?si_sitemap=index', 'top' );
        add_rewrite_rule( '([a-z0-9_-]+)-sitemap-([0-9]+)\.xml$', 'index.php?si_sitemap=$matches[1]&si_sitemap_page=$matches[2]', 'top' );
        add_rewrite_rule( '([a-z0-9_-]+)-sitemap\.xml$', 'index.php?si_sitemap=$matches[1]', 'top' );
    }

    public static function add_query_vars( $vars ) {
        $vars[] = 'si_sitemap';
        $vars[] = 'si_sitemap_page';
        return $vars;
    }

    public static function render_sitemap() {
        if ( is_admin() || ! get_query_var( 'si_sitemap' ) ) {
            return;
        }

        $sitemap_type = get_query_var( 'si_sitemap' );
        $page = get_query_var( 'si_sitemap_page' ) ? intval( get_query_var( 'si_sitemap_page' ) ) : 1;
        $limit = 1000;

        $allowed_post_types = get_option( 'si_sitemap_post_types', array( 'post', 'page' ) );
        if ( empty( $allowed_post_types ) || ! is_array( $allowed_post_types ) ) {
            $allowed_post_types = array( 'post', 'page' );
        }

        if ( ob_get_length() ) ob_clean();
        header( 'Content-Type: application/xml; charset=utf-8' );
        echo '<?xml version="1.0" encoding="UTF-8"?>';
        
        $xsl_url = plugins_url( 'assets/css/sitemap.xsl', dirname( __FILE__, 2 ) . '/seo-inspector.php' );
        echo '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl_url ) . '"?>' . "\n";

        // 1. Render Sitemap Index
        if ( $sitemap_type === 'index' || $sitemap_type === '1' ) {
            echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            
            // Loop through post types
            foreach ( $allowed_post_types as $pt ) {
                $total_posts = wp_count_posts( $pt );
                $published_count = isset( $total_posts->publish ) ? intval( $total_posts->publish ) : 0;
                if ( $published_count === 0 ) continue;

                $pages_count = ceil( $published_count / $limit );
                for ( $i = 1; $i <= $pages_count; $i++ ) {
                    $page_suffix = $pages_count > 1 ? "-{$i}" : '';
                    echo '  <sitemap>' . "\n";
                    echo '    <loc>' . esc_url( home_url( "/{$pt}-sitemap{$page_suffix}.xml" ) ) . '</loc>' . "\n";
                    
                    $latest = get_posts( array( 'post_type' => $pt, 'posts_per_page' => 1, 'post_status' => 'publish' ) );
                    if ( ! empty( $latest ) ) {
                        echo '    <lastmod>' . get_the_modified_date( 'c', $latest[0]->ID ) . '</lastmod>' . "\n";
                    } else {
                        echo '    <lastmod>' . date( 'c' ) . '</lastmod>' . "\n";
                    }
                    echo '  </sitemap>' . "\n";
                }
            }

            // Loop through taxonomies
            $taxonomies = array( 'category', 'post_tag' );
            foreach ( $taxonomies as $tax ) {
                $total_terms = wp_count_terms( array( 'taxonomy' => $tax, 'hide_empty' => true ) );
                if ( is_wp_error( $total_terms ) || $total_terms == 0 ) continue;

                $pages_count = ceil( $total_terms / $limit );
                for ( $i = 1; $i <= $pages_count; $i++ ) {
                    $page_suffix = $pages_count > 1 ? "-{$i}" : '';
                    echo '  <sitemap>' . "\n";
                    echo '    <loc>' . esc_url( home_url( "/{$tax}-sitemap{$page_suffix}.xml" ) ) . '</loc>' . "\n";
                    echo '    <lastmod>' . date( 'c' ) . '</lastmod>' . "\n";
                    echo '  </sitemap>' . "\n";
                }
            }

            // Author sitemap
            $total_authors = count( get_users( array( 'capability' => array( 'edit_posts' ), 'fields' => 'ID' ) ) );
            if ( $total_authors > 0 ) {
                $pages_count = ceil( $total_authors / $limit );
                for ( $i = 1; $i <= $pages_count; $i++ ) {
                    $page_suffix = $pages_count > 1 ? "-{$i}" : '';
                    echo '  <sitemap>' . "\n";
                    echo '    <loc>' . esc_url( home_url( "/author-sitemap{$page_suffix}.xml" ) ) . '</loc>' . "\n";
                    echo '    <lastmod>' . date( 'c' ) . '</lastmod>' . "\n";
                    echo '  </sitemap>' . "\n";
                }
            }

            echo '</sitemapindex>';
            exit;
        }

        // 2. Render Taxonomy Sitemap
        if ( in_array( $sitemap_type, array( 'category', 'post_tag' ) ) ) {
            $terms = get_terms( array(
                'taxonomy'   => $sitemap_type,
                'hide_empty' => true,
                'number'     => $limit,
                'offset'     => ( $page - 1 ) * $limit
            ) );

            if ( empty( $terms ) || is_wp_error( $terms ) ) {
                self::render_404();
                return;
            }

            echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            foreach ( $terms as $term ) {
                echo '  <url>' . "\n";
                echo '    <loc>' . esc_url( get_term_link( $term ) ) . '</loc>' . "\n";
                echo '    <changefreq>weekly</changefreq>' . "\n";
                echo '    <priority>0.5</priority>' . "\n";
                echo '  </url>' . "\n";
            }
            echo '</urlset>';
            exit;
        }

        // 3. Render Author Sitemap
        if ( $sitemap_type === 'author' ) {
            $authors = get_users( array(
                'capability' => array( 'edit_posts' ),
                'number'     => $limit,
                'offset'     => ( $page - 1 ) * $limit
            ) );

            if ( empty( $authors ) ) {
                self::render_404();
                return;
            }

            echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            foreach ( $authors as $author ) {
                echo '  <url>' . "\n";
                echo '    <loc>' . esc_url( get_author_posts_url( $author->ID ) ) . '</loc>' . "\n";
                echo '    <changefreq>weekly</changefreq>' . "\n";
                echo '    <priority>0.5</priority>' . "\n";
                echo '  </url>' . "\n";
            }
            echo '</urlset>';
            exit;
        }

        // 4. Render Post Type Sitemap (with Images)
        if ( in_array( $sitemap_type, $allowed_post_types ) ) {
            $posts = get_posts( array(
                'post_type'      => $sitemap_type,
                'post_status'    => 'publish',
                'posts_per_page' => $limit,
                'offset'         => ( $page - 1 ) * $limit,
                'orderby'        => 'modified',
                'order'          => 'DESC'
            ) );

            if ( empty( $posts ) ) {
                self::render_404();
                return;
            }

            echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";

            foreach ( $posts as $post ) {
                // Skip posts marked as noindex
                $robots = get_post_meta( $post->ID, '_si_robots', true ) ?: array();
                $robots_index = get_post_meta( $post->ID, '_si_robots_index', true );
                if ( in_array( 'noindex', $robots ) || $robots_index === 'noindex' ) {
                    continue;
                }

                echo '  <url>' . "\n";
                echo '    <loc>' . esc_url( get_permalink( $post->ID ) ) . '</loc>' . "\n";
                echo '    <lastmod>' . get_the_modified_date( 'c', $post->ID ) . '</lastmod>' . "\n";
                echo '    <changefreq>weekly</changefreq>' . "\n";
                echo '    <priority>0.8</priority>' . "\n";

                // Parse and append post images
                $images = array();
                
                // Add featured image
                if ( has_post_thumbnail( $post->ID ) ) {
                    $thumb_id = get_post_thumbnail_id( $post->ID );
                    $thumb_url = wp_get_attachment_image_url( $thumb_id, 'full' );
                    if ( $thumb_url ) {
                        $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
                        $images[] = array(
                            'url' => $thumb_url,
                            'title' => $alt ?: $post->post_title
                        );
                    }
                }

                // Add content images
                if ( preg_match_all( '/<img[^>]+src=["\']([^"\']+)["\']/i', $post->post_content, $img_matches ) ) {
                    foreach ( $img_matches[1] as $idx => $url ) {
                        if ( strpos( $url, 'data:' ) === 0 ) continue; // Skip inline images
                        
                        $caption = '';
                        if ( preg_match( '/alt=["\']([^"\']+)["\']/i', $img_matches[0][$idx], $alt_match ) ) {
                            $caption = trim( $alt_match[1] );
                        }
                        $images[] = array(
                            'url' => esc_url( $url ),
                            'title' => $caption ?: $post->post_title
                        );
                    }
                }

                // De-duplicate images by URL
                $unique_images = array();
                foreach ( $images as $img ) {
                    $unique_images[$img['url']] = $img;
                }

                foreach ( $unique_images as $img ) {
                    echo '    <image:image>' . "\n";
                    echo '      <image:loc>' . esc_url( $img['url'] ) . '</image:loc>' . "\n";
                    if ( ! empty( $img['title'] ) ) {
                        echo '      <image:title>' . esc_xml( $img['title'] ) . '</image:title>' . "\n";
                    }
                    echo '    </image:image>' . "\n";
                }

                echo '  </url>' . "\n";
            }

            echo '</urlset>';
            exit;
        }

        self::render_404();
    }

    private static function render_404() {
        global $wp_query;
        $wp_query->set_404();
        status_header( 404 );
        nocache_headers();
    }

    public static function flush_rules() {
        self::add_rewrite_rules();
        flush_rewrite_rules();
    }
}
