<?php
/**
 * Master SEO Analyzer Class
 * Exhaustive checklist implementation.
 */

class SI_SEO_Analyzer {
    private $url;
    private $html;
    private $headers;
    private $issues = array();
    private $score = 100;
    private $start_time;

    public function __construct( $url ) {
        $this->url = $url;
    }

    public function analyze() {
        $this->start_time = microtime( true );
        $response = wp_remote_get( $this->url, array( 'timeout' => 15, 'sslverify' => false ) );
        
        if ( is_wp_error( $response ) ) {
            return array(
                'url'    => $this->url,
                'score'  => 0,
                'issues' => array( array( 'type' => 'critical', 'message' => 'Could not fetch page content: ' . $response->get_error_message() ) )
            );
        }

        $this->html = wp_remote_retrieve_body( $response );
        $this->headers = wp_remote_retrieve_headers( $response );
        $load_time = round( ( microtime( true ) - $this->start_time ) * 1000 );

        // --- 1. CORE ON-PAGE ---
        $this->check_title();
        $this->check_meta_description();
        $this->check_h1();
        $this->check_headings_hierarchy();
        $this->check_content_length();
        $this->check_images_alt();
        $this->check_multiple_keywords();
        $this->check_readability();

        // --- 2. TECHNICAL HTML ---
        $this->check_html_lang();
        $this->check_charset();
        $this->check_viewport();
        $this->check_canonical();
        $this->check_favicon();

        // --- 3. TECHNICAL SERVER & PERFORMANCE ---
        $this->check_https();
        $this->check_robots_txt();
        $this->check_sitemap();
        $this->check_compression();
        $this->check_page_size();
        $this->add_issue( 'success', "Response Time: {$load_time}ms" );

        // --- 4. SECURITY HEADERS ---
        $this->check_security_headers();

        // --- 5. SEMANTIC & SOCIAL ---
        $this->check_schema();
        $this->check_og_tags();
        $this->check_social_accounts(); // Renamed from Twitter Cards

        // --- 6. LINKING ---
        $this->check_links_distribution();

        // --- 7. EXTERNAL SERVICES ---
        $this->check_gsc_tag();
        $this->check_analytics_tag();

        return array(
            'url'    => $this->url,
            'score'  => max( 0, min( 100, $this->score ) ),
            'issues' => $this->issues
        );
    }

    // --- Core On-Page ---
    private function check_title() {
        if ( preg_match( '/<title>(.*?)<\/title>/is', $this->html, $matches ) ) {
            $title = trim( $matches[1] );
            $len = strlen( $title );
            if ( $len < 30 ) $this->add_issue( 'warning', "Title too short ($len chars). Aim for 50-60.", 5 );
            elseif ( $len > 60 ) $this->add_issue( 'warning', "Title too long ($len chars). Aim for 50-60.", 5 );
            else $this->add_issue( 'success', 'Title tag is perfectly optimized.' );
        } else {
            $this->add_issue( 'critical', 'Missing Title Tag!', 20 );
        }
    }

    private function check_meta_description() {
        if ( preg_match( '/<meta name="description" content="(.*?)"/is', $this->html, $matches ) ) {
            $desc = trim( $matches[1] );
            $len = strlen( $desc );
            if ( $len < 120 ) $this->add_issue( 'warning', "Meta description too short ($len chars).", 5 );
            elseif ( $len > 160 ) $this->add_issue( 'warning', "Meta description too long ($len chars).", 5 );
            else $this->add_issue( 'success', 'Meta description is perfectly optimized.' );
        } else {
            $this->add_issue( 'critical', 'Missing Meta Description!', 15 );
        }
    }

    private function check_h1() {
        $count = preg_match_all( '/<h1[^>]*>(.*?)<\/h1>/is', $this->html, $matches );
        if ( $count === 1 ) $this->add_issue( 'success', 'Single H1 tag found.' );
        elseif ( $count === 0 ) $this->add_issue( 'critical', 'Missing H1 tag!', 15 );
        else $this->add_issue( 'warning', "Multiple H1 tags found ($count).", 10 );
    }

    private function check_headings_hierarchy() {
        preg_match_all( '/<(h[1-6])[^>]*>/i', $this->html, $matches );
        $tags = $matches[1];
        if ( empty( $tags ) ) {
            $this->add_issue( 'warning', 'No heading tags found.', 5 );
            return;
        }
        $prev = 0;
        $broken = false;
        foreach ( $tags as $tag ) {
            $curr = (int) substr( $tag, 1 );
            if ( $curr > $prev + 1 && $prev !== 0 ) $broken = true;
            $prev = $curr;
        }
        if ( $broken ) $this->add_issue( 'warning', 'Heading hierarchy is skipped (e.g., H2 to H4).', 5 );
        else $this->add_issue( 'success', 'Heading hierarchy is logical.' );
    }

    private function check_content_length() {
        $text = strip_tags( $this->html );
        $count = str_word_count( $text );
        
        $post_id = url_to_postid( $this->url );
        $is_cornerstone = false;
        if ( $post_id ) {
            $is_cornerstone = get_post_meta( $post_id, '_si_is_cornerstone', true ) === 'yes';
        }

        $min_words = $is_cornerstone ? 900 : 300;

        if ( $count < $min_words ) {
            $type = $is_cornerstone ? "Cornerstone content requires at least $min_words words." : "Thin content: Only $count words (minimum $min_words).";
            $this->add_issue( 'warning', $type, 10 );
        } else {
            $this->add_issue( 'success', "Content length is good ($count words)." );
        }
    }

    private function check_images_alt() {
        $img_count = preg_match_all( '/<img[^>]+>/i', $this->html, $m );
        $alt_count = preg_match_all( '/<img[^>]+alt=["\']([^"\']+)["\']/i', $this->html, $m );
        if ( $img_count > 0 && $alt_count < $img_count ) {
            $diff = $img_count - $alt_count;
            $this->add_issue( 'warning', "$diff images missing ALT text.", 10 );
        } elseif ( $img_count > 0 ) {
            $this->add_issue( 'success', 'All images have ALT text.' );
        }
    }

    // --- Technical HTML ---
    private function check_html_lang() {
        if ( preg_match( '/<html[^>]+lang=["\']([^"\']+)["\']/i', $this->html, $m ) ) $this->add_issue( 'success', "Language set to: " . strtoupper($m[1]) );
        else $this->add_issue( 'warning', 'HTML lang attribute missing.', 3 );
    }

    private function check_charset() {
        if ( preg_match( '/<meta[^>]+charset=["\']?UTF-8["\']?/i', $this->html ) ) $this->add_issue( 'success', 'Charset is UTF-8.' );
        else $this->add_issue( 'warning', 'UTF-8 Charset not explicitly set.', 2 );
    }

    private function check_viewport() {
        if ( strpos( $this->html, 'name="viewport"' ) !== false ) $this->add_issue( 'success', 'Mobile viewport meta found.' );
        else $this->add_issue( 'critical', 'Missing Viewport Meta (Not Responsive)!', 10 );
    }

    private function check_canonical() {
        if ( strpos( $this->html, 'rel="canonical"' ) !== false ) $this->add_issue( 'success', 'Canonical tag present.' );
        else $this->add_issue( 'warning', 'Missing Canonical tag.', 5 );
    }

    private function check_favicon() {
        if ( strpos( $this->html, 'rel="icon"' ) !== false || strpos( $this->html, 'rel="shortcut icon"' ) !== false ) $this->add_issue( 'success', 'Favicon detected.' );
        else $this->add_issue( 'warning', 'Favicon missing.', 2 );
    }

    // --- Technical Server ---
    private function check_https() {
        if ( strpos( $this->url, 'https://' ) === 0 ) $this->add_issue( 'success', 'Using secure HTTPS connection.' );
        else $this->add_issue( 'critical', 'Insecure HTTP connection!', 15 );
    }

    private function check_robots_txt() {
        $robots_url = get_site_url() . '/robots.txt';
        $res = wp_remote_head( $robots_url );
        if ( ! is_wp_error( $res ) && wp_remote_retrieve_response_code( $res ) === 200 ) $this->add_issue( 'success', 'robots.txt found.' );
        else $this->add_issue( 'warning', 'robots.txt missing or unreachable.', 5 );
    }

    private function check_sitemap() {
        $sitemap_url = get_site_url() . '/sitemap_index.xml';
        $res = wp_remote_head( $sitemap_url );
        if ( ! is_wp_error( $res ) && wp_remote_retrieve_response_code( $res ) === 200 ) $this->add_issue( 'success', 'XML Sitemap found.' );
        else $this->add_issue( 'warning', 'XML Sitemap not found at default location.', 5 );
    }

    private function check_compression() {
        $enc = isset( $this->headers['content-encoding'] ) ? $this->headers['content-encoding'] : '';
        if ( strpos( $enc, 'gzip' ) !== false || strpos( $enc, 'br' ) !== false ) $this->add_issue( 'success', 'GZIP/Brotli compression active.' );
        else $this->add_issue( 'warning', 'Server compression not detected.', 5 );
    }

    private function check_page_size() {
        $size = strlen( $this->html ) / 1024;
        if ( $size > 150 ) $this->add_issue( 'warning', "Page size large (" . round($size) . " KB).", 5 );
        else $this->add_issue( 'success', "Page size optimized (" . round($size) . " KB)." );
    }

    // --- Security Headers ---
    private function check_security_headers() {
        $h = $this->headers;
        if ( isset( $h['strict-transport-security'] ) ) $this->add_issue( 'success', 'HSTS Header active.' );
        if ( isset( $h['x-frame-options'] ) ) $this->add_issue( 'success', 'X-Frame-Options set.' );
        else $this->add_issue( 'warning', 'X-Frame-Options missing (Clickjacking risk).', 2 );
        if ( isset( $h['x-content-type-options'] ) ) $this->add_issue( 'success', 'X-Content-Type-Options: nosniff active.' );
    }

    // --- Semantic & Social ---
    private function check_schema() {
        if ( strpos( $this->html, 'application/ld+json' ) !== false ) $this->add_issue( 'success', 'Schema.org JSON-LD structured data found.' );
        else $this->add_issue( 'warning', 'Missing JSON-LD Schema.', 5 );
    }

    private function check_og_tags() {
        if ( strpos( $this->html, 'property="og:' ) !== false ) $this->add_issue( 'success', 'Open Graph social tags present.' );
        else $this->add_issue( 'warning', 'Missing Open Graph tags.', 5 );
    }

    private function check_social_accounts() {
        if ( strpos( $this->html, 'name="twitter:' ) !== false ) $this->add_issue( 'success', 'Twitter Card social tags found.' );
        else $this->add_issue( 'warning', 'Twitter Card social tags missing.', 5 );
    }

    private function check_links_distribution() {
        preg_match_all( '/<a\s+[^>]*href=["\']([^"\']+)["\']/i', $this->html, $m );
        $links = $m[1];
        $int = 0; $ext = 0;
        $host = parse_url( get_site_url(), PHP_URL_HOST );
        foreach ( $links as $l ) {
            if ( strpos($l, $host) !== false || strpos($l, '/') === 0 ) $int++;
            else $ext++;
        }
        $this->add_issue( 'success', "Links: $int internal, $ext external." );
    }

    // --- External Services ---
    private function check_gsc_tag() {
        if ( preg_match( '/<meta[^>]+name=["\']google-site-verification["\'][^>]+content=["\']([^"\']+)["\']/i', $this->html, $m ) ) {
            $this->add_issue( 'success', "Google Search Console verified (ID: " . esc_html($m[1]) . ")" );
        } elseif ( preg_match( '/<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']google-site-verification["\']/i', $this->html, $m ) ) {
            $this->add_issue( 'success', "Google Search Console verified (ID: " . esc_html($m[1]) . ")" );
        } else {
            $this->add_issue( 'warning', 'Google Search Console tag missing.', 2 );
        }
    }

    private function check_analytics_tag() {
        $found = false;
        // Check for gtag.js
        if ( preg_match( '/googletagmanager\.com\/gtag\/js\?id=(G-[A-Z0-9]+|UA-[0-9-]+)/i', $this->html, $m ) ) {
            $this->add_issue( 'success', "Google Analytics detected (" . esc_html($m[1]) . ")" );
            $found = true;
        } 
        // Check for older analytics.js
        elseif ( strpos( $this->html, 'google-analytics.com/analytics.js' ) !== false ) {
            $this->add_issue( 'success', "Legacy Google Analytics (analytics.js) detected." );
            $found = true;
        }
        // Check for GTM
        elseif ( preg_match( '/googletagmanager\.com\/gtm\.js\?id=(GTM-[A-Z0-9]+)/i', $this->html, $m ) ) {
            $this->add_issue( 'success', "Google Tag Manager detected (" . esc_html($m[1]) . ")" );
            $found = true;
        }

        if ( ! $found ) {
            $this->add_issue( 'warning', 'Google Analytics or Tag Manager tracking missing.', 5 );
        }
    }

    private function add_issue( $type, $message, $deduction = 0 ) {
        $this->issues[] = array( 'type' => $type, 'message' => $message );
        $this->score -= $deduction;
    }

    // --- Premium Keyword & Readability Audit Logic ---
    
    private function check_multiple_keywords() {
        $post_id = url_to_postid( $this->url );
        if ( ! $post_id ) {
            return;
        }

        $keywords_raw = get_post_meta( $post_id, '_si_focus_keywords', true );
        if ( empty( $keywords_raw ) ) {
            $this->add_issue( 'warning', 'No focus keyphrases configured for this post.', 5 );
            return;
        }

        $keywords = array_filter( array_map( 'trim', explode( ',', $keywords_raw ) ) );
        if ( empty( $keywords ) ) {
            $this->add_issue( 'warning', 'No focus keyphrases configured for this post.', 5 );
            return;
        }

        // Get text representation of body
        $text = strip_tags( $this->html );
        $word_count = str_word_count( $text );
        if ( $word_count === 0 ) $word_count = 1;

        // Parse headings
        preg_match_all( '/<h[1-6][^>]*>(.*?)<\/h[1-6]>/is', $this->html, $heading_matches );
        $headings_text = implode( ' ', $heading_matches[1] );

        // Parse image alt tags
        preg_match_all( '/<img[^>]+alt=["\']([^"\']+)["\']/i', $this->html, $alt_matches );
        $alts_text = implode( ' ', $alt_matches[1] );

        // Title and description checks
        preg_match( '/<title>(.*?)<\/title>/is', $this->html, $title_matches );
        $title_text = isset( $title_matches[1] ) ? $title_matches[1] : '';

        preg_match( '/<meta name="description" content="(.*?)"/is', $this->html, $desc_matches );
        $desc_text = isset( $desc_matches[1] ) ? $desc_matches[1] : '';

        // Get first paragraph / first 100 words
        $intro_text = substr( $text, 0, 1000 ); // First 1000 chars as proxy for intro

        foreach ( $keywords as $kw ) {
            $kw_lower = strtolower( $kw );
            $kw_escaped = preg_quote( $kw_lower, '/' );

            // 1. Keyword density
            $matches_count = preg_match_all( '/\b' . $kw_escaped . '\b/i', strtolower( $text ), $discard );
            $density = ( $matches_count / $word_count ) * 100;

            if ( $density >= 0.5 && $density <= 2.5 ) {
                $this->add_issue( 'success', "Keyphrase '$kw': Density is perfect (" . round( $density, 2 ) . "%)." );
            } elseif ( $density > 2.5 ) {
                $this->add_issue( 'warning', "Keyphrase '$kw': Over-optimized density (" . round( $density, 2 ) . "%). Keep it under 2.5%.", 3 );
            } else {
                $this->add_issue( 'warning', "Keyphrase '$kw': Keyword density is very low (" . round( $density, 2 ) . "%). Aim for 0.5% - 2.5%.", 2 );
            }

            // 2. Headings usage
            if ( preg_match( '/\b' . $kw_escaped . '\b/i', strtolower( $headings_text ) ) ) {
                $this->add_issue( 'success', "Keyphrase '$kw': Found in page subheadings." );
            } else {
                $this->add_issue( 'warning', "Keyphrase '$kw': Missing from subheadings.", 2 );
            }

            // 3. Intro presence
            if ( preg_match( '/\b' . $kw_escaped . '\b/i', strtolower( $intro_text ) ) ) {
                $this->add_issue( 'success', "Keyphrase '$kw': Present in the introduction paragraph." );
            } else {
                $this->add_issue( 'warning', "Keyphrase '$kw': Missing from the introduction paragraph.", 2 );
            }

            // 4. Image ALT usage
            if ( ! empty( $alts_text ) && preg_match( '/\b' . $kw_escaped . '\b/i', strtolower( $alts_text ) ) ) {
                $this->add_issue( 'success', "Keyphrase '$kw': Present in image ALT attributes." );
            } else {
                $this->add_issue( 'warning', "Keyphrase '$kw': Missing from image ALT attributes.", 1 );
            }

            // 5. Title & Desc checks
            if ( preg_match( '/\b' . $kw_escaped . '\b/i', strtolower( $title_text ) ) ) {
                $this->add_issue( 'success', "Keyphrase '$kw': Present in SEO Title." );
            } else {
                $this->add_issue( 'warning', "Keyphrase '$kw': Missing from SEO Title.", 2 );
            }

            if ( preg_match( '/\b' . $kw_escaped . '\b/i', strtolower( $desc_text ) ) ) {
                $this->add_issue( 'success', "Keyphrase '$kw': Present in Meta Description." );
            } else {
                $this->add_issue( 'warning', "Keyphrase '$kw': Missing from Meta Description.", 1 );
            }
        }
    }

    private function check_readability() {
        $text = strip_tags( $this->html );
        $word_count = str_word_count( $text );
        if ( $word_count === 0 ) {
            return;
        }

        $sentences = preg_split( '/[.!?]+(?:\s|$)/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $sentence_count = count( $sentences );
        if ( $sentence_count === 0 ) $sentence_count = 1;

        $paragraphs = preg_split( '/\n\s*\n/', $text, -1, PREG_SPLIT_NO_EMPTY );
        $paragraph_count = count( $paragraphs );
        if ( $paragraph_count === 0 ) $paragraph_count = 1;

        // 1. Paragraph length
        $long_paragraphs = 0;
        foreach ( $paragraphs as $para ) {
            $p_words = str_word_count( $para );
            if ( $p_words > 150 ) {
                $long_paragraphs++;
            }
        }
        if ( $long_paragraphs > 0 ) {
            $this->add_issue( 'warning', "Readability: $long_paragraphs paragraphs contain more than 150 words.", 3 );
        } else {
            $this->add_issue( 'success', "Readability: All paragraphs are of moderate length." );
        }

        // 2. Sentence metrics
        $long_sentences = 0;
        $total_syllables = 0;
        $transition_count = 0;
        $passive_count = 0;
        $consecutive_starts = 0;
        $prev_start_word = '';
        $consecutive_streak = 1;

        $transition_words = array(
            "accordingly", "as a result", "consequently", "for example", "for instance", 
            "however", "therefore", "in addition", "moreover", "meanwhile", "on the other hand", 
            "furthermore", "nevertheless", "first", "second", "third", "finally", "because", 
            "additionally", "similarly", "subsequently", "thereafter", "ultimately", "likewise", 
            "specifically", "indeed", "consequentially", "in contrast", "alternatively"
        );

        $irregular_participles = array(
            "done", "made", "seen", "said", "found", "built", "run", "bought", "held", 
            "drawn", "sung", "lost", "left", "kept", "written", "taken", "known", "given"
        );

        foreach ( $sentences as $sent ) {
            $sent = trim( $sent );
            $s_words = array_filter( explode( ' ', preg_replace( '/[^a-z ]/i', '', strtolower( $sent ) ) ) );
            $s_word_count = count( $s_words );
            if ( $s_word_count > 20 ) {
                $long_sentences++;
            }

            $has_transition = false;
            foreach ( $transition_words as $tw ) {
                if ( strpos( strtolower( $sent ), $tw ) !== false ) {
                    $has_transition = true;
                    break;
                }
            }
            if ( $has_transition ) {
                $transition_count++;
            }

            foreach ( $s_words as $w ) {
                $total_syllables += $this->count_syllables_php( $w );
            }

            $has_passive = false;
            if ( preg_match( '/\b(is|am|are|was|were|be|been|being)\b\s+([a-zA-Z]+ed|[a-zA-Z]+en|[a-zA-Z]+t)\b/i', $sent ) ) {
                $has_passive = true;
            } else {
                foreach ( $irregular_participles as $ip ) {
                    if ( preg_match( '/\b(is|am|are|was|were|be|been|being)\b\s+\b' . $ip . '\b/i', $sent ) ) {
                        $has_passive = true;
                        break;
                    }
                }
            }
            if ( $has_passive ) {
                $passive_count++;
            }

            if ( ! empty( $s_words ) ) {
                $start_w = reset( $s_words );
                if ( $start_w === $prev_start_word ) {
                    $consecutive_streak++;
                    if ( $consecutive_streak >= 3 ) {
                        $consecutive_starts++;
                    }
                } else {
                    $consecutive_streak = 1;
                }
                $prev_start_word = $start_w;
            }
        }

        $asl = $word_count / $sentence_count;
        $asw = $total_syllables / $word_count;
        $flesch = 206.835 - ( 1.015 * $asl ) - ( 84.6 * $asw );
        $flesch = max( 0, min( 100, $flesch ) );

        if ( $flesch >= 60 ) {
            $this->add_issue( 'success', "Flesch Reading Ease: " . round( $flesch, 1 ) . " (easy to read)." );
        } elseif ( $flesch >= 50 ) {
            $this->add_issue( 'warning', "Flesch Reading Ease: " . round( $flesch, 1 ) . " (fairly difficult). Make sentences shorter.", 2 );
        } else {
            $this->add_issue( 'warning', "Flesch Reading Ease: " . round( $flesch, 1 ) . " (difficult to read). Use simpler words.", 4 );
        }

        $pct_long_sent = ( $long_sentences / $sentence_count ) * 100;
        if ( $pct_long_sent > 25 ) {
            $this->add_issue( 'warning', "Readability: " . round( $pct_long_sent, 1 ) . "% of sentences are longer than 20 words.", 3 );
        } else {
            $this->add_issue( 'success', "Readability: Sentence lengths are well optimized." );
        }

        $pct_passive = ( $passive_count / $sentence_count ) * 100;
        if ( $pct_passive > 10 ) {
            $this->add_issue( 'warning', "Readability: " . round( $pct_passive, 1 ) . "% of sentences use passive voice. Aim for less than 10%.", 2 );
        } else {
            $this->add_issue( 'success', "Readability: Passive voice usage is low." );
        }

        $pct_transition = ( $transition_count / $sentence_count ) * 100;
        if ( $pct_transition < 30 ) {
            $this->add_issue( 'warning', "Readability: Only " . round( $pct_transition, 1 ) . "% of sentences use transitions. Try adding more.", 2 );
        } else {
            $this->add_issue( 'success', "Readability: Good use of transition words." );
        }

        if ( $consecutive_starts > 0 ) {
            $this->add_issue( 'warning', "Readability: Found starting consecutive sentences with the same word. Mix up structures.", 2 );
        }
    }

    private function count_syllables_php( $word ) {
        $word = strtolower( trim( $word ) );
        if ( strlen( $word ) <= 3 ) return 1;
        $word = preg_replace( '/(?:es|ed|[^laeiouy]e)$/', '', $word );
        $word = preg_replace( '/^y/', '', $word );
        preg_match_all( '/[aeiouy]{1,2}/', $word, $matches );
        return count( $matches[0] ) ?: 1;
    }
}
