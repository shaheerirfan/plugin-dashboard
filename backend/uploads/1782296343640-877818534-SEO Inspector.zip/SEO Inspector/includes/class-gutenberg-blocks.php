<?php
/**
 * SEO Inspector Gutenberg Blocks Class
 * Registers FAQ and How-To schema blocks.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Gutenberg_Blocks {
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_blocks' ) );
        add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'enqueue_editor_assets' ) );
    }

    public static function register_blocks() {
        register_block_type( 'seo-inspector/faq', array(
            'render_callback' => array( __CLASS__, 'render_faq_block' ),
            'attributes'      => array(
                'questions' => array(
                    'type'    => 'array',
                    'default' => array(
                        array( 'question' => '', 'answer' => '' )
                    )
                )
            )
        ) );

        register_block_type( 'seo-inspector/howto', array(
            'render_callback' => array( __CLASS__, 'render_howto_block' ),
            'attributes'      => array(
                'title'       => array(
                    'type'    => 'string',
                    'default' => ''
                ),
                'description' => array(
                    'type'    => 'string',
                    'default' => ''
                ),
                'steps'       => array(
                    'type'    => 'array',
                    'default' => array(
                        array( 'title' => '', 'content' => '' )
                    )
                )
            )
        ) );
    }

    public static function enqueue_editor_assets() {
        wp_enqueue_script(
            'si-editor-blocks-js',
            plugins_url( 'assets/js/blocks.js', dirname( __FILE__, 2 ) . '/seo-inspector.php' ),
            array( 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components' ),
            time(),
            true
        );
    }

    public static function render_faq_block( $attributes ) {
        $questions = isset( $attributes['questions'] ) ? $attributes['questions'] : array();
        if ( empty( $questions ) ) {
            return '';
        }

        $html = '<div class="si-faq-accordion-block" style="border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; margin: 25px 0;">';
        foreach ( $questions as $q ) {
            $q_text = isset( $q['question'] ) ? sanitize_text_field( $q['question'] ) : '';
            $a_text = isset( $q['answer'] ) ? wp_kses_post( $q['answer'] ) : '';
            
            if ( empty( $q_text ) ) continue;

            $html .= '<div class="si-faq-item-block" style="border-bottom: 1px solid #e2e8f0; padding: 20px; background: #fff;">';
            $html .= '<h4 class="si-faq-question-block" style="margin: 0 0 10px 0; font-size: 1.15rem; font-weight: 700; color: #1e293b;">' . esc_html( $q_text ) . '</h4>';
            $html .= '<div class="si-faq-answer-block" style="font-size: 1rem; color: #475569; line-height: 1.6;">' . $a_text . '</div>';
            $html .= '</div>';
        }
        $html .= '</div>';
        return $html;
    }

    public static function render_howto_block( $attributes ) {
        $title       = isset( $attributes['title'] ) ? sanitize_text_field( $attributes['title'] ) : '';
        $description = isset( $attributes['description'] ) ? sanitize_textarea_field( $attributes['description'] ) : '';
        $steps       = isset( $attributes['steps'] ) ? $attributes['steps'] : array();

        if ( empty( $steps ) ) {
            return '';
        }

        $html = '<div class="si-howto-block-container" style="border: 1px solid #e2e8f0; border-radius: 12px; padding: 30px; background: #f8fafc; margin: 25px 0; font-family: sans-serif;">';
        if ( ! empty( $title ) ) {
            $html .= '<h3 class="si-howto-block-title" style="margin: 0 0 10px 0; font-size: 1.5rem; font-weight: 800; color: #0f172a;">' . esc_html( $title ) . '</h3>';
        }
        if ( ! empty( $description ) ) {
            $html .= '<p class="si-howto-block-description" style="margin: 0 0 20px 0; font-size: 1rem; color: #475569; line-height: 1.5;">' . esc_html( $description ) . '</p>';
        }
        
        $html .= '<ol class="si-howto-block-steps" style="margin: 0; padding-left: 20px; color: #0d64cb; font-weight: 700;">';
        foreach ( $steps as $step ) {
            $step_title = isset( $step['title'] ) ? sanitize_text_field( $step['title'] ) : '';
            $step_content = isset( $step['content'] ) ? wp_kses_post( $step['content'] ) : '';

            if ( empty( $step_title ) ) continue;

            $html .= '<li class="si-howto-block-step" style="margin-bottom: 20px; font-size: 1.1rem; color: #0f172a;">';
            $html .= '<span class="si-howto-step-title" style="font-weight: 700; color: #1e293b;">' . esc_html( $step_title ) . '</span>';
            $html .= '<p class="si-howto-step-content" style="margin: 8px 0 0 0; font-size: 0.95rem; font-weight: 400; color: #475569; line-height: 1.6;">' . $step_content . '</p>';
            $html .= '</li>';
        }
        $html .= '</ol>';
        $html .= '</div>';
        return $html;
    }
}
