<?php
/**
 * SEO Inspector Keyword Cannibalization
 * Scans the database to identify multiple posts competing for the same focus keyword.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Cannibalization {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_submenu' ), 20 );
    }

    public static function add_submenu() {
        add_submenu_page(
            'seo-inspector',
            'Keyword Cannibalization',
            'Cannibalization',
            'manage_options',
            'si-cannibalization',
            array( __CLASS__, 'render_page' )
        );
    }

    public static function render_page() {
        // Query to find duplicate keywords
        global $wpdb;
        
        $query = "
            SELECT meta_value as keyword, COUNT(post_id) as post_count, GROUP_CONCAT(post_id) as post_ids
            FROM {$wpdb->postmeta} pm
            JOIN {$wpdb->posts} p ON p.ID = pm.post_id
            WHERE pm.meta_key = '_si_focus_keywords'
            AND p.post_status = 'publish'
            AND pm.meta_value != ''
            GROUP BY meta_value
            HAVING post_count > 1
            ORDER BY post_count DESC
        ";
        
        $results = $wpdb->get_results( $query );

        ?>
        <div class="wrap si-page-wrap">
            <h1>Keyword Cannibalization Detector</h1>
            <p>Identify instances where multiple pages on your site are competing for the exact same focus keyword. This confuses search engines and dilutes your ranking power.</p>

            <div class="si-settings-card">
                <?php if ( empty( $results ) ) : ?>
                    <p style="color: #10b981; font-weight: bold;">Great job! No keyword cannibalization detected.</p>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Focus Keyword</th>
                                <th>Competing Posts</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $results as $row ) : 
                                // Split comma separated keywords and only check primary
                                $primary_keyword = trim( explode( ',', $row->keyword )[0] );
                                if ( empty( $primary_keyword ) ) continue;

                                $post_ids = explode( ',', $row->post_ids );
                            ?>
                            <tr>
                                <td><strong style="color:#e83e8c; font-size: 1.1em;"><?php echo esc_html( $primary_keyword ); ?></strong></td>
                                <td>
                                    <ul style="margin:0; padding-left:20px; list-style-type:disc;">
                                        <?php foreach ( $post_ids as $pid ) : ?>
                                            <li><a href="<?php echo esc_url( get_edit_post_link( $pid ) ); ?>" target="_blank"><?php echo esc_html( get_the_title( $pid ) ); ?></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </td>
                                <td>
                                    <p class="description">Consider combining these articles or changing the focus keyword on one of them.</p>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
