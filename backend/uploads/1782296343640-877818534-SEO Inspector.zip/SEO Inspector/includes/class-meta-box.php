<?php
/**
 * SEO Inspector Meta Box Class
 * Handles UI and saving logic for post-level SEO (Yoast Clone).
 */

class SI_Meta_Box {
    public static function init() {
        add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
        add_action( 'save_post', array( __CLASS__, 'save_meta_data' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    public static function add_meta_box() {
        $screens = array( 'post', 'page' );
        foreach ( $screens as $screen ) {
            add_meta_box(
                'si_seo_meta_box',
                'SEO Inspector',
                array( __CLASS__, 'render_meta_box' ),
                $screen,
                'normal',
                'high'
            );
        }
    }

    public static function render_meta_box( $post ) {
        wp_nonce_field( 'si_meta_box_nonce', 'si_meta_box_nonce_field' );

        $title       = get_post_meta( $post->ID, '_si_seo_title', true );
        $description = get_post_meta( $post->ID, '_si_meta_description', true );
        $keywords    = get_post_meta( $post->ID, '_si_focus_keywords', true );
        
        // Defaults if empty
        $display_title = $title ?: $post->post_title . ' - ' . get_bloginfo( 'name' );
        $display_url   = get_permalink( $post->ID );
        $slug          = $post->post_name;
        ?>
        <div class="si-mb-container yoast-style">
            <!-- Sidebar Navigation -->
            <div class="si-mb-sidebar">
                <div class="si-mb-tab active" data-tab="si-tab-seo">
                    <span class="si-traffic-light si-light-gray" id="si-overall-seo-light"></span> SEO
                </div>
                <div class="si-mb-tab" data-tab="si-tab-readability">
                    <span class="si-traffic-light si-light-gray" id="si-overall-readability-light"></span> Readability
                </div>
                <div class="si-mb-tab" data-tab="si-tab-schema"><i class="dashicons dashicons-networking"></i> Schema</div>
                <div class="si-mb-tab" data-tab="si-tab-social"><i class="dashicons dashicons-share"></i> Social</div>
                <div class="si-mb-tab" data-tab="si-tab-linking"><i class="dashicons dashicons-admin-links"></i> Internal Linking</div>
            </div>

            <!-- Content Area -->
            <div class="si-mb-content-area">

                <!-- SEO Tab -->
                <div id="si-tab-seo" class="si-tab-content active">
                    
                    <div class="si-mb-field">
                        <label for="si_focus_keywords">Focus keyphrase</label>
                        <div class="si-field-action-group">
                            <div class="si-keywords-input-wrapper" id="si-kw-container">
                                <input type="text" id="si_kw_input" placeholder="Add keyword and press Enter...">
                                <input type="hidden" id="si_focus_keywords" name="si_focus_keywords" value="<?php echo esc_attr( $keywords ); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="si-accordion">
                        <div class="si-accordion-header active">
                            <span>Google preview</span>
                            <span class="dashicons dashicons-arrow-up-alt2"></span>
                        </div>
                        <div class="si-accordion-content" style="display: block;">
                            <div class="si-preview-header">
                                <div class="si-device-toggle">
                                    <button type="button" class="si-device-btn" data-device="mobile"><i class="dashicons dashicons-smartphone"></i> Mobile result</button>
                                    <button type="button" class="si-device-btn active" data-device="desktop"><i class="dashicons dashicons-desktop"></i> Desktop result</button>
                                </div>
                            </div>
                            
                            <div id="si-google-preview" class="si-google-preview-v2">
                                <div class="si-gp-site-info">
                                    <div class="si-gp-favicon">G</div>
                                    <div class="si-gp-breadcrumb"><?php echo esc_url( home_url() ); ?> › <?php echo esc_html( $slug ); ?></div>
                                </div>
                                <div class="si-gp-title-v2" id="si-preview-title"><?php echo esc_html( $display_title ); ?></div>
                                <div class="si-gp-desc-v2" id="si-preview-desc">
                                    <?php echo $description ? esc_html( $description ) : 'Please provide a meta description by editing the snippet below. If you don’t, Google will try to find a relevant part of your content...'; ?>
                                </div>
                            </div>

                            <div class="si-mb-field" style="margin-top: 20px;">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                    <label for="si_seo_title" style="margin:0;">SEO title</label>
                                    <button type="button" class="button si-ai-generate-btn" data-type="title" style="font-size:0.8rem; height:28px; line-height:26px; border-radius:6px; background:#fff; border:1px solid #cbd5e1; font-weight:600;"><span class="dashicons dashicons-lightbulb" style="font-size:14px; width:14px; height:14px; vertical-align:middle; margin-right:3px;"></span>AI Generate</button>
                                </div>
                                <input type="text" id="si_seo_title" name="si_seo_title" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php echo esc_attr( $post->post_title ); ?>">
                                <div class="si-input-progress-bar"><div class="si-input-progress-fill" id="si-title-progress-fill"></div></div>
                            </div>

                            <div class="si-mb-field">
                                <label for="si_post_slug">Slug</label>
                                <input type="text" id="si_post_slug" name="si_post_slug" value="<?php echo esc_attr( $slug ); ?>">
                            </div>

                            <div class="si-mb-field">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                                    <label for="si_meta_description" style="margin:0;">Meta description</label>
                                    <button type="button" class="button si-ai-generate-btn" data-type="description" style="font-size:0.8rem; height:28px; line-height:26px; border-radius:6px; background:#fff; border:1px solid #cbd5e1; font-weight:600;"><span class="dashicons dashicons-lightbulb" style="font-size:14px; width:14px; height:14px; vertical-align:middle; margin-right:3px;"></span>AI Generate</button>
                                </div>
                                <textarea id="si_meta_description" name="si_meta_description" rows="3"><?php echo esc_textarea( $description ); ?></textarea>
                                <div class="si-input-progress-bar"><div class="si-input-progress-fill" id="si-desc-progress-fill"></div></div>
                            </div>
                        </div>
                    </div>

                    <div class="si-accordion">
                        <div class="si-accordion-header active">
                            <span>SEO analysis</span>
                            <span class="si-traffic-light si-light-gray" id="si-seo-analysis-light"></span>
                            <span class="dashicons dashicons-arrow-up-alt2"></span>
                        </div>
                        <div class="si-accordion-content" style="display: block;">
                            <ul id="si-seo-analysis-list" class="si-analysis-list">
                                <!-- Results injected by JS -->
                            </ul>
                        </div>
                    </div>

                    <div class="si-accordion">
                        <div class="si-accordion-header">
                            <span>AI SEO Suggestions</span>
                            <span class="dashicons dashicons-lightbulb" style="color:var(--si-primary);"></span>
                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                        </div>
                        <div class="si-accordion-content">
                            <p style="font-size:0.85rem; color:#64748b; margin-bottom:12px;">Get intelligent, contextual suggestions on how to improve this post's SEO score.</p>
                            <button type="button" id="si-ai-suggestions-btn" class="button button-secondary" style="font-weight:600;"><span class="dashicons dashicons-update" style="font-size:16px; width:16px; height:16px; vertical-align:middle; margin-right:3px;"></span> Generate AI Suggestions</button>
                            <div id="si-ai-suggestions-results" style="margin-top:15px; padding:15px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; display:none; font-size:0.9rem; line-height:1.6; color:var(--si-text);"></div>
                        </div>
                    </div>

                    <div class="si-accordion">
                        <div class="si-accordion-header">
                            <span>Cornerstone content</span>
                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                        </div>
                        <div class="si-accordion-content">
                            <div class="si-mb-field" style="display: flex; align-items: center; gap: 10px;">
                                <label class="si-toggle" style="margin: 0;">
                                    <input type="checkbox" id="si_is_cornerstone" name="si_is_cornerstone" value="yes" <?php checked( get_post_meta( $post->ID, '_si_is_cornerstone', true ), 'yes' ); ?>>
                                    <span class="si-slider"></span>
                                    <span class="si-knob"></span>
                                </label>
                                <div>
                                    <strong style="display: block;">Mark as cornerstone content</strong>
                                    <span style="font-size: 0.85rem; color: #64748b;">Cornerstone content should be the most important, extensive articles on your site.</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="si-accordion">
                        <div class="si-accordion-header">
                            <span>Advanced</span>
                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                        </div>
                        <div class="si-accordion-content">
                            <?php 
                            $robots_index = get_post_meta( $post->ID, '_si_robots_index', true ) ?: 'default';
                            $robots_follow = get_post_meta( $post->ID, '_si_robots_follow', true ) ?: 'default';
                            $robots_advanced = get_post_meta( $post->ID, '_si_robots_advanced', true ) ?: array();
                            ?>
                            <div class="si-mb-field">
                                <label>Allow search engines to show this Post in search results?</label>
                                <select name="si_robots_index">
                                    <option value="default" <?php selected($robots_index, 'default'); ?>>Default for Posts (Yes)</option>
                                    <option value="index" <?php selected($robots_index, 'index'); ?>>Yes</option>
                                    <option value="noindex" <?php selected($robots_index, 'noindex'); ?>>No</option>
                                </select>
                            </div>
                            <div class="si-mb-field">
                                <label>Should search engines follow links on this Post?</label>
                                <select name="si_robots_follow">
                                    <option value="default" <?php selected($robots_follow, 'default'); ?>>Yes</option>
                                    <option value="nofollow" <?php selected($robots_follow, 'nofollow'); ?>>No</option>
                                </select>
                            </div>
                            <div class="si-mb-field">
                                <label>Meta robots advanced</label>
                                <div class="si-checkbox-group" style="margin-top: 8px;">
                                    <label style="display: block; font-weight: normal; margin-bottom: 5px;">
                                        <input type="checkbox" name="si_robots_advanced[]" value="noimageindex" <?php echo in_array('noimageindex', $robots_advanced) ? 'checked' : ''; ?>> No Image Index
                                    </label>
                                    <label style="display: block; font-weight: normal; margin-bottom: 5px;">
                                        <input type="checkbox" name="si_robots_advanced[]" value="noarchive" <?php echo in_array('noarchive', $robots_advanced) ? 'checked' : ''; ?>> No Archive
                                    </label>
                                    <label style="display: block; font-weight: normal; margin-bottom: 5px;">
                                        <input type="checkbox" name="si_robots_advanced[]" value="nosnippet" <?php echo in_array('nosnippet', $robots_advanced) ? 'checked' : ''; ?>> No Snippet
                                    </label>
                                </div>
                            </div>
                            <div class="si-mb-field">
                                <label>Breadcrumbs Title</label>
                                <input type="text" name="si_breadcrumb_title" value="<?php echo esc_attr( get_post_meta( $post->ID, '_si_breadcrumb_title', true ) ); ?>" placeholder="<?php echo esc_attr( $post->post_title ); ?>">
                            </div>
                            <div class="si-mb-field">
                                <label>Canonical URL</label>
                                <input type="url" name="si_canonical_url" value="<?php echo esc_attr( get_post_meta( $post->ID, '_si_canonical_url', true ) ); ?>" placeholder="Leave empty to default to permalink.">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Readability Tab -->
                <div id="si-tab-readability" class="si-tab-content">
                    <div class="si-accordion">
                        <div class="si-accordion-header active">
                            <span>Readability analysis</span>
                            <span class="si-traffic-light si-light-gray" id="si-readability-analysis-light"></span>
                            <span class="dashicons dashicons-arrow-up-alt2"></span>
                        </div>
                        <div class="si-accordion-content" style="display: block;">
                            <ul id="si-readability-analysis-list" class="si-analysis-list">
                                <!-- Results injected by JS -->
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Schema Tab -->
                <div id="si-tab-schema" class="si-tab-content">
                    <p style="font-size: 0.9rem; color: #64748b;">Configure global schema settings and custom JSON-LD definitions for this post.</p>
                    
                    <?php
                    $webpage_type = get_post_meta( $post->ID, '_si_schema_webpage_type', true ) ?: 'WebPage';
                    $article_type = get_post_meta( $post->ID, '_si_schema_article_type', true ) ?: 'Article';
                    ?>
                    <div class="si-mb-field">
                        <label for="si_schema_webpage_type">WebPage Schema Type</label>
                        <select id="si_schema_webpage_type" name="si_schema_webpage_type" style="width:100%; height:40px; border-radius:8px; border:1px solid #cbd5e1; padding:0 10px;">
                            <option value="WebPage" <?php selected( $webpage_type, 'WebPage' ); ?>>Standard WebPage</option>
                            <option value="AboutPage" <?php selected( $webpage_type, 'AboutPage' ); ?>>About Page</option>
                            <option value="ContactPage" <?php selected( $webpage_type, 'ContactPage' ); ?>>Contact Page</option>
                            <option value="FAQPage" <?php selected( $webpage_type, 'FAQPage' ); ?>>FAQ Page</option>
                            <option value="ProfilePage" <?php selected( $webpage_type, 'ProfilePage' ); ?>>Profile Page (Author Bio)</option>
                            <option value="ItemPage" <?php selected( $webpage_type, 'ItemPage' ); ?>>Item Page</option>
                        </select>
                    </div>

                    <div class="si-mb-field">
                        <label for="si_schema_article_type">Article Schema Type</label>
                        <select id="si_schema_article_type" name="si_schema_article_type" style="width:100%; height:40px; border-radius:8px; border:1px solid #cbd5e1; padding:0 10px;">
                            <option value="Article" <?php selected( $article_type, 'Article' ); ?>>Standard Article</option>
                            <option value="BlogPosting" <?php selected( $article_type, 'BlogPosting' ); ?>>Blog Posting</option>
                            <option value="NewsArticle" <?php selected( $article_type, 'NewsArticle' ); ?>>News Article</option>
                            <option value="TechArticle" <?php selected( $article_type, 'TechArticle' ); ?>>Technical Article</option>
                            <option value="None" <?php selected( $article_type, 'None' ); ?>>None (No Article Schema)</option>
                        </select>
                    </div>

                    <div class="si-mb-field">
                        <label>Custom Schema (JSON-LD)</label>
                        <textarea id="si_custom_schema" name="si_custom_schema" rows="8" placeholder='{ "@context": "https://schema.org", "@type": "Article", ... }' style="font-family: monospace;"><?php echo esc_textarea( get_post_meta( $post->ID, '_si_custom_schema', true ) ); ?></textarea>
                    </div>
                </div>

                <!-- Social Tab -->
                <div id="si-tab-social" class="si-tab-content">
                    <div class="si-accordion">
                        <div class="si-accordion-header active">
                            <span>Facebook</span>
                            <span class="dashicons dashicons-arrow-up-alt2"></span>
                        </div>
                        <div class="si-accordion-content" style="display: block;">
                            <div class="si-social-preview-wrapper fb" style="margin-bottom:20px;">
                                <div class="si-social-preview-card fb" style="border:1px solid #e2e8f0; border-radius:8px; overflow:hidden; font-family:Helvetica, Arial, sans-serif; background:#fff; max-width:520px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                                    <div class="si-sp-image-container fb" style="height:273px; background:#f1f5f9; position:relative; display:flex; align-items:center; justify-content:center; border-bottom:1px solid #f1f5f9; overflow:hidden;">
                                        <img id="si-fb-preview-img-tag" src="" alt="Facebook Share Image" style="display:none; width:100%; height:100%; object-fit:cover;">
                                        <div id="si-fb-preview-img-placeholder" style="color:#64748b; font-size:0.9rem;"><span class="dashicons dashicons-format-image" style="vertical-align:middle; margin-right:5px;"></span>No Image Selected</div>
                                    </div>
                                    <div class="si-sp-text-container fb" style="padding:12px; background:#f0f2f5; text-align:left;">
                                        <div class="si-sp-domain fb" style="font-size:12px; color:#606770; text-transform:uppercase; margin-bottom:4px; letter-spacing:0.5px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?php echo parse_url(home_url(), PHP_URL_HOST); ?></div>
                                        <div class="si-sp-title fb" id="si-fb-preview-title-tag" style="font-size:16px; font-weight:600; color:#1d2129; margin-bottom:4px; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; height:38px; line-height:1.2;">Facebook Title Mockup</div>
                                        <div class="si-sp-desc fb" id="si-fb-preview-desc-tag" style="font-size:14px; color:#606770; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; overflow:hidden; height:18px; line-height:1.3;">Facebook description snippet text showing how the post shares look.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="si-mb-field">
                                <label>Facebook image</label>
                                <div style="display:flex; gap:10px;">
                                    <input type="url" id="si_fb_image" name="si_fb_image" value="<?php echo esc_attr( get_post_meta( $post->ID, '_si_fb_image', true ) ); ?>" placeholder="https://example.com/fb-image.jpg">
                                    <button type="button" class="button si-media-upload-btn" data-target="si_fb_image">Upload</button>
                                </div>
                            </div>
                            <div class="si-mb-field">
                                <label>Facebook title</label>
                                <input type="text" id="si_fb_title" name="si_fb_title" value="<?php echo esc_attr( get_post_meta( $post->ID, '_si_fb_title', true ) ); ?>" placeholder="Leave empty to use SEO Title">
                            </div>
                            <div class="si-mb-field">
                                <label>Facebook description</label>
                                <textarea id="si_fb_desc" name="si_fb_desc" rows="2" placeholder="Leave empty to use Meta Description"><?php echo esc_textarea( get_post_meta( $post->ID, '_si_fb_desc', true ) ); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="si-accordion">
                        <div class="si-accordion-header">
                            <span>Twitter</span>
                            <span class="dashicons dashicons-arrow-down-alt2"></span>
                        </div>
                        <div class="si-accordion-content">
                            <div class="si-social-preview-wrapper tw" style="margin-bottom:20px;">
                                <div class="si-social-preview-card tw" style="border:1px solid #e2e8f0; border-radius:12px; overflow:hidden; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background:#fff; max-width:506px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                                    <div class="si-sp-image-container tw" style="height:265px; background:#f1f5f9; position:relative; display:flex; align-items:center; justify-content:center; border-bottom:1px solid #e2e8f0; overflow:hidden;">
                                        <img id="si-tw-preview-img-tag" src="" alt="Twitter Share Image" style="display:none; width:100%; height:100%; object-fit:cover;">
                                        <div id="si-tw-preview-img-placeholder" style="color:#64748b; font-size:0.9rem;"><span class="dashicons dashicons-format-image" style="vertical-align:middle; margin-right:5px;"></span>No Image Selected</div>
                                    </div>
                                    <div class="si-sp-text-container tw" style="padding:12px; text-align:left;">
                                        <div class="si-sp-domain tw" style="font-size:13px; color:#536471; margin-bottom:2px;"><?php echo parse_url(home_url(), PHP_URL_HOST); ?></div>
                                        <div class="si-sp-title tw" id="si-tw-preview-title-tag" style="font-size:15px; font-weight:600; color:#0f1419; margin-bottom:4px; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; height:36px; line-height:1.2;">Twitter Title Mockup</div>
                                        <div class="si-sp-desc tw" id="si-tw-preview-desc-tag" style="font-size:15px; color:#536471; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; overflow:hidden; height:18px; line-height:1.2;">Twitter description snippet text showing card layout configurations.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="si-mb-field">
                                <label>Twitter image</label>
                                <div style="display:flex; gap:10px;">
                                    <input type="url" id="si_tw_image" name="si_tw_image" value="<?php echo esc_attr( get_post_meta( $post->ID, '_si_tw_image', true ) ); ?>" placeholder="https://example.com/tw-image.jpg">
                                    <button type="button" class="button si-media-upload-btn" data-target="si_tw_image">Upload</button>
                                </div>
                            </div>
                            <div class="si-mb-field">
                                <label>Twitter title</label>
                                <input type="text" id="si_tw_title" name="si_tw_title" value="<?php echo esc_attr( get_post_meta( $post->ID, '_si_tw_title', true ) ); ?>" placeholder="Leave empty to use SEO Title">
                            </div>
                            <div class="si-mb-field">
                                <label>Twitter description</label>
                                <textarea id="si_tw_desc" name="si_tw_desc" rows="2" placeholder="Leave empty to use Meta Description"><?php echo esc_textarea( get_post_meta( $post->ID, '_si_tw_desc', true ) ); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Linking Tab -->
                <div id="si-tab-linking" class="si-tab-content">
                    <h4>Internal Linking Suggestions</h4>
                    <p style="font-size: 0.85rem; color: #64748b;">Here are highly relevant posts you should link to from this article, based on your focus keywords.</p>
                    <div id="si-link-suggestions-container" style="margin-top: 20px;">
                        <div style="padding: 15px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; text-align: center; color: #64748b;">
                            <span class="dashicons dashicons-update" style="animation: spin 2s linear infinite;"></span> Fetching AI suggestions...
                        </div>
                    </div>
                </div>

            </div> <!-- /si-mb-content-area -->
        </div>
        <?php
    }

    public static function save_meta_data( $post_id ) {
        if ( ! isset( $_POST['si_meta_box_nonce_field'] ) || ! wp_verify_nonce( $_POST['si_meta_box_nonce_field'], 'si_meta_box_nonce' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Basic fields
        if ( isset( $_POST['si_seo_title'] ) ) update_post_meta( $post_id, '_si_seo_title', sanitize_text_field( $_POST['si_seo_title'] ) );
        if ( isset( $_POST['si_meta_description'] ) ) update_post_meta( $post_id, '_si_meta_description', sanitize_textarea_field( $_POST['si_meta_description'] ) );
        if ( isset( $_POST['si_focus_keywords'] ) ) update_post_meta( $post_id, '_si_focus_keywords', sanitize_text_field( $_POST['si_focus_keywords'] ) );
        
        // Cornerstone
        $is_cornerstone = isset( $_POST['si_is_cornerstone'] ) ? 'yes' : 'no';
        update_post_meta( $post_id, '_si_is_cornerstone', $is_cornerstone );

        // Schema
        if ( isset( $_POST['si_schema_webpage_type'] ) ) {
            update_post_meta( $post_id, '_si_schema_webpage_type', sanitize_text_field( $_POST['si_schema_webpage_type'] ) );
        }
        if ( isset( $_POST['si_schema_article_type'] ) ) {
            update_post_meta( $post_id, '_si_schema_article_type', sanitize_text_field( $_POST['si_schema_article_type'] ) );
        }
        if ( isset( $_POST['si_custom_schema'] ) ) {
            update_post_meta( $post_id, '_si_custom_schema', wp_unslash( $_POST['si_custom_schema'] ) );
        }

        // Advanced
        if ( isset( $_POST['si_robots_index'] ) ) update_post_meta( $post_id, '_si_robots_index', sanitize_text_field( $_POST['si_robots_index'] ) );
        if ( isset( $_POST['si_robots_follow'] ) ) update_post_meta( $post_id, '_si_robots_follow', sanitize_text_field( $_POST['si_robots_follow'] ) );
        $robots_advanced = isset( $_POST['si_robots_advanced'] ) ? (array) $_POST['si_robots_advanced'] : array();
        update_post_meta( $post_id, '_si_robots_advanced', $robots_advanced );
        if ( isset( $_POST['si_breadcrumb_title'] ) ) update_post_meta( $post_id, '_si_breadcrumb_title', sanitize_text_field( $_POST['si_breadcrumb_title'] ) );
        if ( isset( $_POST['si_canonical_url'] ) ) update_post_meta( $post_id, '_si_canonical_url', esc_url_raw( $_POST['si_canonical_url'] ) );

        // Social
        if ( isset( $_POST['si_fb_image'] ) ) update_post_meta( $post_id, '_si_fb_image', esc_url_raw( $_POST['si_fb_image'] ) );
        if ( isset( $_POST['si_fb_title'] ) ) update_post_meta( $post_id, '_si_fb_title', sanitize_text_field( $_POST['si_fb_title'] ) );
        if ( isset( $_POST['si_fb_desc'] ) ) update_post_meta( $post_id, '_si_fb_desc', sanitize_textarea_field( $_POST['si_fb_desc'] ) );
        if ( isset( $_POST['si_tw_image'] ) ) update_post_meta( $post_id, '_si_tw_image', esc_url_raw( $_POST['si_tw_image'] ) );
        if ( isset( $_POST['si_tw_title'] ) ) update_post_meta( $post_id, '_si_tw_title', sanitize_text_field( $_POST['si_tw_title'] ) );
        if ( isset( $_POST['si_tw_desc'] ) ) update_post_meta( $post_id, '_si_tw_desc', sanitize_textarea_field( $_POST['si_tw_desc'] ) );

        // Handle Slug modification
        if ( isset( $_POST['si_post_slug'] ) ) {
            $new_slug = sanitize_title( $_POST['si_post_slug'] );
            $post_obj = get_post( $post_id );
            if ( $post_obj && $post_obj->post_name !== $new_slug ) {
                remove_action( 'save_post', array( __CLASS__, 'save_meta_data' ) );
                wp_update_post( array(
                    'ID'        => $post_id,
                    'post_name' => $new_slug
                ) );
                add_action( 'save_post', array( __CLASS__, 'save_meta_data' ) );
            }
        }
    }

    public static function enqueue_assets() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->base !== 'post' ) return;

        wp_enqueue_media();
        wp_enqueue_style( 'si-mb-styles', plugins_url( '../assets/css/styles.css', __FILE__ ), array(), time() );
        wp_enqueue_script( 'si-mb-js', plugins_url( '../assets/js/meta-box.js', __FILE__ ), array( 'jquery' ), time(), true );
        
        wp_localize_script( 'si-mb-js', 'si_meta_box_data', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'post_id' => get_the_ID(),
            'nonce'   => wp_create_nonce( 'si_meta_box_nonce' )
        ) );
    }
}
