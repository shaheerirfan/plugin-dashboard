<?php
/**
 * SEO Inspector File Editor Class
 * Handles robots.txt and .htaccess editing securely.
 */

class SI_File_Editor {
    public static function init() {
        // Menu registered centrally in seo-inspector.php
        add_action('admin_post_si_restore_file', array(__CLASS__, 'handle_restore'));
    }

    private static function is_valid_robots( $content ) {
        if ( stripos( $content, '<?php' ) !== false ) return false;
        return true;
    }

    private static function is_valid_htaccess( $content ) {
        if ( stripos( $content, '<?php' ) !== false ) return false;
        return true;
    }

    public static function handle_restore() {
        if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['file'] ) || ! isset( $_GET['_wpnonce'] ) ) {
            wp_die( 'Unauthorized' );
        }
        
        if ( ! wp_verify_nonce( $_GET['_wpnonce'], 'si_restore_nonce' ) ) {
            wp_die( 'Invalid nonce' );
        }

        $type = sanitize_text_field( $_GET['file'] );
        $file = ABSPATH . ( $type === 'htaccess' ? '.htaccess' : 'robots.txt' );
        $backup = $file . '.bak';

        if ( file_exists( $backup ) ) {
            copy( $backup, $file );
            wp_redirect( admin_url( 'admin.php?page=si-file-editor&restored=1' ) );
            exit;
        } else {
            wp_die( 'No backup found.' );
        }
    }

    public static function render_editor_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $robots_file = ABSPATH . 'robots.txt';
        $htaccess_file = ABSPATH . '.htaccess';
        
        // Handle robots.txt save
        if ( isset( $_POST['si_save_robots'] ) && check_admin_referer( 'si_robots_nonce' ) ) {
            $content = wp_unslash( $_POST['si_robots_content'] );
            if ( self::is_valid_robots( $content ) ) {
                if ( file_exists( $robots_file ) ) {
                    copy( $robots_file, $robots_file . '.bak' ); // Create backup
                }
                file_put_contents( $robots_file, $content );
                echo '<div class="updated"><p>robots.txt saved successfully! Backup created.</p></div>';
            } else {
                echo '<div class="error"><p>Invalid robots.txt content detected (PHP code is not allowed).</p></div>';
            }
        }

        // Handle .htaccess save
        if ( isset( $_POST['si_save_htaccess'] ) && check_admin_referer( 'si_htaccess_nonce' ) ) {
            $content = wp_unslash( $_POST['si_htaccess_content'] );
            if ( self::is_valid_htaccess( $content ) ) {
                if ( file_exists( $htaccess_file ) ) {
                    copy( $htaccess_file, $htaccess_file . '.bak' ); // Create backup
                }
                file_put_contents( $htaccess_file, $content );
                echo '<div class="updated"><p>.htaccess saved successfully! Backup created.</p></div>';
            } else {
                echo '<div class="error"><p>Invalid .htaccess content detected.</p></div>';
            }
        }

        $robots_content = file_exists( $robots_file ) ? file_get_contents( $robots_file ) : "User-agent: *\nDisallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php";
        $htaccess_content = file_exists( $htaccess_file ) ? file_get_contents( $htaccess_file ) : "";
        ?>
        <div class="wrap si-dashboard">
            <header class="si-header left" style="margin-bottom: 40px; border-bottom: none; padding-bottom: 0;">
                <h1 style="font-size: 3.5rem; line-height: 1.1; margin-bottom: 10px;">File Editor</h1>
                <p style="font-size: 1.1rem; color: #64748b;">Manage and edit your site's core configuration files securely with automatic backups.</p>
            </header>
            
            <?php if ( isset( $_GET['restored'] ) ): ?>
                <div class="updated"><p>File restored from backup successfully.</p></div>
            <?php endif; ?>

            <!-- robots.txt Editor -->
            <div class="si-main-card" style="text-align: left; margin-bottom: 30px;">
                <h3>robots.txt Editor</h3>
                <p>Edit your robots.txt file to control how search engines crawl your site.</p>
                <form method="post">
                    <?php wp_nonce_field( 'si_robots_nonce' ); ?>
                    <textarea name="si_robots_content" rows="10" style="width:100%; font-family:monospace; padding:20px; border-radius:15px; border:1px solid #e2e8f0; margin-bottom:20px;"><?php echo esc_textarea( $robots_content ); ?></textarea>
                    
                    <div style="display:flex; gap:15px; align-items:center;">
                        <button type="submit" name="si_save_robots" class="button button-primary" style="padding:10px 40px !important; height:auto !important;">Save robots.txt</button>
                        <?php if ( file_exists( $robots_file . '.bak' ) ) : ?>
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=si_restore_file&file=robots' ), 'si_restore_nonce' ) ); ?>" class="button" style="color:#d63638; border-color:#d63638;" onclick="return confirm('Restore from last backup? Current changes will be lost.');">Restore Backup</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- .htaccess Editor -->
            <div class="si-main-card" style="text-align: left;">
                <h3>.htaccess Editor</h3>
                <p>Edit your Apache .htaccess file. <strong>Warning:</strong> Invalid directives can break your entire site.</p>
                <form method="post">
                    <?php wp_nonce_field( 'si_htaccess_nonce' ); ?>
                    <textarea name="si_htaccess_content" rows="15" style="width:100%; font-family:monospace; padding:20px; border-radius:15px; border:1px solid #e2e8f0; margin-bottom:20px;"><?php echo esc_textarea( $htaccess_content ); ?></textarea>
                    
                    <div style="display:flex; gap:15px; align-items:center;">
                        <button type="submit" name="si_save_htaccess" class="button button-primary" style="padding:10px 40px !important; height:auto !important;">Save .htaccess</button>
                        <?php if ( file_exists( $htaccess_file . '.bak' ) ) : ?>
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=si_restore_file&file=htaccess' ), 'si_restore_nonce' ) ); ?>" class="button" style="color:#d63638; border-color:#d63638;" onclick="return confirm('Restore from last backup? Current changes will be lost.');">Restore Backup</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }
}
