<?php
/**
 * SEO Inspector Redirection Manager Class
 * Handles 301/302/307/410/451 redirects, Regex redirects, and Apache/NGINX exports.
 */

class SI_Redirects {
    public static function init() {
        add_action( 'init', array( __CLASS__, 'handle_admin_actions' ) );
        add_action( 'template_redirect', array( __CLASS__, 'handle_visitor_redirection' ), 5 );
        add_action( 'template_redirect', array( __CLASS__, 'handle_404_redirections' ) );
        add_action( 'post_updated', array( __CLASS__, 'monitor_slug_changes' ), 10, 3 );
        add_action( 'trashed_post', array( __CLASS__, 'monitor_trashed_posts' ) );
    }

    public static function monitor_slug_changes( $post_id, $post_after, $post_before ) {
        if ( $post_after->post_status !== 'publish' || $post_before->post_status !== 'publish' ) {
            return;
        }

        if ( $post_before->post_name !== $post_after->post_name ) {
            $old_link = wp_make_link_relative( get_permalink( $post_before ) );
            $new_link = wp_make_link_relative( get_permalink( $post_after ) );

            if ( $old_link !== $new_link ) {
                self::add_redirect_rule( $old_link, $new_link, '301', 'plain' );
            }
        }
    }

    public static function monitor_trashed_posts( $post_id ) {
        $post = get_post( $post_id );
        if ( $post && $post->post_status === 'publish' ) {
            $old_link = wp_make_link_relative( get_permalink( $post_id ) );
            $new_link = '/'; // Default to homepage

            if ( $old_link && $old_link !== $new_link ) {
                self::add_redirect_rule( $old_link, $new_link, '301', 'plain' );
            }
        }
    }

    public static function add_redirect_rule( $source, $target, $type = '301', $format = 'plain' ) {
        $redirects = get_option( 'si_redirects', array() );
        
        // Prevent duplicates
        foreach ( $redirects as $r ) {
            if ( $r['source'] === $source && $r['target'] === $target && ($r['format'] ?? 'plain') === $format ) return;
        }

        $redirects[] = array(
            'source' => $source,
            'target' => $target,
            'type'   => $type,
            'format' => $format,
            'date'   => current_time( 'mysql' )
        );
        update_option( 'si_redirects', $redirects );
    }

    public static function handle_visitor_redirection() {
        if ( is_admin() ) {
            return;
        }

        $redirects = get_option( 'si_redirects', array() );
        if ( empty( $redirects ) ) {
            return;
        }

        $request_uri = $_SERVER['REQUEST_URI'] ?? '/';
        $request_path = parse_url( $request_uri, PHP_URL_PATH ) ?: '/';
        $request_path = '/' . ltrim( $request_path, '/' );

        // Strip subdirectory if present
        $home_path = parse_url( home_url(), PHP_URL_PATH ) ?: '';
        if ( ! empty( $home_path ) && strpos( $request_path, $home_path ) === 0 ) {
            $request_path = '/' . ltrim( substr( $request_path, strlen( $home_path ) ), '/' );
        }

        foreach ( $redirects as $r ) {
            $format = isset( $r['format'] ) ? $r['format'] : 'plain';
            
            if ( $format === 'regex' ) {
                $regex = $r['source'];
                $pattern = '#' . str_replace( '#', '\\#', $regex ) . '#i';
                
                if ( @preg_match( $pattern, $request_uri, $matches ) ) {
                    $target = $r['target'];
                    $target = preg_replace_callback( '/\$([0-9]+)/', function( $match ) use ( $matches ) {
                        $idx = intval( $match[1] );
                        return isset( $matches[$idx] ) ? $matches[$idx] : '';
                    }, $target );

                    self::execute_redirect( $target, $r['type'] );
                }
            } else {
                $source_path = '/' . ltrim( parse_url( $r['source'], PHP_URL_PATH ) ?: $r['source'], '/' );
                
                if ( rtrim( $request_path, '/' ) === rtrim( $source_path, '/' ) ) {
                    self::execute_redirect( $r['target'], $r['type'] );
                }
            }
        }
    }

    private static function execute_redirect( $target, $type ) {
        $type = intval( $type );
        if ( in_array( $type, array( 410, 451 ) ) ) {
            status_header( $type );
            nocache_headers();
            $msg = ( $type === 410 ) ? '410 Content Deleted' : '451 Unavailable For Legal Reasons';
            wp_die( '<h1>' . esc_html($msg) . '</h1><p>The requested resource is no longer available.</p>', $msg, array( 'response' => $type ) );
            exit;
        }

        $target_url = ( strpos( $target, 'http' ) === 0 ) ? $target : home_url( '/' . ltrim( $target, '/' ) );
        wp_redirect( $target_url, $type, 'SEO Inspector' );
        exit;
    }

    public static function handle_404_redirections() {
        if ( is_404() && get_option( 'si_404_redirection', 'off' ) === 'on' ) {
            wp_redirect( home_url() );
            exit;
        }
    }

    public static function handle_admin_actions() {
        if ( is_admin() && current_user_can( 'manage_options' ) ) {
            // Save Settings
            if ( isset( $_POST['si_save_redirect_settings'] ) ) {
                check_admin_referer( 'si_redirect_settings_nonce' );
                update_option( 'si_404_redirection', isset( $_POST['si_404_redirection'] ) ? 'on' : 'off' );
                wp_safe_redirect( admin_url( 'admin.php?page=si-redirects&si_msg=settings_saved' ) );
                exit;
            }

            // Export CSV
            if ( isset( $_POST['si_export_csv'] ) ) {
                check_admin_referer( 'si_export_csv_nonce' );
                $redirects = get_option( 'si_redirects', array() );
                
                header( 'Content-Type: text/csv; charset=utf-8' );
                header( 'Content-Disposition: attachment; filename=seo-inspector-redirects.csv' );
                
                $output = fopen( 'php://output', 'w' );
                fputcsv( $output, array( 'Source URL', 'Target URL', 'Type', 'Format' ) );
                
                foreach ( $redirects as $r ) {
                    fputcsv( $output, array( $r['source'], $r['target'], $r['type'], $r['format'] ?? 'plain' ) );
                }
                
                fclose( $output );
                exit;
            }

            // Export Apache .htaccess
            if ( isset( $_POST['si_export_htaccess'] ) ) {
                check_admin_referer( 'si_export_htaccess_nonce' );
                $redirects = get_option( 'si_redirects', array() );
                
                header( 'Content-Type: text/plain; charset=utf-8' );
                header( 'Content-Disposition: attachment; filename=htaccess-redirects.txt' );
                
                echo "# SEO Inspector Apache Redirects\n";
                foreach ( $redirects as $r ) {
                    $type = $r['type'];
                    $format = $r['format'] ?? 'plain';
                    if ( in_array($type, array('410', '451')) ) {
                        $directive = ($format === 'regex') ? 'RedirectMatch' : 'Redirect';
                        echo $directive . " " . $type . " " . $r['source'] . "\n";
                    } else {
                        $directive = ($format === 'regex') ? 'RedirectMatch' : 'Redirect';
                        echo $directive . " " . $type . " " . $r['source'] . " " . $r['target'] . "\n";
                    }
                }
                exit;
            }

            // Export NGINX rewrites
            if ( isset( $_POST['si_export_nginx'] ) ) {
                check_admin_referer( 'si_export_nginx_nonce' );
                $redirects = get_option( 'si_redirects', array() );
                
                header( 'Content-Type: text/plain; charset=utf-8' );
                header( 'Content-Disposition: attachment; filename=nginx-redirects.txt' );
                
                echo "# SEO Inspector NGINX Redirects\n";
                foreach ( $redirects as $r ) {
                    $type = $r['type'];
                    $format = $r['format'] ?? 'plain';
                    if ( in_array($type, array('410', '451')) ) {
                        echo "rewrite ^" . $r['source'] . "$ return " . $type . ";\n";
                    } else {
                        $flag = ($type === '301') ? 'permanent' : 'redirect';
                        if ($format === 'regex') {
                            echo "rewrite " . $r['source'] . " " . $r['target'] . " " . $flag . ";\n";
                        } else {
                            echo "rewrite ^" . $r['source'] . "$ " . $r['target'] . " " . $flag . ";\n";
                        }
                    }
                }
                exit;
            }

            // Import CSV
            if ( isset( $_POST['si_import_csv'] ) ) {
                check_admin_referer( 'si_import_csv_nonce' );
                
                if ( ! empty( $_FILES['si_csv_file']['tmp_name'] ) ) {
                    $file = fopen( $_FILES['si_csv_file']['tmp_name'], 'r' );
                    $redirects = get_option( 'si_redirects', array() );
                    
                    fgetcsv( $file ); // Skip header
                    $count = 0;
                    while ( ( $row = fgetcsv( $file ) ) !== false ) {
                        if ( count( $row ) >= 3 ) {
                            $source = sanitize_text_field( $row[0] );
                            $target = sanitize_text_field( $row[1] );
                            $type   = sanitize_text_field( $row[2] );
                            $format = isset($row[3]) ? sanitize_text_field($row[3]) : 'plain';
                            
                            if ( ! empty( $source ) ) {
                                $is_dupe = false;
                                foreach ( $redirects as $r ) {
                                    if ( $r['source'] === $source && $r['target'] === $target && ($r['format'] ?? 'plain') === $format ) {
                                        $is_dupe = true;
                                        break;
                                    }
                                }
                                if ( ! $is_dupe ) {
                                    $redirects[] = array(
                                        'source' => $source,
                                        'target' => $target,
                                        'type'   => in_array( $type, array('301','302','307','410','451') ) ? $type : '301',
                                        'format' => $format,
                                        'date'   => current_time( 'mysql' )
                                    );
                                    $count++;
                                }
                            }
                        }
                    }
                    fclose( $file );
                    update_option( 'si_redirects', $redirects );
                    wp_safe_redirect( admin_url( 'admin.php?page=si-redirects&si_msg=imported&count=' . $count ) );
                    exit;
                }
            }

            // Add Redirect (Plain or Regex)
            if ( isset( $_POST['si_add_redirect'] ) ) {
                check_admin_referer( 'si_redirect_nonce' );
                $source = sanitize_text_field( $_POST['si_source'] );
                $target = sanitize_text_field( $_POST['si_target'] );
                $type = sanitize_text_field( $_POST['si_type'] );
                $format = sanitize_text_field( $_POST['si_format'] );
                
                if ( ! empty( $source ) ) {
                    self::add_redirect_rule( $source, $target, $type, $format );
                    wp_safe_redirect( admin_url( 'admin.php?page=si-redirects&si_msg=added' ) );
                    exit;
                }
            }

            // Individual Delete
            if ( isset( $_GET['delete'] ) ) {
                check_admin_referer( 'si_delete_nonce' );
                $redirects = get_option( 'si_redirects', array() );
                unset( $redirects[ $_GET['delete'] ] );
                update_option( 'si_redirects', $redirects );
                wp_safe_redirect( admin_url( 'admin.php?page=si-redirects&si_msg=deleted' ) );
                exit;
            }
        }
    }

    public static function render_redirect_page() {
        if ( isset( $_GET['si_msg'] ) ) {
            $msg = 'Action completed successfully!';
            if ( $_GET['si_msg'] === 'added' ) $msg = 'Redirect added successfully!';
            if ( $_GET['si_msg'] === 'deleted' ) $msg = 'Redirect deleted successfully!';
            if ( $_GET['si_msg'] === 'settings_saved' ) $msg = 'Settings saved successfully!';
            if ( $_GET['si_msg'] === 'imported' ) {
                $count = isset($_GET['count']) ? intval($_GET['count']) : 0;
                $msg = $count . ' redirect(s) imported successfully!';
            }
            echo '<div class="updated"><p>' . esc_html( $msg ) . '</p></div>';
        }

        $redirects = get_option( 'si_redirects', array() );
        wp_enqueue_script( 'si-redirects-js', plugins_url( '../assets/js/redirects.js', __FILE__ ), array( 'jquery' ), time(), true );
        ?>
        <div class="wrap si-dashboard">
            <header class="si-header left" style="margin-bottom: 40px; border-bottom: none; padding-bottom: 0;">
                <h1 style="font-size: 3.5rem; line-height: 1.1; margin-bottom: 10px;">Redirection Manager</h1>
                <p style="font-size: 1.1rem; color: #64748b;">Manage visitor redirections (301, 302, 307, 410, 451) and Regex pattern rules.</p>
            </header>

            <!-- Sidebar Tab Navigation -->
            <div class="si-mb-container" style="display:flex; flex-direction:row; min-height:600px; border:1px solid #e2e8f0; border-radius:24px; overflow:hidden; background:#fff; box-shadow:0 10px 30px rgba(0,0,0,0.02);">
                <div class="si-mb-sidebar" style="width:250px; background:#f8fafc; border-right:1px solid #e2e8f0; padding:20px 0; display:flex; flex-direction:column; gap:5px;">
                    <div class="si-mb-tab active" data-tab="tab-plain-redirects" style="padding:15px 25px; font-weight:600; color:#475569; cursor:pointer; display:flex; align-items:center; gap:10px; border-left:4px solid transparent;"><i class="dashicons dashicons-randomize"></i> Plain Redirects</div>
                    <div class="si-mb-tab" data-tab="tab-regex-redirects" style="padding:15px 25px; font-weight:600; color:#475569; cursor:pointer; display:flex; align-items:center; gap:10px; border-left:4px solid transparent;"><i class="dashicons dashicons-editor-code"></i> Regex Redirects</div>
                    <div class="si-mb-tab" data-tab="tab-import-export" style="padding:15px 25px; font-weight:600; color:#475569; cursor:pointer; display:flex; align-items:center; gap:10px; border-left:4px solid transparent;"><i class="dashicons dashicons-backup"></i> Export & Import</div>
                    <div class="si-mb-tab" data-tab="tab-redirect-settings" style="padding:15px 25px; font-weight:600; color:#475569; cursor:pointer; display:flex; align-items:center; gap:10px; border-left:4px solid transparent;"><i class="dashicons dashicons-admin-settings"></i> Settings</div>
                </div>

                <div class="si-mb-content-area" style="flex:1; padding:40px;">
                    
                    <!-- TAB 1: PLAIN REDIRECTS -->
                    <div id="tab-plain-redirects" class="si-tab-content active" style="display:block;">
                        <h3 style="margin-top:0;">Add Plain Redirect</h3>
                        <form method="post" style="margin-bottom:40px;">
                            <?php wp_nonce_field( 'si_redirect_nonce' ); ?>
                            <input type="hidden" name="si_format" value="plain">
                            <div style="display:flex; gap:15px; flex-wrap:wrap; align-items:flex-end;">
                                <div class="si-mb-field" style="flex:1; min-width:200px; margin:0;">
                                    <label>Source URL Path</label>
                                    <input type="text" name="si_source" placeholder="e.g. /old-url" required style="width:100%;">
                                </div>
                                <div class="si-mb-field" style="flex:1; min-width:200px; margin:0;">
                                    <label>Target URL Path / URL</label>
                                    <input type="text" name="si_target" placeholder="e.g. /new-url" style="width:100%;">
                                </div>
                                <div class="si-mb-field" style="width:250px; margin:0;">
                                    <label>Redirect Type</label>
                                    <select name="si_type" style="width:100%; height:46px; border-radius:10px; border:1px solid #cbd5e1; padding: 0 10px;">
                                        <option value="301">301 Moved Permanently</option>
                                        <option value="302">302 Found</option>
                                        <option value="307">307 Temporary Redirect</option>
                                        <option value="410">410 Content Deleted</option>
                                        <option value="451">451 Unavailable (Legal)</option>
                                    </select>
                                </div>
                                <button type="submit" name="si_add_redirect" class="button button-primary" style="height:46px; border-radius:10px; padding:0 25px; background:var(--si-primary) !important; border:none !important; font-weight:700;">Add Redirect</button>
                            </div>
                        </form>

                        <h3>Active Plain Redirects</h3>
                        <div class="si-search-container" style="max-width:300px; margin-bottom:20px;">
                            <input type="text" class="si-redirect-search" placeholder="Search redirects..." style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                        </div>
                        
                        <div class="si-redirect-feed-container">
                            <table class="si-premium-table" style="width:100%; text-align:left; border-collapse:collapse;" id="si-redirects-table">
                                <thead>
                                    <tr style="background:#f8fafc; border-bottom:1px solid #e2e8f0;">
                                        <th style="padding:15px;">Source URL</th>
                                        <th style="padding:15px;">Target URL</th>
                                        <th style="padding:15px; width:150px;">Type</th>
                                        <th style="padding:15px; width:80px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $has_plain = false;
                                    foreach ( $redirects as $key => $r ) : 
                                        if ( ( $r['format'] ?? 'plain' ) !== 'plain' ) continue;
                                        $has_plain = true;
                                        $badge_class = in_array( $r['type'], array('301', '302', '307') ) ? 'perm' : 'temp';
                                    ?>
                                        <tr class="si-redirect-table-row" style="border-bottom:1px solid #f1f5f9;">
                                            <td style="padding:15px;"><?php echo esc_html( $r['source'] ); ?></td>
                                            <td style="padding:15px;"><?php echo esc_html( $r['target'] ?: '(None)' ); ?></td>
                                            <td style="padding:15px;"><span class="si-type-badge <?php echo $badge_class; ?>"><?php echo esc_html( $r['type'] ); ?></span></td>
                                            <td style="padding:15px;">
                                                <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=si-redirects&delete=' . $key ), 'si_delete_nonce' ) ); ?>" class="si-delete-redirect-btn" style="color:#ef4444;" onclick="return confirm('Delete this redirect?');">
                                                    <span class="dashicons dashicons-trash"></span>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if ( ! $has_plain ) : ?>
                                        <tr><td colspan="4" style="padding:20px; text-align:center; color:#64748b;">No plain redirects configured.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- TAB 2: REGEX REDIRECTS -->
                    <div id="tab-regex-redirects" class="si-tab-content" style="display:none;">
                        <h3 style="margin-top:0;">Add Regex Redirect</h3>
                        <form method="post" style="margin-bottom:40px;">
                            <?php wp_nonce_field( 'si_redirect_nonce' ); ?>
                            <input type="hidden" name="si_format" value="regex">
                            <div style="display:flex; gap:15px; flex-wrap:wrap; align-items:flex-end;">
                                <div class="si-mb-field" style="flex:1; min-width:200px; margin:0;">
                                    <label>Source Regex Pattern</label>
                                    <input type="text" name="si_source" placeholder="e.g. ^/blog/(.*)$" required style="width:100%;">
                                </div>
                                <div class="si-mb-field" style="flex:1; min-width:200px; margin:0;">
                                    <label>Target Replacement URL</label>
                                    <input type="text" name="si_target" placeholder="e.g. /news/$1" style="width:100%;">
                                </div>
                                <div class="si-mb-field" style="width:250px; margin:0;">
                                    <label>Redirect Type</label>
                                    <select name="si_type" style="width:100%; height:46px; border-radius:10px; border:1px solid #cbd5e1; padding: 0 10px;">
                                        <option value="301">301 Moved Permanently</option>
                                        <option value="302">302 Found</option>
                                        <option value="307">307 Temporary Redirect</option>
                                        <option value="410">410 Content Deleted</option>
                                        <option value="451">451 Unavailable (Legal)</option>
                                    </select>
                                </div>
                                <button type="submit" name="si_add_redirect" class="button button-primary" style="height:46px; border-radius:10px; padding:0 25px; background:var(--si-primary) !important; border:none !important; font-weight:700;">Add Redirect</button>
                            </div>
                        </form>

                        <h3>Active Regular Expression Redirects</h3>
                        <div class="si-search-container" style="max-width:300px; margin-bottom:20px;">
                            <input type="text" class="si-redirect-search" placeholder="Search regex rules..." style="width:100%; padding:10px; border-radius:8px; border:1px solid #cbd5e1;">
                        </div>

                        <table class="si-premium-table" style="width:100%; text-align:left; border-collapse:collapse;">
                            <thead>
                                <tr style="background:#f8fafc; border-bottom:1px solid #e2e8f0;">
                                    <th style="padding:15px;">Regex Pattern</th>
                                    <th style="padding:15px;">Replacement URL</th>
                                    <th style="padding:15px; width:150px;">Type</th>
                                    <th style="padding:15px; width:80px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $has_regex = false;
                                foreach ( $redirects as $key => $r ) : 
                                    if ( ( $r['format'] ?? 'plain' ) !== 'regex' ) continue;
                                    $has_regex = true;
                                    $badge_class = in_array( $r['type'], array('301', '302', '307') ) ? 'perm' : 'temp';
                                ?>
                                    <tr class="si-redirect-table-row" style="border-bottom:1px solid #f1f5f9;">
                                        <td style="padding:15px; font-family:monospace;"><?php echo esc_html( $r['source'] ); ?></td>
                                        <td style="padding:15px; font-family:monospace;"><?php echo esc_html( $r['target'] ?: '(None)' ); ?></td>
                                        <td style="padding:15px;"><span class="si-type-badge <?php echo $badge_class; ?>"><?php echo esc_html( $r['type'] ); ?></span></td>
                                        <td style="padding:15px;">
                                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=si-redirects&delete=' . $key ), 'si_delete_nonce' ) ); ?>" class="si-delete-redirect-btn" style="color:#ef4444;" onclick="return confirm('Delete this redirect?');">
                                                <span class="dashicons dashicons-trash"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if ( ! $has_regex ) : ?>
                                    <tr><td colspan="4" style="padding:20px; text-align:center; color:#64748b;">No regex redirects configured.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- TAB 3: EXPORT & IMPORT -->
                    <div id="tab-import-export" class="si-tab-content" style="display:none;">
                        <h3 style="margin-top:0;">Bulk Configuration Exports</h3>
                        <p style="color:#64748b; font-size:0.9rem; margin-bottom:25px;">Export your redirections to use on external servers for fast, server-level redirections (bypassing PHP completely for maximum performance).</p>
                        
                        <div style="display:flex; gap:15px; flex-wrap:wrap; margin-bottom:40px;">
                            <form method="post" style="margin:0;">
                                <?php wp_nonce_field( 'si_export_csv_nonce' ); ?>
                                <button type="submit" name="si_export_csv" class="button button-primary" style="height:44px; padding:0 25px; border-radius:10px; font-weight:600; background:#475569 !important; border:none !important;">Export CSV</button>
                            </form>
                            <form method="post" style="margin:0;">
                                <?php wp_nonce_field( 'si_export_htaccess_nonce' ); ?>
                                <button type="submit" name="si_export_htaccess" class="button button-primary" style="height:44px; padding:0 25px; border-radius:10px; font-weight:600; background:var(--si-secondary) !important; border:none !important;">Export Apache (.htaccess)</button>
                            </form>
                            <form method="post" style="margin:0;">
                                <?php wp_nonce_field( 'si_export_nginx_nonce' ); ?>
                                <button type="submit" name="si_export_nginx" class="button button-primary" style="height:44px; padding:0 25px; border-radius:10px; font-weight:600; background:var(--si-accent) !important; border:none !important;">Export NGINX Config</button>
                            </form>
                        </div>

                        <hr style="border:0; height:1px; background:#e2e8f0; margin:30px 0;">

                        <h3>Import Configurations</h3>
                        <p style="color:#64748b; font-size:0.9rem; margin-bottom:20px;">Upload a CSV file containing redirection rows to import in bulk.</p>
                        <form method="post" enctype="multipart/form-data" style="display:flex; align-items:center; gap:15px;">
                            <?php wp_nonce_field( 'si_import_csv_nonce' ); ?>
                            <input type="file" name="si_csv_file" accept=".csv" required style="padding:10px; border:1px solid #cbd5e1; border-radius:10px; background:#f8fafc; font-size:0.9rem;">
                            <button type="submit" name="si_import_csv" class="button button-primary" style="height:44px; padding:0 25px; border-radius:10px; font-weight:700; background:var(--si-primary) !important; border:none !important;">Upload & Import CSV</button>
                        </form>
                    </div>

                    <!-- TAB 4: SETTINGS -->
                    <div id="tab-redirect-settings" class="si-tab-content" style="display:none;">
                        <h3 style="margin-top:0;">Global Redirect Settings</h3>
                        <p style="color:#64748b; font-size:0.9rem; margin-bottom:25px;">Adjust automated rules and behavior for redirects across the site.</p>
                        
                        <form method="post" style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:16px; padding:25px; display:flex; align-items:center; justify-content:space-between;">
                            <?php wp_nonce_field( 'si_redirect_settings_nonce' ); ?>
                            <div>
                                <h4 style="margin:0 0 5px 0; font-size:1.1rem;">Redirect All 404s to Homepage</h4>
                                <p style="margin:0; color:#64748b; font-size:0.9rem;">Turn on to automatically redirect all page errors (Page Not Found) to the main home page.</p>
                            </div>
                            <div style="display:flex; align-items:center; gap:15px;">
                                <label class="si-toggle" style="margin:0;">
                                    <input type="checkbox" name="si_404_redirection" <?php checked( get_option( 'si_404_redirection', 'off' ), 'on' ); ?>>
                                    <span class="si-slider"></span>
                                    <span class="si-knob"></span>
                                </label>
                                <button type="submit" name="si_save_redirect_settings" class="button button-primary" style="height:40px; padding:0 20px; border-radius:8px; font-weight:700; background:var(--si-primary) !important; border:none !important;">Save Option</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.si-mb-tab').on('click', function() {
                var target = $(this).data('tab');
                $('.si-mb-tab').removeClass('active').css('border-left-color', 'transparent');
                $(this).addClass('active').css('border-left-color', 'var(--si-primary)');
                
                $('.si-tab-content').hide();
                $('#' + target).fadeIn(200);
            });

            // Make first tab look active on sidebar
            $('.si-mb-tab.active').css('border-left-color', 'var(--si-primary)');

            // Handle custom search inputs dynamically per tab
            $('.si-redirect-search').on('input', function() {
                var query = $(this).val().toLowerCase();
                var $activeTab = $(this).closest('.si-tab-content');
                var $rows = $activeTab.find('.si-redirect-table-row');
                
                $rows.each(function() {
                    var source = $(this).find('td').eq(0).text().toLowerCase();
                    var target = $(this).find('td').eq(1).text().toLowerCase();
                    if (source.includes(query) || target.includes(query)) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
            });
        });
        </script>
        <?php
    }
}
