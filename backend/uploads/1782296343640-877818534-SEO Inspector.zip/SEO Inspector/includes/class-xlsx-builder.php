<?php
/**
 * Pure PHP XLSX Builder for SEO Inspector
 * Generates native Excel (.xlsx) files without external dependencies.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_XLSX_Builder {

    private $sheets = array();
    private $shared_strings = array();
    private $shared_strings_lookup = array();
    private $styles = array();

    public function __construct() {
        // Initialize basic styles (colors, bold, etc.)
    }

    /**
     * Add a worksheet to the workbook.
     *
     * @param string $name       Worksheet name
     * @param array  $headers    Array of column headers
     * @param array  $rows       Array of arrays containing row data
     * @param string $tab_color  Hex color for the tab (e.g. 'FF0000')
     * @param bool   $freeze_top Freeze the top header row
     * @param bool   $auto_filter Enable auto filter on headers
     */
    public function add_sheet( $name, $headers, $rows, $tab_color = '', $freeze_top = true, $auto_filter = true ) {
        // Ensure unique, valid sheet name (max 31 chars)
        $safe_name = substr( preg_replace( '/[\[\]\*\?\/\:\\\]/', '', $name ), 0, 31 );
        
        $this->sheets[] = array(
            'name'        => $safe_name,
            'headers'     => $headers,
            'rows'        => $rows,
            'tab_color'   => str_replace( '#', '', $tab_color ),
            'freeze_top'  => $freeze_top,
            'auto_filter' => $auto_filter,
            'conditional' => array()
        );
        return count( $this->sheets ) - 1; // Return sheet index
    }

    /**
     * Set conditional formatting rules for a specific column in a sheet
     */
    public function set_conditional_format( $sheet_index, $col_letter, $rules ) {
        if ( isset( $this->sheets[ $sheet_index ] ) ) {
            $this->sheets[ $sheet_index ]['conditional'][ $col_letter ] = $rules;
        }
    }

    private function get_shared_string_index( $string ) {
        $string = (string) $string;
        if ( isset( $this->shared_strings_lookup[ $string ] ) ) {
            return $this->shared_strings_lookup[ $string ];
        }
        $index = count( $this->shared_strings );
        $this->shared_strings[] = $string;
        $this->shared_strings_lookup[ $string ] = $index;
        return $index;
    }

    private function cell_name( $col_index, $row_index ) {
        $dividend = $col_index + 1;
        $col_name = '';
        while ( $dividend > 0 ) {
            $modulo = ( $dividend - 1 ) % 26;
            $col_name = chr( 65 + $modulo ) . $col_name;
            $dividend = (int) ( ( $dividend - $modulo ) / 26 );
        }
        return $col_name . ( $row_index + 1 );
    }

    /**
     * Builds and outputs the XLSX file directly to output buffer.
     */
    public function output( $filename = 'report.xlsx' ) {
        // Create temporary file
        $temp_file = wp_tempnam( 'si_xlsx_' );
        $zip = new ZipArchive();
        
        if ( $zip->open( $temp_file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) !== true ) {
            return false;
        }

        // 1. [Content_Types].xml
        $zip->addFromString( '[Content_Types].xml', $this->build_content_types() );
        
        // 2. _rels/.rels
        $zip->addFromString( '_rels/.rels', $this->build_rels() );
        
        // 3. xl/_rels/workbook.xml.rels
        $zip->addFromString( 'xl/_rels/workbook.xml.rels', $this->build_workbook_rels() );
        
        // 4. xl/workbook.xml
        $zip->addFromString( 'xl/workbook.xml', $this->build_workbook() );
        
        // 5. xl/styles.xml
        $zip->addFromString( 'xl/styles.xml', $this->build_styles() );

        // 6. xl/worksheets/sheet*.xml
        foreach ( $this->sheets as $index => $sheet ) {
            $sheet_id = $index + 1;
            $zip->addFromString( "xl/worksheets/sheet{$sheet_id}.xml", $this->build_sheet( $sheet ) );
        }

        // 7. xl/sharedStrings.xml
        $zip->addFromString( 'xl/sharedStrings.xml', $this->build_shared_strings() );

        $zip->close();

        // Send headers
        header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
        header( 'Content-Disposition: attachment;filename="' . sanitize_file_name( $filename ) . '"' );
        header( 'Cache-Control: max-age=0' );
        header( 'Content-Length: ' . filesize( $temp_file ) );
        
        // Output file
        readfile( $temp_file );
        
        // Cleanup
        unlink( $temp_file );
        exit;
    }

    private function escape_xml( $str ) {
        return htmlspecialchars( $str, ENT_XML1 | ENT_COMPAT, 'UTF-8' );
    }

    private function build_content_types() {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">';
        $xml .= '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>';
        $xml .= '<Default Extension="xml" ContentType="application/xml"/>';
        $xml .= '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>';
        $xml .= '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        $xml .= '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>';
        
        foreach ( $this->sheets as $index => $sheet ) {
            $sheet_id = $index + 1;
            $xml .= '<Override PartName="/xl/worksheets/sheet' . $sheet_id . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        $xml .= '</Types>';
        return $xml;
    }

    private function build_rels() {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
        $xml .= '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>';
        $xml .= '</Relationships>';
        return $xml;
    }

    private function build_workbook_rels() {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
        $xml .= '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
        $xml .= '<Relationship Id="rIdSharedStrings" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>';
        
        foreach ( $this->sheets as $index => $sheet ) {
            $sheet_id = $index + 1;
            $xml .= '<Relationship Id="rIdSheet' . $sheet_id . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $sheet_id . '.xml"/>';
        }
        $xml .= '</Relationships>';
        return $xml;
    }

    private function build_workbook() {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
        $xml .= '<sheets>';
        
        foreach ( $this->sheets as $index => $sheet ) {
            $sheet_id = $index + 1;
            $xml .= '<sheet name="' . $this->escape_xml( $sheet['name'] ) . '" sheetId="' . $sheet_id . '" r:id="rIdSheet' . $sheet_id . '"/>';
        }
        
        $xml .= '</sheets>';
        $xml .= '</workbook>';
        return $xml;
    }

    private function build_styles() {
        // Define simple styles: 0=Normal, 1=Header (bold)
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
        
        // Fonts
        $xml .= '<fonts count="2">';
        $xml .= '<font><sz val="11"/><name val="Calibri"/></font>'; // Normal
        $xml .= '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'; // Bold white
        $xml .= '</fonts>';
        
        // Fills
        $xml .= '<fills count="3">';
        $xml .= '<fill><patternFill patternType="none"/></fill>';
        $xml .= '<fill><patternFill patternType="gray125"/></fill>';
        $xml .= '<fill><patternFill patternType="solid"><fgColor rgb="FF334155"/><bgColor indexed="64"/></patternFill></fill>'; // Dark header
        $xml .= '</fills>';
        
        // Borders
        $xml .= '<borders count="1">';
        $xml .= '<border><left/><right/><top/><bottom/><diagonal/></border>';
        $xml .= '</borders>';
        
        // Cell Style Xfs
        $xml .= '<cellStyleXfs count="1">';
        $xml .= '<xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>';
        $xml .= '</cellStyleXfs>';
        
        // Cell Xfs
        $xml .= '<cellXfs count="2">';
        $xml .= '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'; // 0 = Normal
        $xml .= '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'; // 1 = Header
        $xml .= '</cellXfs>';
        
        // Conditional formatting scale colors...
        // For simplicity in this lightweight generator, we use basic XML structure.
        
        $xml .= '</styleSheet>';
        return $xml;
    }

    private function build_sheet( $sheet ) {
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
        
        // Tab Color
        if ( ! empty( $sheet['tab_color'] ) ) {
            $xml .= '<sheetPr><tabColor rgb="FF' . strtoupper( $sheet['tab_color'] ) . '"/></sheetPr>';
        }

        // Frozen Pane
        if ( $sheet['freeze_top'] ) {
            $xml .= '<sheetViews>';
            $xml .= '<sheetView tabSelected="1" workbookViewId="0">';
            $xml .= '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>';
            $xml .= '</sheetView>';
            $xml .= '</sheetViews>';
        }

        // Column widths
        if ( ! empty( $sheet['headers'] ) ) {
            $xml .= '<cols>';
            foreach ( $sheet['headers'] as $col_index => $header ) {
                $width = ($col_index === 0) ? 60 : 30; // First col (URL) is usually wider
                $min_max = $col_index + 1;
                $xml .= '<col min="' . $min_max . '" max="' . $min_max . '" width="' . $width . '" customWidth="1"/>';
            }
            $xml .= '</cols>';
        }

        $xml .= '<sheetData>';
        
        // Headers
        if ( ! empty( $sheet['headers'] ) ) {
            $xml .= '<row r="1">';
            foreach ( $sheet['headers'] as $col_index => $header ) {
                $cell_ref = $this->cell_name( $col_index, 0 );
                $str_index = $this->get_shared_string_index( $header );
                $xml .= '<c r="' . $cell_ref . '" s="1" t="s"><v>' . $str_index . '</v></c>';
            }
            $xml .= '</row>';
        }

        // Rows
        $row_num = 2;
        foreach ( $sheet['rows'] as $row_data ) {
            $xml .= '<row r="' . $row_num . '">';
            $col_index = 0;
            foreach ( $row_data as $cell_value ) {
                $cell_ref = $this->cell_name( $col_index, $row_num - 1 );
                
                if ( is_numeric( $cell_value ) && ! is_string( $cell_value ) ) {
                    // Numeric cell
                    $xml .= '<c r="' . $cell_ref . '"><v>' . $cell_value . '</v></c>';
                } else {
                    // String cell
                    $str_index = $this->get_shared_string_index( $cell_value );
                    $xml .= '<c r="' . $cell_ref . '" t="s"><v>' . $str_index . '</v></c>';
                }
                $col_index++;
            }
            $xml .= '</row>';
            $row_num++;
        }
        $xml .= '</sheetData>';

        // AutoFilter
        if ( $sheet['auto_filter'] && ! empty( $sheet['headers'] ) ) {
            $last_col = $this->cell_name( count( $sheet['headers'] ) - 1, count( $sheet['rows'] ) );
            $xml .= '<autoFilter ref="A1:' . $last_col . '"/>';
        }

        $xml .= '</worksheet>';
        return $xml;
    }

    private function build_shared_strings() {
        $count = count( $this->shared_strings );
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $xml .= '<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . $count . '" uniqueCount="' . $count . '">';
        
        foreach ( $this->shared_strings as $str ) {
            $xml .= '<si><t>' . $this->escape_xml( $str ) . '</t></si>';
        }
        
        $xml .= '</sst>';
        return $xml;
    }
}
