<?php
/**
 * SEO Inspector - XLSX Export
 * Collects crawl results and generates a multi-tab Excel audit report.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_XLSX_Export {

    public static function init() {
        add_action( 'wp_ajax_si_store_crawl_results', array( __CLASS__, 'ajax_store_crawl_results' ) );
        add_action( 'wp_ajax_si_export_audit_xlsx', array( __CLASS__, 'ajax_export_xlsx' ) );
    }

    /**
     * Store crawl results server-side temporarily so the download endpoint can generate the XLSX.
     */
    public static function ajax_store_crawl_results() {
        check_ajax_referer( 'si_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $raw_data = isset( $_POST['results'] ) ? wp_unslash( $_POST['results'] ) : '';
        $results = json_decode( $raw_data, true );

        if ( ! is_array( $results ) ) {
            wp_send_json_error( 'Invalid data' );
        }

        // Store in a transient for 1 hour (plenty of time to click download)
        $user_id = get_current_user_id();
        set_transient( 'si_crawl_results_' . $user_id, $results, HOUR_IN_SECONDS );

        wp_send_json_success( 'Stored successfully' );
    }

    /**
     * Generate and download the XLSX file.
     */
    public static function ajax_export_xlsx() {
        if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( $_GET['nonce'], 'si_nonce' ) ) {
            wp_die( 'Invalid nonce.' );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized.' );
        }

        $user_id = get_current_user_id();
        $results = get_transient( 'si_crawl_results_' . $user_id );

        if ( ! is_array( $results ) || empty( $results ) ) {
            wp_die( 'No recent crawl results found. Please run a new scan.' );
        }

        require_once ABSOLUTE_PATH . 'includes/class-xlsx-builder.php';
        $builder = new SI_XLSX_Builder();

        // 1. Organize data into categories
        $categories = array();
        $summary = array(
            'urls_crawled' => count( $results ),
            'total_issues' => 0,
            'total_passes' => 0,
            'score_sum'    => 0,
            'category_counts' => array()
        );

        foreach ( $results as $res ) {
            $url = isset( $res['url'] ) ? $res['url'] : 'Unknown';
            $score = isset( $res['score'] ) ? (int) $res['score'] : 0;
            $issues = isset( $res['issues'] ) && is_array( $res['issues'] ) ? $res['issues'] : array();

            $summary['score_sum'] += $score;

            foreach ( $issues as $issue ) {
                $type = isset( $issue['type'] ) ? $issue['type'] : 'unknown';
                $msg  = isset( $issue['message'] ) ? $issue['message'] : '';

                // Map issue message to a Category Name
                $cat_name = self::determine_category( $msg, $type );

                if ( ! isset( $categories[ $cat_name ] ) ) {
                    $categories[ $cat_name ] = array(
                        'type' => $type, // success, warning, critical
                        'rows' => array()
                    );
                }

                if ( $type === 'success' ) {
                    $summary['total_passes']++;
                } else {
                    $summary['total_issues']++;
                }

                if ( ! isset( $summary['category_counts'][$cat_name] ) ) {
                    $summary['category_counts'][$cat_name] = 0;
                }
                $summary['category_counts'][$cat_name]++;

                $categories[ $cat_name ]['rows'][] = array(
                    $url,
                    $msg,
                    ucfirst( $type )
                );
            }
        }

        $overall_score = $summary['urls_crawled'] > 0 ? round( $summary['score_sum'] / $summary['urls_crawled'] ) : 0;

        // 2. Build Summary Sheet
        $summary_headers = array( 'Category', 'Count', 'Type' );
        $summary_rows = array();
        
        $summary_rows[] = array( 'Total URLs Crawled', $summary['urls_crawled'], 'Info' );
        $summary_rows[] = array( 'Overall SEO Score', $overall_score . '/100', 'Info' );
        $summary_rows[] = array( 'Total Issues Found', $summary['total_issues'], 'Warning/Critical' );
        $summary_rows[] = array( 'Total Checks Passed', $summary['total_passes'], 'Success' );
        $summary_rows[] = array( '', '', '' ); // Blank row
        $summary_rows[] = array( '--- BREAKDOWN BY CATEGORY ---', '', '' );

        // Sort category counts descending
        arsort( $summary['category_counts'] );
        foreach ( $summary['category_counts'] as $cat_name => $count ) {
            $cat_type = isset( $categories[$cat_name]['type'] ) ? ucfirst( $categories[$cat_name]['type'] ) : 'Unknown';
            $summary_rows[] = array( $cat_name, $count, $cat_type );
        }

        $builder->add_sheet( 'Summary', $summary_headers, $summary_rows, '0D64CB' ); // Blue tab

        // 3. Build Individual Category Sheets
        foreach ( $categories as $cat_name => $cat_data ) {
            $headers = array( 'URL', 'Details', 'Severity' );
            
            // Determine tab color based on severity
            $color = 'E2E8F0'; // Default gray
            if ( $cat_data['type'] === 'critical' ) $color = 'EF4444'; // Red
            elseif ( $cat_data['type'] === 'warning' ) $color = 'F59E0B'; // Amber
            elseif ( $cat_data['type'] === 'success' ) $color = '10B981'; // Green

            $builder->add_sheet( $cat_name, $headers, $cat_data['rows'], $color );
        }

        // 4. Output
        $date = date( 'Y-m-d' );
        $builder->output( "SEO-Audit-Report-{$date}.xlsx" );
    }

    /**
     * Heuristically determines a short category name for the tab based on the issue message.
     */
    private static function determine_category( $message, $type ) {
        $msg_lower = strtolower( $message );
        
        if ( strpos( $msg_lower, 'title too short' ) !== false ) return 'Title Too Short';
        if ( strpos( $msg_lower, 'title too long' ) !== false ) return 'Title Too Long';
        if ( strpos( $msg_lower, 'missing title' ) !== false ) return 'Missing Title';
        if ( strpos( $msg_lower, 'title tag is perfectly optimized' ) !== false ) return 'Title Optimized';
        
        if ( strpos( $msg_lower, 'meta description too short' ) !== false ) return 'Meta Desc Too Short';
        if ( strpos( $msg_lower, 'meta description too long' ) !== false ) return 'Meta Desc Too Long';
        if ( strpos( $msg_lower, 'missing meta description' ) !== false ) return 'Missing Meta Desc';
        if ( strpos( $msg_lower, 'meta description is perfectly optimized' ) !== false ) return 'Meta Desc Optimized';
        
        if ( strpos( $msg_lower, 'single h1' ) !== false ) return 'Single H1';
        if ( strpos( $msg_lower, 'missing h1' ) !== false ) return 'Missing H1';
        if ( strpos( $msg_lower, 'multiple h1' ) !== false ) return 'Multiple H1 Found';
        if ( strpos( $msg_lower, 'heading hierarchy' ) !== false ) return 'Heading Hierarchy';
        
        if ( strpos( $msg_lower, 'content length' ) !== false ) return 'Content Length OK';
        if ( strpos( $msg_lower, 'thin content' ) !== false || strpos( $msg_lower, 'cornerstone content requires' ) !== false ) return 'Thin Content';
        
        if ( strpos( $msg_lower, 'missing alt text' ) !== false ) return 'Missing Alt Text';
        if ( strpos( $msg_lower, 'all images have alt' ) !== false ) return 'Images Optimized';
        
        if ( strpos( $msg_lower, 'canonical' ) !== false ) {
            return $type === 'success' ? 'Canonical Present' : 'Canonical Missing';
        }
        
        if ( strpos( $msg_lower, 'schema' ) !== false || strpos( $msg_lower, 'json-ld' ) !== false ) {
            return $type === 'success' ? 'Schema Found' : 'Schema Missing';
        }

        if ( strpos( $msg_lower, 'open graph' ) !== false || strpos( $msg_lower, 'twitter card' ) !== false ) {
            return $type === 'success' ? 'Social Tags OK' : 'Social Tags Missing';
        }

        if ( strpos( $msg_lower, 'analytics' ) !== false || strpos( $msg_lower, 'search console' ) !== false || strpos( $msg_lower, 'tag manager' ) !== false ) {
            return $type === 'success' ? 'Tracking Installed' : 'Tracking Missing';
        }

        if ( strpos( $msg_lower, 'flesch' ) !== false || strpos( $msg_lower, 'readability' ) !== false ) {
            return 'Readability Analysis';
        }

        if ( strpos( $msg_lower, 'keyphrase' ) !== false ) {
            return 'Keyword Usage';
        }

        // Fallback: Use the first 4 words
        $words = explode( ' ', $message );
        $short = implode( ' ', array_slice( $words, 0, 4 ) );
        return rtrim( $short, '.,:;!' );
    }
}
