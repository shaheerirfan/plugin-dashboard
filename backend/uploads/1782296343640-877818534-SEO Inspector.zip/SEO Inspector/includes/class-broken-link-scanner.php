<?php
/**
 * SEO Inspector Broken Link Scanner
 * Scans post content for broken links (404s) using asynchronous batches.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Broken_Link_Scanner {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_submenu' ), 20 );
        add_action( 'wp_ajax_si_scan_broken_links', array( __CLASS__, 'ajax_scan_links' ) );
        add_action( 'wp_ajax_si_clear_broken_links', array( __CLASS__, 'ajax_clear_links' ) );
    }

    public static function add_submenu() {
        add_submenu_page(
            'seo-inspector',
            'Broken Links',
            'Broken Links',
            'manage_options',
            'si-broken-links',
            array( __CLASS__, 'render_page' )
        );
    }

    public static function render_page() {
        $nonce = wp_create_nonce( 'si_broken_links_nonce' );
        $broken_links = get_option( 'si_broken_links_report', array() );
        ?>
        <div class="wrap si-page-wrap">
            <h1>Broken Link Scanner</h1>
            <p>Scan your site's content to find dead links and 404 errors that harm your SEO.</p>
            
            <div class="si-settings-card" style="margin-bottom: 20px;">
                <button id="si-start-link-scan-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>">Scan Entire Site</button>
                <button id="si-clear-link-scan-btn" class="button" data-nonce="<?php echo esc_attr( $nonce ); ?>" style="margin-left: 10px;">Clear Report</button>
                
                <div id="si-link-scan-progress-container" style="display:none; margin-top: 20px;">
                    <div style="height: 10px; background: #e2e8f0; border-radius: 5px; overflow: hidden;">
                        <div id="si-link-scan-progress-bar" style="height: 100%; width: 0%; background: #e83e8c; transition: width 0.3s;"></div>
                    </div>
                    <p id="si-link-scan-status" style="margin-top: 10px; font-weight: bold; color: #475569;">Initializing...</p>
                </div>
            </div>

            <div class="si-settings-card">
                <h3>Scan Results</h3>
                <?php if ( empty( $broken_links ) ) : ?>
                    <p style="color: #10b981; font-weight: bold;">No broken links found! Your site is healthy.</p>
                <?php else : ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Post URL</th>
                                <th>Broken Link URL</th>
                                <th>Status Code</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $broken_links as $report ) : ?>
                            <tr>
                                <td><a href="<?php echo esc_url( get_permalink( $report['post_id'] ) ); ?>" target="_blank"><?php echo esc_html( get_the_title( $report['post_id'] ) ); ?></a></td>
                                <td><code><?php echo esc_html( $report['link'] ); ?></code></td>
                                <td><span style="color:#e83e8c; font-weight:bold;"><?php echo esc_html( $report['status'] ); ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#si-start-link-scan-btn').on('click', function() {
                var $btn = $(this);
                var nonce = $btn.data('nonce');
                
                $btn.prop('disabled', true);
                $('#si-link-scan-progress-container').show();
                $('#si-link-scan-progress-bar').css('width', '0%');
                
                function processBatch(page) {
                    $.post(ajaxurl, {
                        action: 'si_scan_broken_links',
                        nonce: nonce,
                        paged: page
                    }, function(response) {
                        if (response.success) {
                            var data = response.data;
                            var pct = Math.round((data.current_page / data.total_pages) * 100);
                            $('#si-link-scan-progress-bar').css('width', pct + '%');
                            $('#si-link-scan-status').text('Scanning posts... ' + pct + '%');
                            
                            if (data.has_more) {
                                processBatch(data.current_page + 1);
                            } else {
                                $('#si-link-scan-status').text('Scan Complete! Reloading...');
                                setTimeout(function() { location.reload(); }, 1500);
                            }
                        } else {
                            $('#si-link-scan-status').text('Error: ' + response.data).css('color', 'red');
                            $btn.prop('disabled', false);
                        }
                    }).fail(function() {
                        $('#si-link-scan-status').text('Server error.').css('color', 'red');
                        $btn.prop('disabled', false);
                    });
                }
                
                processBatch(1);
            });

            $('#si-clear-link-scan-btn').on('click', function() {
                if(confirm('Clear the current report?')) {
                    var nonce = $(this).data('nonce');
                    $.post(ajaxurl, {
                        action: 'si_clear_broken_links',
                        nonce: nonce
                    }, function() {
                        location.reload();
                    });
                }
            });
        });
        </script>
        <?php
    }

    public static function ajax_scan_links() {
        check_ajax_referer( 'si_broken_links_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $paged = isset( $_POST['paged'] ) ? max( 1, intval( $_POST['paged'] ) ) : 1;
        $posts_per_page = 10; // Small batch to prevent timeouts since network requests are slow

        if ( $paged === 1 ) {
            delete_option( 'si_broken_links_report' );
        }

        $query = new WP_Query( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged
        ) );

        $broken_links = get_option( 'si_broken_links_report', array() );

        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post ) {
                preg_match_all( '/<a\s+[^>]*href=["\'](http[^"\']+)["\']/i', $post->post_content, $matches );
                $links = array_unique( $matches[1] );
                
                foreach ( $links as $link ) {
                    // Check headers
                    $response = wp_remote_head( $link, array( 'timeout' => 3, 'redirection' => 2, 'sslverify' => false ) );
                    if ( is_wp_error( $response ) ) {
                        // Request failed completely
                        $broken_links[] = array(
                            'post_id' => $post->ID,
                            'link'    => $link,
                            'status'  => 'Timeout / Unreachable'
                        );
                    } else {
                        $status_code = wp_remote_retrieve_response_code( $response );
                        if ( $status_code >= 400 ) {
                            $broken_links[] = array(
                                'post_id' => $post->ID,
                                'link'    => $link,
                                'status'  => $status_code . ' HTTP Error'
                            );
                        }
                    }
                }
            }
        }

        update_option( 'si_broken_links_report', $broken_links, false );
        $has_more = $paged < $query->max_num_pages;

        wp_send_json_success( array(
            'current_page' => $paged,
            'total_pages'  => max( 1, $query->max_num_pages ),
            'has_more'     => $has_more
        ) );
    }

    public static function ajax_clear_links() {
        check_ajax_referer( 'si_broken_links_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
        delete_option( 'si_broken_links_report' );
        wp_send_json_success();
    }
}
