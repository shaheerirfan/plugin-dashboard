<?php
/**
 * SEO Inspector Schema Generator Class
 * Generates an interconnected JSON-LD Schema Graph and handles Breadcrumbs.
 */

class SI_Schema_Generator {
    public static function init() {
        add_action( 'wp_head', array( __CLASS__, 'inject_schema' ), 20 );
    }

    public static function inject_schema() {
        if ( ! is_singular() && ! is_home() && ! is_front_page() && ! is_archive() ) return;

        $post_id = get_the_ID();
        $site_url = home_url( '/' );
        $current_url = is_singular() ? get_permalink( $post_id ) : ( is_home() || is_front_page() ? $site_url : get_pagenum_link( get_query_var( 'paged' ) ) );

        $graph = array();

        // 1. WebSite
        $graph[] = array(
            '@type' => 'WebSite',
            '@id' => $site_url . '#website',
            'url' => $site_url,
            'name' => get_bloginfo( 'name' ),
            'description' => get_bloginfo( 'description' ),
            'publisher' => array( '@id' => $site_url . '#organization' ),
            'potentialAction' => array(
                array(
                    '@type' => 'SearchAction',
                    'target' => array(
                        '@type' => 'EntryPoint',
                        'urlTemplate' => $site_url . '?s={search_term_string}'
                    ),
                    'query-input' => 'required name=search_term_string'
                )
            )
        );

        // 2. Organization (Publisher)
        $graph[] = array(
            '@type' => 'Organization',
            '@id' => $site_url . '#organization',
            'name' => get_bloginfo( 'name' ),
            'url' => $site_url,
            'logo' => array(
                '@type' => 'ImageObject',
                '@id' => $site_url . '#logo',
                'url' => get_site_icon_url(),
                'caption' => get_bloginfo( 'name' )
            )
        );

        // Generate Breadcrumb Items
        $breadcrumbs = self::get_breadcrumb_items();

        // 3. BreadcrumbList
        $breadcrumb_list = array();
        foreach ( $breadcrumbs as $index => $crumb ) {
            $breadcrumb_list[] = array(
                '@type' => 'ListItem',
                'position' => $index + 1,
                'item' => array(
                    '@type' => 'WebPage',
                    '@id' => $crumb['url'],
                    'url' => $crumb['url'],
                    'name' => $crumb['name']
                )
            );
        }

        $graph[] = array(
            '@type' => 'BreadcrumbList',
            '@id' => $current_url . '#breadcrumb',
            'itemListElement' => $breadcrumb_list
        );

        // 4. WebPage (custom type fallback)
        $webpage_type = is_singular() ? (get_post_meta( $post_id, '_si_schema_webpage_type', true ) ?: 'WebPage') : 'WebPage';
        $webpage = array(
            '@type' => $webpage_type,
            '@id' => $current_url . '#webpage',
            'url' => $current_url,
            'name' => wp_get_document_title(),
            'isPartOf' => array( '@id' => $site_url . '#website' ),
            'breadcrumb' => array( '@id' => $current_url . '#breadcrumb' ),
        );
        
        if ( is_singular() && has_post_thumbnail( $post_id ) ) {
            $webpage['primaryImageOfPage'] = array( '@id' => $current_url . '#primaryimage' );
            
            // 5. ImageObject (Primary Image)
            $thumb_id = get_post_thumbnail_id( $post_id );
            $thumb_url = wp_get_attachment_image_url( $thumb_id, 'full' );
            $graph[] = array(
                '@type' => 'ImageObject',
                '@id' => $current_url . '#primaryimage',
                'url' => $thumb_url,
            );
        }

        $graph[] = $webpage;

        // 6. Article (if singular and not None)
        if ( is_singular() ) {
            $article_type = get_post_meta( $post_id, '_si_schema_article_type', true ) ?: 'Article';
            
            if ( $article_type !== 'None' ) {
                $article = array(
                    '@type' => $article_type,
                    '@id' => $current_url . '#article',
                    'isPartOf' => array( '@id' => $current_url . '#webpage' ),
                    'mainEntityOfPage' => array( '@id' => $current_url . '#webpage' ),
                    'headline' => get_the_title( $post_id ),
                    'datePublished' => get_the_date( 'c', $post_id ),
                    'dateModified' => get_the_modified_date( 'c', $post_id ),
                    'author' => array( '@id' => $current_url . '#author' ),
                    'publisher' => array( '@id' => $site_url . '#organization' )
                );

                if ( has_post_thumbnail( $post_id ) ) {
                    $article['image'] = array( '@id' => $current_url . '#primaryimage' );
                }

                $graph[] = $article;

                // 7. Person (Author)
                $author_id = get_post_field( 'post_author', $post_id );
                $graph[] = array(
                    '@type' => 'Person',
                    '@id' => $current_url . '#author',
                    'name' => get_the_author_meta( 'display_name', $author_id ),
                    'url' => get_author_posts_url( $author_id )
                );
            }

            // 8. WooCommerce Product Integration
            if ( get_post_type( $post_id ) === 'product' && class_exists( 'WooCommerce' ) ) {
                $product = wc_get_product( $post_id );
                if ( $product ) {
                    $product_schema = array(
                        '@type' => 'Product',
                        '@id' => $current_url . '#product',
                        'name' => $product->get_name(),
                        'url' => $current_url,
                        'description' => wp_strip_all_tags( $product->get_short_description() ?: $product->get_description() ),
                        'sku' => $product->get_sku(),
                        'image' => wp_get_attachment_image_url( $product->get_image_id(), 'full' ),
                        'mainEntityOfPage' => array( '@id' => $current_url . '#webpage' ),
                        'offers' => array(
                            '@type' => 'Offer',
                            'price' => $product->get_price(),
                            'priceCurrency' => get_woocommerce_currency(),
                            'availability' => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
                            'url' => $current_url,
                        )
                    );
                    $graph[] = $product_schema;
                }
            }
        }

        $final_schema = array(
            '@context' => 'https://schema.org',
            '@graph' => $graph
        );

        // Add Custom Schema if exists
        if ( is_singular() ) {
            $custom_schema = get_post_meta( $post_id, '_si_custom_schema', true );
            if ( ! empty( $custom_schema ) ) {
                echo "<!-- SEO Inspector Custom Schema -->\n";
                echo '<script type="application/ld+json">' . $custom_schema . '</script>' . "\n";
            }
        }

        echo "<!-- SEO Inspector Auto Schema Graph -->\n";
        echo '<script type="application/ld+json">' . wp_json_encode( $final_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
    }

    /**
     * Internal method to build breadcrumbs array
     */
    public static function get_breadcrumb_items() {
        $crumbs = array();
        $crumbs[] = array( 'name' => 'Home', 'url' => home_url( '/' ) );

        if ( is_singular() ) {
            $post = get_post();
            $post_type = get_post_type_object( $post->post_type );

            if ( $post_type && $post_type->has_archive ) {
                $crumbs[] = array( 'name' => $post_type->labels->name, 'url' => get_post_type_archive_link( $post->post_type ) );
            }

            if ( $post->post_type === 'post' ) {
                $categories = get_the_category( $post->ID );
                if ( ! empty( $categories ) ) {
                    $crumbs[] = array( 'name' => $categories[0]->name, 'url' => get_category_link( $categories[0]->term_id ) );
                }
            }

            $crumbs[] = array( 'name' => get_the_title(), 'url' => get_permalink() );
        } elseif ( is_category() ) {
            $crumbs[] = array( 'name' => single_cat_title( '', false ), 'url' => get_category_link( get_queried_object_id() ) );
        } elseif ( is_archive() ) {
            $crumbs[] = array( 'name' => post_type_archive_title( '', false ), 'url' => get_post_type_archive_link( get_post_type() ) );
        }

        return $crumbs;
    }

    /**
     * Output HTML Breadcrumbs
     */
    public static function output_breadcrumbs() {
        $crumbs = self::get_breadcrumb_items();
        
        echo '<nav class="si-breadcrumbs" aria-label="breadcrumb">';
        echo '<ol style="list-style: none; padding: 0; display: flex; gap: 8px;">';
        
        foreach ( $crumbs as $index => $crumb ) {
            $is_last = ( $index === count( $crumbs ) - 1 );
            
            echo '<li class="si-breadcrumb-item" ' . ( $is_last ? 'aria-current="page"' : '' ) . '>';
            
            if ( $is_last ) {
                echo '<span>' . esc_html( $crumb['name'] ) . '</span>';
            } else {
                echo '<a href="' . esc_url( $crumb['url'] ) . '">' . esc_html( $crumb['name'] ) . '</a>';
                echo '<span class="si-breadcrumb-separator" style="margin-left: 8px;">»</span>';
            }
            
            echo '</li>';
        }
        
        echo '</ol>';
        echo '</nav>';
    }
}

// Global helper function for themes to output breadcrumbs
function si_breadcrumbs() {
    SI_Schema_Generator::output_breadcrumbs();
}
