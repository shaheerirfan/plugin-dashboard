<?php
/**
 * SEO Inspector Bulk Export
 * Architecture Hardening: Implements asynchronous chunked processing to prevent timeouts.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_Bulk_Export {
    public static function init() {
        add_action( 'wp_ajax_si_bulk_export_process', array( __CLASS__, 'ajax_process_export' ) );
        add_action( 'wp_ajax_si_bulk_export_download', array( __CLASS__, 'ajax_download_export' ) );
        add_action( 'admin_menu', array( __CLASS__, 'add_submenu' ), 20 );
    }

    public static function add_submenu() {
        add_submenu_page(
            'seo-inspector',
            'Bulk CSV Export',
            'CSV Export',
            'manage_options',
            'si-bulk-export',
            array( __CLASS__, 'render_page' )
        );
    }

    public static function render_page() {
        $nonce = wp_create_nonce( 'si_export_nonce' );
        ?>
        <div class="wrap si-page-wrap">
            <h1>Bulk SEO CSV Export</h1>
            <p>Generate a complete CSV report of all your posts and their SEO metadata. This process runs in batches to prevent server timeouts.</p>

            <div class="si-settings-card" style="max-width: 600px; margin-top: 20px;">
                <button id="si-start-export-btn" class="button button-primary" data-nonce="<?php echo esc_attr( $nonce ); ?>">Start CSV Generation</button>
                
                <div id="si-export-progress-container" style="display:none; margin-top: 20px;">
                    <div style="height: 10px; background: #e2e8f0; border-radius: 5px; overflow: hidden;">
                        <div id="si-export-progress-bar" style="height: 100%; width: 0%; background: #3ABBA8; transition: width 0.3s;"></div>
                    </div>
                    <p id="si-export-status" style="margin-top: 10px; font-weight: bold; color: #475569;">Initializing...</p>
                </div>
                
                <div id="si-export-download-container" style="display:none; margin-top: 20px;">
                    <a id="si-download-csv-btn" href="#" class="button button-primary" style="background: #22c55e; border-color: #16a34a;">Download CSV</a>
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#si-start-export-btn').on('click', function() {
                var $btn = $(this);
                var nonce = $btn.data('nonce');
                
                $btn.prop('disabled', true);
                $('#si-export-progress-container').show();
                $('#si-export-download-container').hide();
                $('#si-export-progress-bar').css('width', '0%');
                
                function processBatch(page) {
                    $.post(ajaxurl, {
                        action: 'si_bulk_export_process',
                        nonce: nonce,
                        paged: page
                    }, function(response) {
                        if (response.success) {
                            var data = response.data;
                            var pct = Math.round((data.current_page / data.total_pages) * 100);
                            $('#si-export-progress-bar').css('width', pct + '%');
                            $('#si-export-status').text('Processing... ' + pct + '%');
                            
                            if (data.has_more) {
                                processBatch(data.current_page + 1);
                            } else {
                                $('#si-export-status').text('Generation Complete!');
                                $('#si-download-csv-btn').attr('href', ajaxurl + '?action=si_bulk_export_download&file=' + encodeURIComponent(data.file) + '&nonce=' + nonce);
                                $('#si-export-download-container').show();
                                $btn.prop('disabled', false).text('Regenerate CSV');
                            }
                        } else {
                            $('#si-export-status').text('Error: ' + response.data).css('color', 'red');
                            $btn.prop('disabled', false);
                        }
                    }).fail(function() {
                        $('#si-export-status').text('Server communication error.').css('color', 'red');
                        $btn.prop('disabled', false);
                    });
                }
                
                processBatch(1);
            });
        });
        </script>
        <?php
    }

    public static function ajax_process_export() {
        check_ajax_referer( 'si_export_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $paged = isset( $_POST['paged'] ) ? max( 1, intval( $_POST['paged'] ) ) : 1;
        $posts_per_page = 50;

        $upload_dir = wp_upload_dir();
        $export_dir = $upload_dir['basedir'] . '/seo-inspector-exports';
        if ( ! file_exists( $export_dir ) ) {
            wp_mkdir_p( $export_dir );
            // Protect directory
            file_put_contents( $export_dir . '/.htaccess', 'deny from all' );
            file_put_contents( $export_dir . '/index.php', '<?php // silence' );
        }

        // Use a persistent file name per user session/day
        $file_name = 'seo-export-' . md5( get_current_user_id() . date('Y-m-d') ) . '.csv';
        $file_path = $export_dir . '/' . $file_name;

        $mode = ( $paged === 1 ) ? 'w' : 'a';
        $fp = fopen( $file_path, $mode );
        
        if ( ! $fp ) {
            wp_send_json_error( 'Could not open file for writing.' );
        }

        // Headers
        if ( $paged === 1 ) {
            fputcsv( $fp, array( 'Post ID', 'Title', 'URL', 'SEO Title', 'Meta Description', 'Focus Keywords', 'Incoming Links', 'Outgoing Links', 'Cornerstone', 'Robots Index', 'Robots Follow' ) );
        }

        $query = new WP_Query( array(
            'post_type'      => array( 'post', 'page' ),
            'post_status'    => 'publish',
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged
        ) );

        if ( $query->have_posts() ) {
            foreach ( $query->posts as $post ) {
                $seo_title = get_post_meta( $post->ID, '_si_seo_title', true );
                $meta_desc = get_post_meta( $post->ID, '_si_meta_description', true );
                $keywords  = get_post_meta( $post->ID, '_si_focus_keywords', true );
                $incoming  = get_post_meta( $post->ID, '_si_incoming_links', true );
                $outgoing  = get_post_meta( $post->ID, '_si_outgoing_links', true );
                $corner    = get_post_meta( $post->ID, '_si_is_cornerstone', true );
                $rob_idx   = get_post_meta( $post->ID, '_si_robots_index', true );
                $rob_fol   = get_post_meta( $post->ID, '_si_robots_follow', true );

                fputcsv( $fp, array(
                    $post->ID,
                    $post->post_title,
                    get_permalink( $post->ID ),
                    $seo_title,
                    $meta_desc,
                    $keywords,
                    $incoming !== '' ? $incoming : '0',
                    $outgoing !== '' ? $outgoing : '0',
                    $corner,
                    $rob_idx,
                    $rob_fol
                ) );
            }
        }

        fclose( $fp );

        $has_more = $paged < $query->max_num_pages;

        wp_send_json_success( array(
            'current_page' => $paged,
            'total_pages'  => max( 1, $query->max_num_pages ),
            'has_more'     => $has_more,
            'file'         => $file_name
        ) );
    }

    public static function ajax_download_export() {
        if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( $_GET['nonce'], 'si_export_nonce' ) ) {
            wp_die( 'Invalid nonce.' );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized.' );
        }

        $file_name = isset( $_GET['file'] ) ? sanitize_file_name( $_GET['file'] ) : '';
        if ( empty( $file_name ) ) {
            wp_die( 'Invalid file.' );
        }

        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/seo-inspector-exports/' . $file_name;

        if ( ! file_exists( $file_path ) ) {
            wp_die( 'File not found.' );
        }

        header( 'Content-Description: File Transfer' );
        header( 'Content-Type: text/csv' );
        header( 'Content-Disposition: attachment; filename="seo-inspector-export.csv"' );
        header( 'Expires: 0' );
        header( 'Cache-Control: must-revalidate' );
        header( 'Pragma: public' );
        header( 'Content-Length: ' . filesize( $file_path ) );
        readfile( $file_path );
        exit;
    }
}
