<?php
/**
 * SEO Inspector IndexNow Class
 * Dynamically pings search engines (Bing, IndexNow) on post publish, update, or deletion.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SI_IndexNow {
    public static function init() {
        // Generate key if missing
        if ( ! get_option( 'si_indexnow_key' ) ) {
            update_option( 'si_indexnow_key', md5( home_url() . time() . wp_rand() ) );
        }

        // Serve verification key at virtual path: /<key>.txt
        add_action( 'parse_request', array( __CLASS__, 'serve_verification_key' ) );

        // Post status hooks
        add_action( 'transition_post_status', array( __CLASS__, 'handle_post_transition' ), 10, 3 );
        add_action( 'before_delete_post', array( __CLASS__, 'handle_post_delete' ) );
    }

    /**
     * Serves the IndexNow text verification key on request.
     */
    public static function serve_verification_key() {
        $key = get_option( 'si_indexnow_key' );
        if ( empty( $key ) ) {
            return;
        }

        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $clean_request = trim( parse_url( $request_uri, PHP_URL_PATH ), '/' );

        if ( $clean_request === $key . '.txt' ) {
            status_header( 200 );
            header( 'Content-Type: text/plain; charset=utf-8' );
            echo esc_html( $key );
            exit;
        }
    }

    /**
     * Dynamic transition post handler.
     */
    public static function handle_post_transition( $new_status, $old_status, $post ) {
        if ( ! in_array( $post->post_type, array( 'post', 'page' ) ) ) {
            return;
        }

        $is_publish = ( $new_status === 'publish' );
        $was_publish = ( $old_status === 'publish' );

        // Trigger submission if newly published or updated while remaining published
        if ( $is_publish ) {
            self::submit_url( get_permalink( $post->ID ) );
        }
    }

    /**
     * Submit url on delete.
     */
    public static function handle_post_delete( $post_id ) {
        $post = get_post( $post_id );
        if ( $post && $post->post_status === 'publish' && in_array( $post->post_type, array( 'post', 'page' ) ) ) {
            self::submit_url( get_permalink( $post_id ) );
        }
    }

    /**
     * Ping IndexNow APIs.
     */
    public static function submit_url( $url ) {
        if ( get_option( 'si_indexnow_enabled', '1' ) !== '1' ) {
            return;
        }

        $key = get_option( 'si_indexnow_key' );
        if ( empty( $key ) ) {
            return;
        }

        $host = parse_url( home_url(), PHP_URL_HOST );
        $payload = array(
            'host'        => $host,
            'key'         => $key,
            'keyLocation' => home_url( '/' . $key . '.txt' ),
            'urlList'     => array( esc_url_raw( $url ) )
        );

        $endpoints = array(
            'https://api.indexnow.org/indexnow',
            'https://www.bing.com/indexnow'
        );

        foreach ( $endpoints as $endpoint ) {
            wp_remote_post( $endpoint, array(
                'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
                'body'    => wp_json_encode( $payload ),
                'timeout' => 8,
                'sslverify' => false
            ) );
        }
    }
}
