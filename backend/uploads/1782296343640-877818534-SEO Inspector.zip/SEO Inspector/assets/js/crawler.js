jQuery(document).ready(function($) {
    let $startBtn = $('#si-start-btn');
    let $downloadBtn = $('#si-download-btn');
    let $progressBar = $('#si-progress-bar');
    let $progressFill = $('.si-progress-fill');
    let $scoreValue = $('#si-score-value');
    let $statusText = $('#si-status-text');
    let $resultsGrid = $('#si-results');
    let $finalFooter = $('#si-final-footer');
    
    let crawlData = [];
    
    // --- NEW: Perform Quick Scan for Tags on Load ---
    performQuickScan();

    $startBtn.on('click', function(e) {
        e.preventDefault();
        $startBtn.prop('disabled', true).text('Crawling...');
        $downloadBtn.hide();
        $progressBar.fadeIn();
        $resultsGrid.empty().hide();
        $finalFooter.hide();
        $progressFill.css('width', '5%');
        crawlData = [];
        
        startCrawling();
    });

    $downloadBtn.on('click', function(e) {
        e.preventDefault();
        downloadReport();
    });

    function performQuickScan() {
        // Prepare the grid for immediate display
        $resultsGrid.empty().show(); 
        
        // Initial render using saved info in si_vars (so the card shows up instantly)
        const initialAudit = renderGlobalAudit([]);
        if (initialAudit.html) {
            $resultsGrid.html(initialAudit.html);
        }

        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_quick_scan',
                _ajax_nonce: si_vars.nonce
            },
            success: function(response) {
                if (response.success && response.data) {
                    // Re-render audit with fresh discoveries from the scanner
                    const auditResult = renderGlobalAudit([response.data]);
                    if (auditResult && auditResult.html) {
                        $resultsGrid.html(auditResult.html); // Replace initial with fresh data
                        
                        // Auto-fill dashboard settings inputs if currently empty
                        if (auditResult.gscFound) {
                            if (!$('#si-global-gsc').val()) $('#si-global-gsc').val(auditResult.gscId);
                        }
                        if (auditResult.gaFound) {
                            if (!$('#si-global-ga').val()) $('#si-global-ga').val(auditResult.gaId);
                        }

                        // --- NEW: Hide Project Settings if tags are already found ---
                        if (auditResult.gscFound && auditResult.gaFound) {
                            $('#si-project-settings-card').fadeOut();
                        }
                    }
                }
            }
        });
    }

    function startCrawling(page = 1, allUrls = []) {
        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_get_urls_to_crawl',
                _ajax_nonce: si_vars.nonce,
                paged: page
            },
            success: function(response) {
                if (response.success) {
                    // Because si_get_urls_to_crawl returns an object with pagination
                    let data = response.data;
                    let currentUrls = data.urls || [];
                    allUrls = allUrls.concat(currentUrls);
                    
                    if (data.has_more) {
                        startCrawling(page + 1, allUrls);
                    } else {
                        crawlPages(allUrls);
                    }
                } else {
                    alert('Error: ' + response.data);
                    resetUI();
                }
            }
        });
    }

    async function crawlPages(urls) {
        let total = urls.length;
        if (total === 0) {
            $statusText.text('No content found to crawl.');
            resetUI();
            return;
        }

        let processed = 0;
        let allResults = [];

        for (let item of urls) {
            try {
                let result = await crawlSinglePage(item.url, item.type);
                allResults.push(result);
                processed++;
                updateProgress(processed, total);
            } catch (error) {
                console.error('Crawl failed for: ' + item.url, error);
                processed++;
                updateProgress(processed, total);
            }
        }

        crawlData = allResults;
        displayFinalResults(allResults);
    }

    function crawlSinglePage(url, type) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: si_vars.ajax_url,
                type: 'POST',
                data: {
                    action: 'si_analyze_url',
                    url: url,
                    type: type,
                    _ajax_nonce: si_vars.nonce
                },
                success: function(response) {
                    if (response.success) resolve(response.data);
                    else reject(response.data);
                },
                error: function(xhr, status, error) {
                    reject(error);
                }
            });
        });
    }

    function updateProgress(processed, total) {
        let percent = (processed / total) * 100;
        $progressFill.css('width', percent + '%');
        $statusText.text(`Analyzing content ${processed} of ${total}...`);
    }

    function displayFinalResults(results) {
        $resultsGrid.show();
        let totalScore = 0;
        
        // Filter results into Pages and Posts
        const pages = results.filter(r => r.type === 'page');
        const posts = results.filter(r => r.type === 'post');

        let html = '';

        // --- Global Site Audit Board ---
        const audit = renderGlobalAudit(results);
        html += audit.html;

        if (pages.length > 0) {
            html += `<div class="si-section-group"><h2 class="si-section-header">Pages</h2><div class="si-results-inner-grid">`;
            pages.forEach(result => {
                totalScore += result.score;
                html += renderResultCard(result);
            });
            html += `</div></div>`;
        }

        if (posts.length > 0) {
            html += `<div class="si-section-group"><h2 class="si-section-header">Posts</h2><div class="si-results-inner-grid">`;
            posts.forEach(result => {
                totalScore += result.score;
                html += renderResultCard(result);
            });
            html += `</div></div>`;
        }

        $resultsGrid.html(html);

        // --- NEW: Sync discovered IDs with Global Settings inputs if empty ---
        if (audit.gscFound && !$('#si-global-gsc').val()) {
            $('#si-global-gsc').val(audit.gscId);
        }
        if (audit.gaFound && !$('#si-global-ga').val()) {
            $('#si-global-ga').val(audit.gaId);
        }

        let avgScore = results.length > 0 ? Math.round(totalScore / results.length) : 0;
        $scoreValue.text(avgScore);
        
        // Update Ring SVG Visuals
        let strokeColor = '#ef4444'; // Red
        if (avgScore >= 80) strokeColor = '#22c55e'; // Green
        else if (avgScore >= 50) strokeColor = '#f59e0b'; // Yellow
        
        $('#si-seo-score-widget-dashboard .si-ring-fill').css({
            'stroke-dasharray': `${avgScore}, 100`,
            'stroke': strokeColor
        });
        $statusText.text('Analysis complete! Check the results below.');
        $startBtn.prop('disabled', false).text('Re-Crawl Site');
        $downloadBtn.show();
        $finalFooter.fadeIn();

        // --- NEW: Reveal Technical Details Card after crawl ---
        $('#si-technical-details-card').fadeIn();

        // --- Store results server-side for XLSX export ---
        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_store_crawl_results',
                results: JSON.stringify(results),
                nonce: si_vars.nonce
            }
        });
    }

    function renderResultCard(result) {
        let issuesHtml = '';
        if (result.issues && result.issues.length > 0) {
            issuesHtml = result.issues.map(issue => {
                let iconClass = 'si-issue-warning';
                if (issue.type === 'success') iconClass = 'si-issue-success';
                if (issue.type === 'critical') iconClass = 'si-issue-critical';
                
                return `
                <li class="si-issue-item ${iconClass}">
                    <span class="si-issue-icon"></span>
                    ${issue.message}
                </li>
                `;
            }).join('');
        } else {
            issuesHtml = `<li class="si-issue-item si-issue-success">No issues found.</li>`;
        }

        return `
            <div class="si-page-card">
                <h4>${result.url} <span style="float:right; font-size: 0.9rem; font-weight: bold; color: ${result.score >= 80 ? '#22c55e' : (result.score >= 50 ? '#f59e0b' : '#ef4444')};">Score: ${result.score}</span></h4>
                <ul class="si-issue-list">
                    ${issuesHtml}
                </ul>
            </div>
        `;
    }

    function renderGlobalAudit(results) {
        let gscFound = false;
        let gaFound = false;
        let gscId = '';
        let gaId = '';
        let gaType = 'Unknown';
        let gscType = 'Meta Tag';

        results.forEach(page => {
            page.issues.forEach(issue => {
                if (issue.message.includes('Google Search Console verified')) {
                    gscFound = true;
                    let match = issue.message.match(/ID: (.*?)\)/);
                    if (match) gscId = match[1];
                }
                if (issue.message.includes('Google Analytics detected')) {
                    gaFound = true;
                    gaType = 'gtag.js (Global Site Tag)';
                    let match = issue.message.match(/\((.*?)\)/);
                    if (match) gaId = match[1];
                }
                if (issue.message.includes('Legacy Google Analytics')) {
                    gaFound = true;
                    gaType = 'analytics.js (Legacy)';
                }
                if (issue.message.includes('Google Tag Manager detected')) {
                    gaFound = true;
                    gaType = 'GTM (Tag Manager)';
                    let match = issue.message.match(/\((.*?)\)/);
                    if (match) gaId = match[1];
                }
            });
        });

        // Check if we've already saved IDs via the plugin
        if (!gscFound && si_vars.gsc_id) { gscFound = true; gscId = si_vars.gsc_id; gscType = 'Internal Settings (Saved)'; }
        if (!gaFound && si_vars.ga_id) { gaFound = true; gaId = si_vars.ga_id; gaType = 'Internal Settings (Saved)'; }

        // --- Always show the card on dashboard if we are in Quick Scan mode or have any tags ---
        // For the purposes of UI consistency, we'll return the card even if empty during Quick Scan
        if (!gscFound && !gaFound && (!results || results.length === 0)) {
            // Check if we are in "Initial Scan" mode (results is empty array)
            if (results.length === 0 && !si_vars.gsc_id && !si_vars.ga_id) {
                 // return empty html to not show empty card before scanner finish
                 return { html: '', gscFound: false, gaFound: false };
            }
        }

        const html = `
            <div class="si-global-audit-card">
                <h2 class="si-section-header">Global Site Audit</h2>
                <div class="si-global-grid">
                    <!-- GSC Section -->
                    <div class="si-global-item ${gscFound ? 'success' : 'warning'}">
                        <div class="si-global-main">
                            <div class="si-global-icon gsc"></div>
                            <div class="si-global-info">
                                <strong>Google Search Console</strong>
                                <span>${gscFound ? 'Connected' : 'Not Detected'}</span>
                                ${!gscFound ? '<a href="#" class="si-add-tag-link" data-type="gsc">+ Add Tag</a>' : ''}
                            </div>
                        </div>
                        ${gscFound ? `
                        <div class="si-technical-summary">
                            <div class="si-summary-row"><strong>Status</strong> <span>Verified</span></div>
                            <div class="si-summary-row"><strong>Method</strong> <span>${gscType}</span></div>
                            <div class="si-summary-row"><strong>Property ID</strong> <code class="si-code-pill">${gscId || 'Loaded'}</code></div>
                        </div>
                        ` : `
                        <div class="si-tag-input-form" id="si-form-gsc" style="display:none;">
                            <input type="text" placeholder="Enter Property ID" id="si-input-gsc">
                            <button class="button si-save-tag-btn" data-type="gsc">Save</button>
                        </div>
                        `}
                    </div>

                    <!-- GA Section -->
                    <div class="si-global-item ${gaFound ? 'success' : 'warning'}">
                        <div class="si-global-main">
                            <div class="si-global-icon ga"></div>
                            <div class="si-global-info">
                                <strong>Google Analytics / GTM</strong>
                                <span>${gaFound ? 'Active' : 'Not Detected'}</span>
                                ${!gaFound ? '<a href="#" class="si-add-tag-link" data-type="ga">+ Add Tag</a>' : ''}
                            </div>
                        </div>
                        ${gaFound ? `
                        <div class="si-technical-summary">
                            <div class="si-summary-row"><strong>Status</strong> <span>Tracking</span></div>
                            <div class="si-summary-row"><strong>Integration</strong> <span>${gaType}</span></div>
                            <div class="si-summary-row"><strong>Tracking ID</strong> <code class="si-code-pill">${gaId || 'Loaded'}</code></div>
                        </div>
                        ` : `
                        <div class="si-tag-input-form" id="si-form-ga" style="display:none;">
                            <input type="text" placeholder="Enter Tracking ID" id="si-input-ga">
                            <button class="button si-save-tag-btn" data-type="ga">Save</button>
                        </div>
                        `}
                    </div>
                </div>
            </div>
        `;
        return { html, gscFound, gaFound, gscId, gaId };
    }

    function downloadReport() {
        if (!crawlData || crawlData.length === 0) {
            alert('No crawl data available. Please run a scan first.');
            return;
        }
        
        let url = si_vars.ajax_url + '?action=si_export_audit_xlsx&nonce=' + si_vars.nonce;
        window.location.href = url;
    }

    function resetUI() {
        $startBtn.prop('disabled', false).text('Start Crawling');
        $progressBar.hide();
    }

    // Add Tag Handlers
    $(document).on('click', '.si-add-tag-link', function(e) {
        e.preventDefault();
        let type = $(this).data('type');
        $(this).hide();
        $(`#si-form-${type}`).fadeIn();
    });

    $(document).on('click', '.si-save-tag-btn', function() {
        let $btn = $(this);
        let type = $btn.data('type');
        let val = $(`#si-input-${type}`).val();

        if (!val) return;

        $btn.prop('disabled', true).text('Saving...');

        let data = {
            action: 'si_save_tags',
            _ajax_nonce: si_vars.nonce
        };
        if (type === 'gsc') data.gsc_id = val;
        else data.ga_id = val;

        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: data,
            success: function(response) {
                if (response.success) {
                    $btn.text('Saved!');
                    setTimeout(() => {
                        $(`#si-form-${type}`).fadeOut(() => {
                            if (type === 'gsc') si_vars.gsc_id = val;
                            else si_vars.ga_id = val;
                            if (crawlData.length > 0) displayFinalResults(crawlData);
                        });
                    }, 1000);
                } else {
                    alert('Error saving tag.');
                    $btn.prop('disabled', false).text('Save');
                }
            }
        });
    });

    // Global Settings Save (Persistent Dashboard Version)
    $('#si-save-global-settings').on('click', function() {
        const $btn = $(this);
        const gscVal = $('#si-global-gsc').val();
        const gaVal = $('#si-global-ga').val();
        const twitterVal = $('#si-global-twitter').val();
        const ogVal = $('#si-global-og-img').val();
        const $msg = $('#si-settings-msg');

        $btn.prop('disabled', true).text('Saving...');
        
        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_save_tags',
                gsc_id: gscVal,
                ga_id: gaVal,
                twitter_id: twitterVal,
                og_image: ogVal,
                _ajax_nonce: si_vars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $btn.prop('disabled', false).text('Save Configurations');
                    $msg.text('Settings saved successfully!').css('color', si_vars.primary_color || '#3ABBA8').fadeIn();
                    si_vars.gsc_id = gscVal;
                    si_vars.ga_id = gaVal;
                    
                    // Do not hide the settings card anymore since it is a global dashboard
                    
                    setTimeout(() => $msg.fadeOut(), 3000);
                } else {
                    alert('Error saving settings.');
                    $btn.prop('disabled', false).text('Save Configurations');
                }
            }
        });
    });

    // Migration Logic
    $('#si-run-migration-btn').on('click', function() {
        const $btn = $(this);
        const plugin = $('#si-migration-plugin').val();
        const $msg = $('#si-migration-msg');

        if (!plugin) {
            alert('Please select a plugin to migrate from.');
            return;
        }

        if (!confirm('Are you sure you want to run the migration? Depending on the size of your site, this may take a few moments.')) return;

        $btn.prop('disabled', true).text('Migrating Data...');
        $msg.hide();

        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_run_migration',
                plugin: plugin,
                _ajax_nonce: si_vars.nonce
            },
            success: function(response) {
                $btn.prop('disabled', false).text('Migrate Settings');
                if (response.success) {
                    $msg.text(response.data).css('color', '#22c55e').fadeIn();
                } else {
                    $msg.text('Error: ' + response.data).css('color', '#ef4444').fadeIn();
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('Migrate Settings');
                $msg.text('An unknown server error occurred.').css('color', '#ef4444').fadeIn();
            }
        });
    });

    // Sitemap Settings logic
    $('#si-save-sitemap-settings').on('click', function() {
        const $btn = $(this);
        const $msg = $('#si-sitemap-msg');
        let selectedPostTypes = [];
        
        $('.si-sitemap-pt-checkbox:checked').each(function() {
            selectedPostTypes.push($(this).val());
        });

        $btn.prop('disabled', true).text('Saving...');
        
        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_save_tags',
                sitemap_post_types: selectedPostTypes,
                _ajax_nonce: si_vars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $btn.prop('disabled', false).text('Save Sitemap Options');
                    $msg.text('Sitemap Configuration Saved!').css('color', si_vars.primary_color || '#3ABBA8').fadeIn();
                    setTimeout(() => $msg.fadeOut(), 3000);
                } else {
                    alert('Error saving sitemap settings.');
                    $btn.prop('disabled', false).text('Save Sitemap Options');
                }
            },
            error: function() {
                alert('An unknown server error occurred.');
                $btn.prop('disabled', false).text('Save Sitemap Options');
            }
        });
    });

    // IndexNow settings logic
    $('#si-save-indexnow-settings').on('click', function() {
        const $btn = $(this);
        const $msg = $('#si-indexnow-msg');
        const enabledVal = $('#si-indexnow-enabled').is(':checked') ? '1' : '0';

        $btn.prop('disabled', true).text('Saving...');
        
        $.ajax({
            url: si_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'si_save_tags',
                indexnow_enabled: enabledVal,
                _ajax_nonce: si_vars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $btn.prop('disabled', false).text('Save IndexNow Options');
                    $msg.text('IndexNow configurations saved!').css('color', '#3ABBA8').fadeIn();
                    setTimeout(() => $msg.fadeOut(), 3000);
                } else {
                    alert('Error saving IndexNow settings.');
                    $btn.prop('disabled', false).text('Save IndexNow Options');
                }
            },
            error: function() {
                alert('Server error.');
                $btn.prop('disabled', false).text('Save IndexNow Options');
            }
        });
    });
});
