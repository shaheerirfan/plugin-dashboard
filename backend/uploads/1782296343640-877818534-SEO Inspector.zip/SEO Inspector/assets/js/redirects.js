jQuery(document).ready(function($) {
    const $searchInput = $('#si-redirect-search');
    const $rows = $('.si-redirect-table-row');
    const $feed = $('.si-redirect-feed-container');
    const $noResults = $('<div class="si-redirect-no-results" style="display:none; text-align:center; padding: 40px; background: #fff; border-radius: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.02); margin-top: 20px;">' +
        '<p style="margin: 0; font-size: 1.1rem; font-weight: 600; color: var(--si-text);">No redirects found matching your search.</p>' +
        '<p style="margin: 5px 0 0; font-size: 0.9rem; color: var(--si-gray);">Try searching for a different URL or path.</p>' +
        '</div>');
    
    $feed.append($noResults);

    $searchInput.on('input', function() {
        const query = $(this).val().toLowerCase();
        let visibleCount = 0;

        $rows.each(function() {
            const source = $(this).find('td').eq(0).text().toLowerCase();
            const target = $(this).find('td').eq(1).text().toLowerCase();

            if (source.includes(query) || target.includes(query)) {
                $(this).show();
                visibleCount++;
            } else {
                $(this).hide();
            }
        });

        if (visibleCount === 0 && query !== '') {
            $noResults.show();
            $('#si-redirect-table').hide();
        } else {
            $noResults.hide();
            $('#si-redirect-table').show();
        }
    });
});
