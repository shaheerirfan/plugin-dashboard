jQuery(document).ready(function($) {
    
    // --- Tabs ---
    $('.si-mb-tab').on('click', function() {
        var target = $(this).data('tab');
        $('.si-mb-tab').removeClass('active');
        $(this).addClass('active');
        $('.si-tab-content').removeClass('active').hide();
        $('#' + target).addClass('active').fadeIn(200);
    });

    // --- Accordions ---
    $('.si-accordion-header').on('click', function() {
        var $this = $(this);
        var $content = $this.next('.si-accordion-content');
        var $icon = $this.find('.dashicons').last();
        
        $this.toggleClass('active');
        $content.slideToggle(200);
        
        if ($this.hasClass('active')) {
            $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
        } else {
            $icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
        }
    });

    // --- Google Preview Toggle ---
    $('.si-device-btn').on('click', function() {
        $('.si-device-btn').removeClass('active');
        $(this).addClass('active');
        if ($(this).data('device') === 'mobile') {
            $('#si-google-preview').addClass('mobile');
        } else {
            $('#si-google-preview').removeClass('mobile');
        }
    });

    // --- Input Binding for Snippet Preview ---
    var $titleInput = $('#si_seo_title');
    var $descInput = $('#si_meta_description');
    
    $titleInput.on('input', updateTitle);
    $descInput.on('input', updateDesc);
    $('#si_post_slug').on('input', function() {
        // Just UI update, actual save handled by PHP
    });

    function updateTitle() {
        var val = $titleInput.val();
        if (!val) val = $titleInput.attr('placeholder') || '';
        $('#si-preview-title').text(val);
        
        // Progress bar
        var len = val.length;
        var max = 60;
        var pct = Math.min((len / max) * 100, 100);
        var $bar = $('#si-title-progress-fill');
        $bar.css('width', pct + '%').removeClass('si-prog-red si-prog-orange si-prog-green');
        
        if (len === 0) {
            $bar.css('width', '0%');
        } else if (len < 30) {
            $bar.addClass('si-prog-orange');
        } else if (len <= 60) {
            $bar.addClass('si-prog-green');
        } else {
            $bar.addClass('si-prog-red');
        }
        runAnalysis();
    }

    function updateDesc() {
        var val = $descInput.val();
        if (!val) {
            $('#si-preview-desc').text('Please provide a meta description by editing the snippet below. If you don’t, Google will try to find a relevant part of your content...');
        } else {
            $('#si-preview-desc').text(val);
        }

        // Progress bar
        var len = val.length;
        var max = 160;
        var pct = Math.min((len / max) * 100, 100);
        var $bar = $('#si-desc-progress-fill');
        $bar.css('width', pct + '%').removeClass('si-prog-red si-prog-orange si-prog-green');
        
        if (len === 0) {
            $bar.css('width', '0%');
        } else if (len < 120) {
            $bar.addClass('si-prog-orange');
        } else if (len <= 160) {
            $bar.addClass('si-prog-green');
        } else {
            $bar.addClass('si-prog-red');
        }
        runAnalysis();
    }

    // --- Keyword Pills ---
    var $kwInput = $('#si_kw_input');
    var $kwHidden = $('#si_focus_keywords');
    var $kwContainer = $('#si-kw-container');
    var activeKeyword = '';
    
    function renderPills() {
        $kwContainer.find('.si-kw-pill').remove();
        var val = $kwHidden.val();
        if (!val) {
            activeKeyword = '';
            return;
        }
        var kws = val.split(',').filter(k => k.trim() !== '');
        
        // Ensure activeKeyword is valid
        if (!activeKeyword || !kws.includes(activeKeyword)) {
            activeKeyword = kws[0] ? kws[0].trim() : '';
        }

        kws.forEach(function(kw) {
            kw = kw.trim();
            var isActive = (kw === activeKeyword);
            var activeClass = isActive ? ' active-pill' : '';
            var activeStyle = isActive ? 'style="background: #3ABBA8 !important; color: #fff !important; border-color: #3ABBA8 !important;"' : '';
            
            var $pill = $('<div class="si-kw-pill' + activeClass + '" ' + activeStyle + '><span style="cursor:pointer;">' + kw + '</span><i class="dashicons dashicons-no-alt" style="margin-left:5px; cursor:pointer;"></i></div>');
            $pill.insertBefore($kwInput);
        });
    }

    // Keyword pill removal
    $kwContainer.on('click', '.dashicons-no-alt', function(e) {
        e.stopPropagation();
        var textToRemove = $(this).siblings('span').text().trim();
        var kws = $kwHidden.val().split(',').map(k => k.trim()).filter(k => k !== '' && k !== textToRemove);
        $kwHidden.val(kws.join(', '));
        
        if (activeKeyword === textToRemove) {
            activeKeyword = kws[0] ? kws[0] : '';
        }
        
        renderPills();
        runAnalysis();
        fetchSuggestions();
    });

    // Toggle active keyword pill
    $kwContainer.on('click', '.si-kw-pill span', function() {
        activeKeyword = $(this).text().trim();
        renderPills();
        runAnalysis();
    });

    $kwInput.on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            var newKw = $(this).val().trim();
            if (newKw) {
                var current = $kwHidden.val() ? $kwHidden.val().split(',').map(k => k.trim()).filter(k => k !== '') : [];
                if (!current.includes(newKw)) {
                    current.push(newKw);
                    $kwHidden.val(current.join(', '));
                    activeKeyword = newKw;
                    renderPills();
                    runAnalysis();
                }
            }
            $(this).val('');
        }
    });

    renderPills();

    // --- AI Generation Handlers ---
    $('.si-ai-generate-btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var type = $btn.data('type');
        var $targetInput = type === 'title' ? $('#si_seo_title') : $('#si_meta_description');
        
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 2s linear infinite;"></span> Generating...');

        $.post(si_meta_box_data.ajaxurl, {
            action: 'si_generate_meta',
            nonce: si_meta_box_data.nonce,
            post_id: si_meta_box_data.post_id,
            type: type
        }, function(response) {
            if (response.success) {
                $targetInput.val(response.data);
                if (type === 'title') updateTitle();
                if (type === 'description') updateDesc();
            } else {
                alert('AI Generation Error: ' + response.data);
            }
        }).fail(function() {
            alert('Server error during AI generation.');
        }).always(function() {
            $btn.prop('disabled', false).html(originalText);
        });
    });

    $('#si-ai-suggestions-btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $results = $('#si-ai-suggestions-results');
        
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 2s linear infinite;"></span> Analyzing...');
        $results.hide();

        $.post(si_meta_box_data.ajaxurl, {
            action: 'si_generate_suggestions',
            nonce: si_meta_box_data.nonce,
            post_id: si_meta_box_data.post_id
        }, function(response) {
            if (response.success) {
                $results.html(response.data.replace(/\n/g, '<br>')).slideDown();
            } else {
                alert('AI Analysis Error: ' + response.data);
            }
        }).fail(function() {
            alert('Server error during AI analysis.');
        }).always(function() {
            $btn.prop('disabled', false).html(originalText);
        });
    });

    // --- Syllable Helper ---
    function countSyllables(word) {
        word = word.toLowerCase().trim();
        if (word.length <= 3) return 1;
        word = word.replace(/(?:es|ed|[^laeiouy]e)$/, '');
        word = word.replace(/^y/, '');
        var matches = word.match(/[aeiouy]{1,2}/g);
        return matches ? matches.length : 1;
    }

    // --- List of Transition Words ---
    var transitionWords = [
        "accordingly", "as a result", "consequently", "for example", "for instance", 
        "however", "therefore", "in addition", "moreover", "meanwhile", "on the other hand", 
        "furthermore", "nevertheless", "first", "second", "third", "finally", "because", 
        "additionally", "similarly", "subsequently", "thereafter", "ultimately", "likewise", 
        "specifically", "indeed", "consequentially", "in contrast", "alternatively"
    ];

    // --- Passive Voice Irregular Verbs ---
    var irregularParticiples = [
        "done", "made", "seen", "said", "found", "built", "run", "bought", "held", 
        "drawn", "sung", "lost", "left", "kept", "written", "taken", "known", "given"
    ];

    // --- Yoast-Style Analysis Engine ---
    function runAnalysis() {
        var title = $titleInput.val() || $titleInput.attr('placeholder') || '';
        var desc = $descInput.val();
        var keywordsRaw = $kwHidden.val();
        var keywords = keywordsRaw ? keywordsRaw.split(',').map(k => k.trim().toLowerCase()).filter(k => k !== '') : [];
        
        var content = '';
        if (wp && wp.data && wp.data.select('core/editor')) {
            content = wp.data.select('core/editor').getEditedPostContent() || '';
        } else if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor) {
            content = tinyMCE.activeEditor.getContent({format: 'text'}) || '';
        } else {
            content = $('#content').val() || '';
        }
        
        var isCornerstone = $('#si_is_cornerstone').is(':checked');
        
        // Strip HTML
        var textContent = content.replace(/<[^>]+>/g, ' ');
        var words = textContent.split(/\s+/).filter(function(w) { return w.trim().length > 0; });
        var wordCount = words.length;

        var seoResults = [];
        var readabilityResults = [];

        // --- 1. SEO ANALYSIS ---
        
        // A. Word Count
        var targetWords = isCornerstone ? 900 : 300;
        if (wordCount >= targetWords) {
            seoResults.push({ score: 3, text: '<strong>Text length:</strong> The text contains ' + wordCount + ' words. Good job!' });
        } else if (wordCount > (targetWords / 2)) {
            seoResults.push({ score: 2, text: '<strong>Text length:</strong> The text contains ' + wordCount + ' words. This is slightly below the recommended minimum of ' + targetWords + ' words.' });
        } else {
            seoResults.push({ score: 1, text: '<strong>Text length:</strong> The text contains ' + wordCount + ' words. This is far below the recommended minimum of ' + targetWords + ' words.' });
        }

        // B. Title length
        if (title.length === 0) {
            seoResults.push({ score: 1, text: '<strong>SEO title width:</strong> Please create an SEO title.' });
        } else if (title.length < 30) {
            seoResults.push({ score: 2, text: '<strong>SEO title width:</strong> The SEO title is too short. Use the space to add keyword variations.' });
        } else if (title.length <= 60) {
            seoResults.push({ score: 3, text: '<strong>SEO title width:</strong> Good job!' });
        } else {
            seoResults.push({ score: 1, text: '<strong>SEO title width:</strong> The SEO title is wider than the viewable limit.' });
        }

        // C. Meta description length
        if (desc.length === 0) {
            seoResults.push({ score: 1, text: '<strong>Meta description length:</strong> No meta description has been specified. Search engines will display copy from the page instead.' });
        } else if (desc.length < 120) {
            seoResults.push({ score: 2, text: '<strong>Meta description length:</strong> The meta description is under 120 characters long. However, up to 160 characters are available.' });
        } else if (desc.length <= 160) {
            seoResults.push({ score: 3, text: '<strong>Meta description length:</strong> Well done!' });
        } else {
            seoResults.push({ score: 1, text: '<strong>Meta description length:</strong> The meta description is over 160 characters.' });
        }

        // D. Focus Keyphrases Checks
        if (keywords.length === 0) {
            seoResults.push({ score: 1, text: '<strong>Focus keyphrase:</strong> No focus keyphrases configured. Add keyphrases to evaluate your SEO score.' });
        } else {
            // Find headings in HTML
            var headingMatches = content.match(/<h[1-6][^>]*>(.*?)<\/h[1-6]>/gi);
            var headingsText = '';
            if (headingMatches) {
                headingsText = headingMatches.map(h => h.replace(/<[^>]+>/g, '').toLowerCase()).join(' ');
            }

            // Find image alt tags in HTML
            var imgMatches = content.match(/<img[^>]+>/gi);
            var altsText = '';
            if (imgMatches) {
                altsText = imgMatches.map(function(img) {
                    var altMatch = img.match(/alt=["\']([^"\']*)["\']/i);
                    return altMatch ? altMatch[1].toLowerCase() : '';
                }).join(' ');
            }

            // Intro text: first 100 words
            var introText = words.slice(0, 100).join(' ').toLowerCase();

            // Analyze each keyword
            keywords.forEach(function(kw) {
                var kwLower = kw.toLowerCase().trim();
                if (!kwLower) return;

                var kwEscaped = kwLower.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');

                // Keyphrase in title
                var inTitle = title.toLowerCase().indexOf(kwLower) !== -1;
                if (inTitle) {
                    seoResults.push({ score: 3, text: '<strong>Keyphrase in title [' + kw + ']:</strong> The focus keyphrase appears in the SEO title.' });
                } else {
                    seoResults.push({ score: 1, text: '<strong>Keyphrase in title [' + kw + ']:</strong> The focus keyphrase does not appear in the SEO title.' });
                }

                // Keyphrase in description
                var inDesc = desc.toLowerCase().indexOf(kwLower) !== -1;
                if (inDesc) {
                    seoResults.push({ score: 3, text: '<strong>Keyphrase in description [' + kw + ']:</strong> The focus keyphrase appears in the meta description.' });
                } else {
                    seoResults.push({ score: 2, text: '<strong>Keyphrase in description [' + kw + ']:</strong> The focus keyphrase is missing from the meta description.' });
                }

                // Keyphrase density
                var kwRegex = new RegExp('\\b' + kwEscaped + '\\b', 'gi');
                var kwMatches = (textContent.toLowerCase().match(kwRegex) || []).length;
                var density = wordCount > 0 ? (kwMatches / wordCount) * 100 : 0;

                if (density >= 0.5 && density <= 2.5) {
                    seoResults.push({ score: 3, text: '<strong>Keyphrase density [' + kw + ']:</strong> Found ' + kwMatches + ' times (' + density.toFixed(1) + '% density). Perfect!' });
                } else if (density > 2.5) {
                    seoResults.push({ score: 1, text: '<strong>Keyphrase density [' + kw + ']:</strong> Over-optimized at ' + density.toFixed(1) + '% density. Keep it below 2.5%.' });
                } else {
                    seoResults.push({ score: 2, text: '<strong>Keyphrase density [' + kw + ']:</strong> Found ' + kwMatches + ' times (' + density.toFixed(1) + '% density). Aim for 0.5% - 2.5%.' });
                }

                // Headings usage
                var inHeadings = headingsText.indexOf(kwLower) !== -1;
                if (inHeadings) {
                    seoResults.push({ score: 3, text: '<strong>Keyphrase in headings [' + kw + ']:</strong> Found in subheadings.' });
                } else {
                    seoResults.push({ score: 2, text: '<strong>Keyphrase in headings [' + kw + ']:</strong> Missing from subheadings.' });
                }

                // Intro paragraph presence
                var inIntro = introText.indexOf(kwLower) !== -1;
                if (inIntro) {
                    seoResults.push({ score: 3, text: '<strong>Keyphrase in introduction [' + kw + ']:</strong> Found in the introduction.' });
                } else {
                    seoResults.push({ score: 2, text: '<strong>Keyphrase in introduction [' + kw + ']:</strong> Missing from the introduction.' });
                }

                // Image ALT usage
                var inAlts = altsText.indexOf(kwLower) !== -1;
                if (inAlts) {
                    seoResults.push({ score: 3, text: '<strong>Keyphrase in image alt [' + kw + ']:</strong> Found in image ALT tags.' });
                } else {
                    seoResults.push({ score: 2, text: '<strong>Keyphrase in image alt [' + kw + ']:</strong> Missing from image ALT tags.' });
                }
            });
        }


        // --- 2. READABILITY ANALYSIS ---
        
        var sentences = textContent.split(/[.!?]+/).filter(function(s) { return s.trim().length > 0; });
        var totalSentencesCount = sentences.length;

        if (totalSentencesCount === 0) {
            readabilityResults.push({ score: 1, text: '<strong>Readability:</strong> Write some content in the editor to calculate readability scores.' });
        } else {
            // A. Sentence Length
            var longSentences = 0;
            var totalSyllables = 0;
            var transitionCount = 0;
            var passiveCount = 0;
            
            var prevSentenceStartWord = '';
            var consecutiveSameStart = 1;
            var hasConsecutiveViolation = false;

            sentences.forEach(function(s, index) {
                s = s.trim();
                var sWords = s.split(/\s+/).filter(w => w.length > 0);
                var sWordCount = sWords.length;
                
                if (sWordCount > 20) {
                    longSentences++;
                }

                // Count syllables and transition words
                var hasTransition = false;
                var sLower = s.toLowerCase();
                transitionWords.forEach(function(tw) {
                    if (sLower.indexOf(tw) !== -1) {
                        hasTransition = true;
                    }
                });
                if (hasTransition) transitionCount++;

                // Syllables sum
                sWords.forEach(function(w) {
                    totalSyllables += countSyllables(w);
                });

                // Passive Voice Check
                var hasPassive = false;
                var passivePattern = /\b(is|am|are|was|were|be|been|being)\b\s+([a-zA-Z]+ed|[a-zA-Z]+en|[a-zA-Z]+t)\b/i;
                if (passivePattern.test(sLower)) {
                    hasPassive = true;
                } else {
                    // Check irregular past participles
                    irregularParticiples.forEach(function(ip) {
                        var ipPattern = new RegExp('\\b(is|am|are|was|were|be|been|being)\\b\\s+\\b' + ip + '\\b', 'i');
                        if (ipPattern.test(sLower)) {
                            hasPassive = true;
                        }
                    });
                }
                if (hasPassive) passiveCount++;

                // Consecutive Sentence Start Check
                if (sWords.length > 0) {
                    var startWord = sWords[0].toLowerCase().replace(/[^a-zA-Z]/g, '');
                    if (startWord === prevSentenceStartWord && startWord.length > 0) {
                        consecutiveSameStart++;
                        if (consecutiveSameStart >= 3) {
                            hasConsecutiveViolation = true;
                        }
                    } else {
                        consecutiveSameStart = 1;
                    }
                    prevSentenceStartWord = startWord;
                }
            });

            // A. Sentence Length score
            var pctLong = (longSentences / totalSentencesCount) * 100;
            if (pctLong > 25) {
                readabilityResults.push({ score: 1, text: '<strong>Sentence length:</strong> ' + pctLong.toFixed(1) + '% of sentences contain more than 20 words, which is above the recommended maximum of 25%.' });
            } else {
                readabilityResults.push({ score: 3, text: '<strong>Sentence length:</strong> ' + pctLong.toFixed(1) + '% of sentences contain more than 20 words, which is within the recommended limits.' });
            }

            // B. Transition Words score
            var pctTransitions = (transitionCount / totalSentencesCount) * 100;
            if (pctTransitions >= 30) {
                readabilityResults.push({ score: 3, text: '<strong>Transition words:</strong> ' + pctTransitions.toFixed(1) + '% of the sentences contain transition words, which is great!' });
            } else {
                readabilityResults.push({ score: 2, text: '<strong>Transition words:</strong> Only ' + pctTransitions.toFixed(1) + '% of the sentences contain transition words. Try using more transitions.' });
            }

            // C. Flesch Reading Ease score
            var asl = wordCount / totalSentencesCount;
            var asw = wordCount > 0 ? (totalSyllables / wordCount) : 0;
            var fleschScore = 206.835 - (1.015 * asl) - (84.6 * asw);
            fleschScore = Math.max(0, Math.min(100, fleschScore));
            
            var difficultyLabel = '';
            if (fleschScore >= 80) difficultyLabel = 'Very Easy';
            else if (fleschScore >= 70) difficultyLabel = 'Easy';
            else if (fleschScore >= 60) difficultyLabel = 'Standard';
            else if (fleschScore >= 50) difficultyLabel = 'Fairly Difficult';
            else difficultyLabel = 'Difficult / Very Difficult';

            if (fleschScore >= 60) {
                readabilityResults.push({ score: 3, text: '<strong>Flesch Reading Ease:</strong> The copy scores ' + fleschScore.toFixed(1) + ' (<strong>' + difficultyLabel + '</strong>). Easy to read.' });
            } else if (fleschScore >= 50) {
                readabilityResults.push({ score: 2, text: '<strong>Flesch Reading Ease:</strong> The copy scores ' + fleschScore.toFixed(1) + ' (<strong>' + difficultyLabel + '</strong>). Try to shorten sentences.' });
            } else {
                readabilityResults.push({ score: 1, text: '<strong>Flesch Reading Ease:</strong> The copy scores ' + fleschScore.toFixed(1) + ' (<strong>' + difficultyLabel + '</strong>). Rewrite using simpler terms.' });
            }

            // D. Passive Voice score
            var pctPassive = (passiveCount / totalSentencesCount) * 100;
            if (pctPassive <= 10) {
                readabilityResults.push({ score: 3, text: '<strong>Passive voice:</strong> Only ' + pctPassive.toFixed(1) + '% of sentences use passive voice. This is excellent.' });
            } else {
                readabilityResults.push({ score: 2, text: '<strong>Passive voice:</strong> ' + pctPassive.toFixed(1) + '% of sentences use passive voice. Try to use more active verbs.' });
            }

            // E. Consecutive Sentences Check
            if (hasConsecutiveViolation) {
                readabilityResults.push({ score: 1, text: '<strong>Consecutive sentences:</strong> You are starting multiple consecutive sentences with the same word. Mix up your sentence structures.' });
            } else {
                readabilityResults.push({ score: 3, text: '<strong>Consecutive sentences:</strong> Sentence starts are well varied.' });
            }

            // F. Paragraph Length Check (New Yoast Premium parity checker)
            var pBlocks = content.split(/<\/p>|\n\s*\n/gi).filter(p => p.replace(/<[^>]+>/g, '').trim().length > 0);
            var longParagraphs = 0;
            pBlocks.forEach(function(pText) {
                var cleanP = pText.replace(/<[^>]+>/g, ' ');
                var pWordsCount = cleanP.split(/\s+/).filter(w => w.trim().length > 0).length;
                if (pWordsCount > 150) {
                    longParagraphs++;
                }
            });
            if (longParagraphs > 0) {
                readabilityResults.push({ score: 2, text: '<strong>Paragraph length:</strong> ' + longParagraphs + ' paragraphs exceed the recommended maximum of 150 words. Break them up.' });
            } else {
                readabilityResults.push({ score: 3, text: '<strong>Paragraph length:</strong> Paragraph lengths are well optimized.' });
            }
        }

        // Sort results: 1 (Red) top, 2 (Orange) middle, 3 (Green) bottom
        seoResults.sort((a, b) => a.score - b.score);
        readabilityResults.sort((a, b) => a.score - b.score);

        // Render SEO
        var $seoList = $('#si-seo-analysis-list').empty();
        var seoScoreTotal = 0;
        seoResults.forEach(function(res) {
            var colorClass = res.score === 1 ? 'si-light-red' : (res.score === 2 ? 'si-light-orange' : 'si-light-green');
            seoScoreTotal += res.score;
            $seoList.append('<li><span class="si-traffic-light ' + colorClass + '"></span> <span>' + res.text + '</span></li>');
        });
        
        // Calculate overall SEO traffic light
        var overallSeoLight = 'si-light-gray';
        if (seoResults.length > 0) {
            var avgSeo = seoScoreTotal / seoResults.length;
            if (avgSeo >= 2.5) overallSeoLight = 'si-light-green';
            else if (avgSeo >= 1.8) overallSeoLight = 'si-light-orange';
            else overallSeoLight = 'si-light-red';
        }
        $('#si-overall-seo-light, #si-seo-analysis-light').removeClass('si-light-red si-light-orange si-light-green si-light-gray').addClass(overallSeoLight);

        // Render Readability
        var $readList = $('#si-readability-analysis-list').empty();
        var readScoreTotal = 0;
        readabilityResults.forEach(function(res) {
            var colorClass = res.score === 1 ? 'si-light-red' : (res.score === 2 ? 'si-light-orange' : 'si-light-green');
            readScoreTotal += res.score;
            $readList.append('<li><span class="si-traffic-light ' + colorClass + '"></span> <span>' + res.text + '</span></li>');
        });

        // Calculate overall Readability traffic light
        var overallReadLight = 'si-light-gray';
        if (readabilityResults.length > 0) {
            var avgRead = readScoreTotal / readabilityResults.length;
            if (avgRead >= 2.5) overallReadLight = 'si-light-green';
            else if (avgRead >= 1.8) overallReadLight = 'si-light-orange';
            else overallReadLight = 'si-light-red';
        }
        $('#si-overall-readability-light, #si-readability-analysis-light').removeClass('si-light-red si-light-orange si-light-green si-light-gray').addClass(overallReadLight);
        updateSocialPreviews();
    }

    // Initial triggers
    setTimeout(function() {
        updateTitle();
        updateDesc();
        fetchSuggestions();
    }, 1000);

    // AI Suggestions (Phase 5 functionality preserved)
    function fetchSuggestions() {
        var $container = $('#si-link-suggestions-container');
        var kws = $kwHidden.val();
        var title = $titleInput.val() || document.title;
        
        if (!kws && title === document.title) return;

        $.post(si_meta_box_data.ajaxurl, {
            action: 'si_get_link_suggestions',
            nonce: si_meta_box_data.nonce,
            post_id: si_meta_box_data.post_id,
            keywords: kws,
            title: title
        }, function(response) {
            if (response.success && response.data.length > 0) {
                var html = '';
                response.data.forEach(function(post) {
                    var relevance = post.relevance_score ? post.relevance_score : 'High';
                    html += '<div style="background:#fff; border:1px solid #cbd5e1; border-radius:8px; padding:12px 15px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">';
                    html += '<div><strong style="display:block; color:#0f172a;">' + post.title + '</strong><span style="font-size:0.8rem; color:#64748b;">Relevance: ' + relevance + '</span></div>';
                    html += '<button type="button" class="button si-copy-link-btn" data-url="' + post.url + '"><span class="dashicons dashicons-admin-links"></span> Copy Link</button>';
                    html += '</div>';
                });
                $container.html(html);
                
                $('.si-copy-link-btn').on('click', function(e) {
                    e.preventDefault();
                    var url = $(this).data('url');
                    var $btn = $(this);
                    navigator.clipboard.writeText(url).then(function() {
                        var originalHtml = $btn.html();
                        $btn.html('<span class="dashicons dashicons-saved"></span> Copied!').css({'background':'#3ABBA8', 'color':'#fff', 'border-color':'#3ABBA8'});
                        setTimeout(function() { $btn.html(originalHtml).css({'background':'', 'color':'', 'border-color':''}); }, 2000);
                    });
                });
            } else {
                $container.html('<div style="padding: 15px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; text-align: center; color: #64748b;">No relevant internal links found yet. Add more content!</div>');
            }
        });
    }

    // --- Social Preview Updates ---
    var $fbTitleInput = $('#si_fb_title');
    var $fbDescInput = $('#si_fb_desc');
    var $fbImageInput = $('#si_fb_image');
    
    var $twTitleInput = $('#si_tw_title');
    var $twDescInput = $('#si_tw_desc');
    var $twImageInput = $('#si_tw_image');

    $fbTitleInput.on('input', updateSocialPreviews);
    $fbDescInput.on('input', updateSocialPreviews);
    $fbImageInput.on('change input', updateSocialPreviews);

    $twTitleInput.on('input', updateSocialPreviews);
    $twDescInput.on('input', updateSocialPreviews);
    $twImageInput.on('change input', updateSocialPreviews);

    function updateSocialPreviews() {
        var defaultTitle = $titleInput.val() || $titleInput.attr('placeholder') || 'Post Title';
        var defaultDesc = $descInput.val() || 'Post description fallback text...';
        
        var featuredImgUrl = '';
        if ($('.editor-post-featured-image__preview img').length) {
            featuredImgUrl = $('.editor-post-featured-image__preview img').attr('src');
        }

        // Facebook Updates
        var fbTitle = $fbTitleInput.val() || defaultTitle;
        var fbDesc = $fbDescInput.val() || defaultDesc;
        var fbImg = $fbImageInput.val() || featuredImgUrl;

        $('#si-fb-preview-title-tag').text(fbTitle);
        $('#si-fb-preview-desc-tag').text(fbDesc);
        if (fbImg) {
            $('#si-fb-preview-img-tag').attr('src', fbImg).show();
            $('#si-fb-preview-img-placeholder').hide();
        } else {
            $('#si-fb-preview-img-tag').hide();
            $('#si-fb-preview-img-placeholder').show();
        }

        // Twitter Updates
        var twTitle = $twTitleInput.val() || defaultTitle;
        var twDesc = $twDescInput.val() || defaultDesc;
        var twImg = $twImageInput.val() || featuredImgUrl;

        $('#si-tw-preview-title-tag').text(twTitle);
        $('#si-tw-preview-desc-tag').text(twDesc);
        if (twImg) {
            $('#si-tw-preview-img-tag').attr('src', twImg).show();
            $('#si-tw-preview-img-placeholder').hide();
        } else {
            $('#si-tw-preview-img-tag').hide();
            $('#si-tw-preview-img-placeholder').show();
        }
    }

    // --- Media Uploader Integration ---
    $('.si-media-upload-btn').on('click', function(e) {
        e.preventDefault();
        var targetId = $(this).data('target');
        var $input = $('#' + targetId);
        
        var custom_uploader = wp.media({
            title: 'Select Image',
            button: { text: 'Use Image' },
            multiple: false
        }).on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $input.val(attachment.url).trigger('change');
        }).open();
    });

    // --- AI Generator Buttons ---
    $('.si-ai-generate-btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var type = $btn.data('type');
        var originalText = $btn.html();
        
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 2s linear infinite;"></span> Generating...');
        
        $.post(si_meta_box_data.ajaxurl, {
            action: 'si_ai_generate',
            nonce: si_meta_box_data.nonce,
            post_id: si_meta_box_data.post_id,
            type: type
        }, function(response) {
            $btn.prop('disabled', false).html(originalText);
            if (response.success && response.data) {
                if (type === 'title') {
                    $titleInput.val(response.data).trigger('input');
                } else if (type === 'description') {
                    $descInput.val(response.data).trigger('input');
                }
            } else {
                alert('AI generation failed: ' + (response.data || 'unknown error'));
            }
        });
    });

    $('#si-ai-suggestions-btn').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var originalText = $btn.html();
        var $resultBox = $('#si-ai-suggestions-results');
        
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation: spin 2s linear infinite;"></span> Generating...');
        $resultBox.hide();

        $.post(si_meta_box_data.ajaxurl, {
            action: 'si_ai_generate',
            nonce: si_meta_box_data.nonce,
            post_id: si_meta_box_data.post_id,
            type: 'suggestions'
        }, function(response) {
            $btn.prop('disabled', false).html(originalText);
            if (response.success && response.data) {
                var formatted = response.data.replace(/\n/g, '<br>');
                $resultBox.html(formatted).slideDown();
            } else {
                $resultBox.html('<p style="color:#c53030;">AI suggestions failed to generate. Please verify settings.</p>').slideDown();
            }
        });
    });

});
