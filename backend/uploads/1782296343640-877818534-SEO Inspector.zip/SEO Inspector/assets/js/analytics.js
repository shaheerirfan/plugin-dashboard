jQuery(document).ready(function($) {
    const ctx = document.getElementById('si-performance-chart');
    if (ctx) {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
                datasets: [{
                    label: 'Clicks',
                    data: [1200, 1900, 3000, 5000, 2000, 3000, 4500],
                    borderColor: '#3ABBA8',
                    backgroundColor: 'rgba(58, 187, 168, 0.1)',
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Impressions',
                    data: [8000, 12000, 15000, 25000, 18000, 22000, 30000],
                    borderColor: '#0D64CB',
                    backgroundColor: 'rgba(13, 100, 203, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
});
