<?php
/**
 * Plugin Name: SEO Inspector
 * Description: A powerful SEO crawler that analyzes your site and provides scoring and improvement suggestions.
 * Version: 1.0.0
 * Text Domain: seo-inspector
 */

if ( ! defined( 'ABSOLUTE_PATH' ) ) {
    define( 'ABSOLUTE_PATH', plugin_dir_path( __FILE__ ) );
}

// Load Dependencies
require_once ABSOLUTE_PATH . 'includes/class-meta-box.php';
require_once ABSOLUTE_PATH . 'includes/class-sitemap.php';
require_once ABSOLUTE_PATH . 'includes/class-redirects.php';
require_once ABSOLUTE_PATH . 'includes/class-file-editor.php';
require_once ABSOLUTE_PATH . 'includes/class-analytics-dashboard.php';
require_once ABSOLUTE_PATH . 'includes/class-schema-generator.php';
require_once ABSOLUTE_PATH . 'includes/class-migration.php';
require_once ABSOLUTE_PATH . 'includes/class-link-counter.php';
require_once ABSOLUTE_PATH . 'includes/class-link-suggestions.php';
require_once ABSOLUTE_PATH . 'includes/class-search-appearance.php';
require_once ABSOLUTE_PATH . 'includes/class-crawl-optimization.php';
require_once ABSOLUTE_PATH . 'includes/class-seo-workouts.php';
require_once ABSOLUTE_PATH . 'includes/class-import-export.php';
require_once ABSOLUTE_PATH . 'includes/class-indexnow.php';
require_once ABSOLUTE_PATH . 'includes/class-web-vitals.php';
require_once ABSOLUTE_PATH . 'includes/class-ai-helpers.php';
require_once ABSOLUTE_PATH . 'includes/class-bulk-export.php';
require_once ABSOLUTE_PATH . 'includes/class-zapier-webhooks.php';
require_once ABSOLUTE_PATH . 'includes/class-broken-link-scanner.php';
require_once ABSOLUTE_PATH . 'includes/class-cannibalization.php';
require_once ABSOLUTE_PATH . 'includes/class-content-gap.php';
require_once ABSOLUTE_PATH . 'includes/class-xlsx-builder.php';
require_once ABSOLUTE_PATH . 'includes/class-xlsx-export.php';

SI_Meta_Box::init();
SI_Sitemap::init();
SI_Redirects::init();
SI_File_Editor::init();
SI_Analytics_Dashboard::init();
SI_Schema_Generator::init();
SI_Migration::init();
SI_Link_Counter::init();
SI_Link_Suggestions::init();
SI_Search_Appearance::init();
SI_Crawl_Optimization::init();
SI_SEO_Workouts::init();
SI_Import_Export::init();
SI_IndexNow::init();
SI_Web_Vitals::init();
SI_Bulk_Export::init();
SI_Zapier_Webhooks::init();
SI_Broken_Link_Scanner::init();
SI_Cannibalization::init();
SI_Content_Gap::init();
SI_XLSX_Export::init();

// Flush rewrite rules on activation for sitemap
register_activation_hook( __FILE__, array( 'SI_Sitemap', 'flush_rules' ) );

// Register Admin Menu
add_action( 'admin_menu', 'si_register_admin_menu' );
function si_register_admin_menu() {
    add_menu_page(
        'SEO Inspector',
        'SEO Inspector',
        'manage_options',
        'seo-inspector',
        'si_render_admin_dashboard',
        'dashicons-rest-api',
        30
    );

    // Submenus - Centralized here to ensure stable parent/child relationship
    add_submenu_page(
        'seo-inspector',
        'Dashboard',
        'Dashboard',
        'manage_options',
        'seo-inspector',
        'si_render_admin_dashboard'
    );

    add_submenu_page(
        'seo-inspector',
        'Search Appearance',
        'Search Appearance',
        'manage_options',
        'si-search-appearance',
        array( 'SI_Search_Appearance', 'render_settings_page' )
    );

    add_submenu_page(
        'seo-inspector',
        'Redirects',
        'Redirects',
        'manage_options',
        'si-redirects',
        array( 'SI_Redirects', 'render_redirect_page' )
    );

    add_submenu_page(
        'seo-inspector',
        'File Editor',
        'File Editor',
        'manage_options',
        'si-file-editor',
        array( 'SI_File_Editor', 'render_editor_page' )
    );

    add_submenu_page(
        'seo-inspector',
        'Analytics',
        'Analytics',
        'manage_options',
        'si-analytics',
        array( 'SI_Analytics_Dashboard', 'render_analytics_page' )
    );

    add_submenu_page(
        'seo-inspector',
        'Crawl Optimization',
        'Crawl Optimization',
        'manage_options',
        'si-crawl-optimization',
        array( 'SI_Crawl_Optimization', 'render_page' )
    );

    add_submenu_page(
        'seo-inspector',
        'SEO Workouts',
        'SEO Workouts',
        'manage_options',
        'si-seo-workouts',
        array( 'SI_SEO_Workouts', 'render_page' )
    );

    add_submenu_page(
        'seo-inspector',
        'Import / Export',
        'Import / Export',
        'manage_options',
        'si-import-export',
        array( 'SI_Import_Export', 'render_page' )
    );
}

// Add Action Links (Settings) under Plugin Name
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'si_add_action_links' );
function si_add_action_links( $links ) {
    $settings_link = '<a href="admin.php?page=seo-inspector">' . __( 'Settings', 'seo-inspector' ) . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}

// Render Dashboard
function si_render_admin_dashboard() {
    ?>
    <div id="si-dashboard">
        <header class="si-header left" style="margin-bottom: 40px; border-bottom: none; padding-bottom: 0;">
            <h1 style="font-size: 3.5rem; line-height: 1.1; margin-bottom: 10px;">SEO Inspector</h1>
            <p style="font-size: 1.1rem; color: #64748b;">Analyze your site's SEO performance and get actionable improvement suggestions.</p>
        </header>

        <main class="si-content">
            <!-- Start / Status Card -->
            <div id="si-main-action-card" class="si-main-card left">
                <div class="si-status-section" style="display: flex; align-items: center; gap: 40px; text-align: left;">
                    <div id="si-seo-score-widget-dashboard" class="si-score-ring" data-score="0">
                        <svg viewBox="0 0 36 36">
                            <path class="si-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            <path class="si-ring-fill" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" style="stroke: #e2e8f0;" />
                        </svg>
                        <div id="si-score-value" class="si-score-text">0</div>
                    </div>
                    <div class="si-description" style="flex: 1;">
                        <h2 style="margin: 0 0 10px 0; font-size: 2rem; font-family: 'Outfit', sans-serif;">Site Audit Status</h2>
                        <p id="si-status-text" style="font-size: 1.1rem; margin: 0;">Your site hasn't been analyzed yet. Launch the crawl to identify SEO gaps and improve your search rankings.</p>
                    </div>
                </div>

                <div class="si-actions" style="margin-top: 30px;">
                    <button id="si-start-btn" type="button" class="button button-primary">Launch Website Crawl</button>
                    <div id="si-progress-bar" class="si-progress-bar" style="display:none; margin: 20px 0 0 0; max-width: 100%;">
                        <div class="si-progress-fill"></div>
                    </div>
                </div>

                <!-- Professional Outreach (Integrated into Card) -->
                <div id="si-final-footer" class="si-contact-section" style="display:none; text-align: left;">
                    <hr class="si-divider" style="margin: 30px 0;">
                    <h3>Technical SEO Mastery</h3>
                    <p style="margin: 0 0 25px 0;">These results show key SEO insights. Want to dominate search rankings? Contact us for advanced SEO optimization</p>
                    
                    <div class="si-footer-actions" style="justify-content: flex-start; margin: 0;">
                        <button id="si-download-btn" type="button" class="button button-primary">Download Report</button>
                    </div>
                </div>
            </div>

            <!-- Analysis Results Grid -->
            <div id="si-results" class="si-results-grid" style="display:none;">
                <!-- Result cards will be dynamically injected here -->
            </div>

            <!-- Global Settings (Persistent) -->
            <div id="si-settings-section" class="si-settings-grid">
                <!-- Project Settings Card -->
                <div id="si-project-settings-card" class="si-settings-card">
                    <h3>Global Settings</h3>
                    <p>Configure default SEO identifiers mapped globally across your WordPress installation.</p>
                    <div class="si-mb-field">
                        <label>Google Search Console ID</label>
                        <input type="text" id="si-global-gsc" value="<?php echo esc_attr( get_option( 'si_gsc_id' ) ); ?>" placeholder="e.g. your-verification-code">
                    </div>
                    <div class="si-mb-field">
                        <label>Google Analytics ID</label>
                        <input type="text" id="si-global-ga" value="<?php echo esc_attr( get_option( 'si_ga_id' ) ); ?>" placeholder="e.g. G-XXXXXXXXXX">
                    </div>
                    <div class="si-mb-field">
                        <label>Global Twitter Handle</label>
                        <input type="text" id="si-global-twitter" value="<?php echo esc_attr( get_option( 'si_twitter_id' ) ); ?>" placeholder="e.g. @YourTwitterHandle">
                    </div>
                    <div class="si-mb-field">
                        <label>Default Open Graph Fallback Image URL</label>
                        <input type="url" id="si-global-og-img" value="<?php echo esc_url( get_option( 'si_og_image' ) ); ?>" placeholder="https://example.com/default-logo.png">
                    </div>
                    <button type="button" id="si-save-global-settings" class="button button-primary si-save-tag-btn">Save Configurations</button>
                    <span id="si-settings-msg" style="margin-left: 10px; font-size: 0.85rem; display: none;"></span>
                </div>

                <!-- Sitemap Settings Card -->
                <div id="si-sitemap-settings-card" class="si-settings-card">
                    <h3>Sitemap Configuration</h3>
                    <p>Select which post types should be dynamically indexed in your XML sitemap.</p>
                    <div style="margin: 15px 0;">
                        <?php
                        $public_post_types = get_post_types( array( 'public' => true ), 'objects' );
                        $saved_post_types  = get_option( 'si_sitemap_post_types', array( 'post', 'page' ) );
                        if ( ! is_array( $saved_post_types ) ) {
                            $saved_post_types = array();
                        }
                        
                        foreach ( $public_post_types as $pt_name => $pt_obj ) {
                            // Exclude attachments
                            if ( $pt_name === 'attachment' ) {
                                continue;
                            }
                            $checked = in_array( $pt_name, $saved_post_types ) ? 'checked' : '';
                            echo '<label style="display: block; margin-bottom: 8px;">';
                            echo '<input type="checkbox" class="si-sitemap-pt-checkbox" value="' . esc_attr( $pt_name ) . '" ' . $checked . ' /> ';
                            echo esc_html( $pt_obj->labels->name );
                            echo '</label>';
                        }
                        ?>
                    </div>
                    <button type="button" id="si-save-sitemap-settings" class="button button-primary">Save Sitemap Options</button>
                    <span id="si-sitemap-msg" style="margin-left: 10px; font-size: 0.85rem; display: none;"></span>
                </div>

                <!-- Migration Tool Card -->
                <div id="si-migration-tool-card" class="si-settings-card">
                    <h3>Data Migration</h3>
                    <p>Select a competitor plugin to import existing SEO titles, descriptions, and settings. We will cleanly map them to SEO Inspector without overwriting existing data.</p>
                    <div style="display: flex; gap: 15px; margin-top: 15px; align-items: center; flex-wrap: wrap;">
                        <div class="si-mb-field" style="margin: 0; min-width: 250px;">
                            <select id="si-migration-plugin" style="width: 100%; height: 40px; border-radius: 8px; border: 1px solid #cbd5e1; padding: 0 10px; background: #fff;">
                                <option value="" disabled selected>-- Select Origin Plugin --</option>
                                <option value="auto">Auto-Detect (Any Plugin)</option>
                                <option value="yoast">Yoast SEO</option>
                                <option value="rankmath">Rank Math</option>
                            </select>
                        </div>
                        <button type="button" id="si-run-migration-btn" class="button button-primary" style="height: 40px; padding: 0 20px; border-radius: 8px; background: var(--si-secondary) !important; border: none !important; font-weight: 600;">Migrate Settings</button>
                    </div>
                    <span id="si-migration-msg" style="display: block; margin-top: 10px; font-size: 0.85rem; font-weight: 600; display: none;"></span>
                </div>

                <!-- IndexNow Settings Card -->
                <div id="si-indexnow-settings-card" class="si-settings-card">
                    <h3>IndexNow Integration</h3>
                    <p>Submit newly published or modified content to search engines automatically.</p>
                    <div style="margin: 15px 0;">
                        <label style="display: block; margin-bottom: 12px; font-weight: 600;">
                            <input type="checkbox" id="si-indexnow-enabled" <?php checked( get_option( 'si_indexnow_enabled', '1' ), '1' ); ?> /> Enable IndexNow Auto-Pings
                        </label>
                        <div class="si-mb-field" style="margin-bottom: 10px;">
                            <label style="display: block; font-weight: 600;">Verification Key</label>
                            <input type="text" id="si-indexnow-key" value="<?php echo esc_attr( get_option( 'si_indexnow_key' ) ); ?>" readonly style="background: #f1f5f9; border-color: #cbd5e1; cursor: not-allowed; width: 100%;">
                        </div>
                        <span style="font-size: 0.85rem; color: var(--si-gray);">
                            Verification Endpoint: <a href="<?php echo esc_url( home_url( '/' . get_option( 'si_indexnow_key' ) . '.txt' ) ); ?>" target="_blank">View Key File</a>
                        </span>
                    </div>
                    <button type="button" id="si-save-indexnow-settings" class="button button-primary">Save IndexNow Options</button>
                    <span id="si-indexnow-msg" style="margin-left: 10px; font-size: 0.85rem; display: none;"></span>
                </div>

                <!-- Technical Details Card (Hidden initially) -->
                <div id="si-technical-details-card" class="si-settings-card" style="display: none;">
                    <h3>Technical Details</h3>
                    <ul style="list-style: none; margin: 0; padding: 0; font-size: 0.9rem; color: var(--si-gray);">
                        <li style="margin-bottom: 10px;"><strong>Sitemap:</strong> <a href="<?php echo esc_url( home_url( '/sitemap_index.xml' ) ); ?>" target="_blank">View Sitemap</a></li>
                        <li style="margin-bottom: 10px;"><strong>Robots:</strong> <a href="<?php echo esc_url( home_url( '/robots.txt' ) ); ?>" target="_blank">View robots.txt</a></li>
                    </ul>
                </div>
            </div>
        </main>
    </div>
    <?php
}

// Enqueue Scripts and Styles
add_action( 'admin_enqueue_scripts', 'si_enqueue_admin_assets' );
function si_enqueue_admin_assets( $hook ) {
    if ( strpos( $hook, 'seo-inspector' ) === false ) {
        return;
    }

    wp_enqueue_style( 'si-admin-styles', plugins_url( 'assets/css/styles.css', __FILE__ ), array(), time() );
    wp_enqueue_script( 'si-admin-js', plugins_url( 'assets/js/crawler.js', __FILE__ ), array( 'jquery' ), time(), true );

    wp_localize_script( 'si-admin-js', 'si_vars', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'si_nonce' ),
        'gsc_id'   => get_option( 'si_gsc_id', '' ),
        'ga_id'    => get_option( 'si_ga_id', '' ),
    ) );
}

// AJAX Handler: Get URLs to crawl
add_action( 'wp_ajax_si_get_urls_to_crawl', 'si_get_urls_to_crawl' );
function si_get_urls_to_crawl() {
    check_ajax_referer( 'si_nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    $paged = isset( $_POST['paged'] ) ? max( 1, intval( $_POST['paged'] ) ) : 1;
    $posts_per_page = 100;

    $args = array(
        'post_type'      => array( 'post', 'page' ), // Including posts (blogs) and pages
        'post_status'    => 'publish',
        'posts_per_page' => $posts_per_page,
        'paged'          => $paged,
        'fields'         => 'ids',
    );

    $query = new WP_Query( $args );
    $urls = array();

    if ( $query->have_posts() ) {
        foreach ( $query->posts as $post_id ) {
            $urls[] = array(
                'url'  => get_permalink( $post_id ),
                'type' => get_post_type( $post_id )
            );
        }
    }

    $response = array(
        'urls'        => $urls,
        'total_pages' => $query->max_num_pages,
        'current_page'=> $paged,
        'has_more'    => $paged < $query->max_num_pages
    );

    wp_send_json_success( $response );
}

// AJAX Handler: Analyze Single URL
add_action( 'wp_ajax_si_analyze_url', 'si_analyze_url' );
function si_analyze_url() {
    check_ajax_referer( 'si_nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    $url = esc_url_raw( $_POST['url'] );
    if ( ! $url ) {
        wp_send_json_error( 'Invalid URL' );
    }

    require_once ABSOLUTE_PATH . 'includes/class-seo-analyzer.php';
    $analyzer = new SI_SEO_Analyzer( $url );
    $results = $analyzer->analyze();
    $results['type'] = isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : 'page';

    wp_send_json_success( $results );
}

// AJAX Handler: Save Tags
add_action( 'wp_ajax_si_save_tags', 'si_save_tags' );
function si_save_tags() {
    check_ajax_referer( 'si_nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    if ( isset( $_POST['gsc_id'] ) ) {
        update_option( 'si_gsc_id', sanitize_text_field( $_POST['gsc_id'] ) );
    }
    if ( isset( $_POST['ga_id'] ) ) {
        update_option( 'si_ga_id', sanitize_text_field( $_POST['ga_id'] ) );
    }
    if ( isset( $_POST['twitter_id'] ) ) {
        update_option( 'si_twitter_id', sanitize_text_field( $_POST['twitter_id'] ) );
    }
    if ( isset( $_POST['og_image'] ) ) {
        update_option( 'si_og_image', esc_url_raw( $_POST['og_image'] ) );
    }
    if ( isset( $_POST['sitemap_post_types'] ) ) {
        $post_types = array_map( 'sanitize_text_field', (array) $_POST['sitemap_post_types'] );
        update_option( 'si_sitemap_post_types', $post_types );
    }
    if ( isset( $_POST['indexnow_enabled'] ) ) {
        update_option( 'si_indexnow_enabled', sanitize_text_field( $_POST['indexnow_enabled'] ) );
    }

    wp_send_json_success( 'Global Configurations Saved' );
}

// AJAX Handler: Quick Scan (Homepage only)
add_action( 'wp_ajax_si_quick_scan', 'si_quick_scan' );
function si_quick_scan() {
    check_ajax_referer( 'si_nonce', '_ajax_nonce' );
    
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    $homepage = home_url( '/' );
    if ( ! class_exists( 'SI_SEO_Analyzer' ) ) {
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-seo-analyzer.php';
    }

    $analyzer = new SI_SEO_Analyzer( $homepage );
    $results  = $analyzer->analyze();
    
    wp_send_json_success( $results );
}

// AJAX Handler: AI Generate Meta
add_action( 'wp_ajax_si_generate_meta', 'si_generate_meta' );
function si_generate_meta() {
    check_ajax_referer( 'si_meta_box_nonce', 'nonce' );
    if ( ! current_user_can( 'edit_posts' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    $post_id = intval( $_POST['post_id'] );
    $type = sanitize_text_field( $_POST['type'] );

    require_once ABSOLUTE_PATH . 'includes/class-ai-helpers.php';
    $result = SI_AI_Manager::generate_meta( $post_id, $type );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}

// AJAX Handler: AI SEO Suggestions
add_action( 'wp_ajax_si_generate_suggestions', 'si_generate_suggestions' );
function si_generate_suggestions() {
    check_ajax_referer( 'si_meta_box_nonce', 'nonce' );
    if ( ! current_user_can( 'edit_posts' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    $post_id = intval( $_POST['post_id'] );
    require_once ABSOLUTE_PATH . 'includes/class-ai-helpers.php';
    
    // Call generic generate function requesting suggestions
    $result = SI_AI_Manager::generate_meta( $post_id, 'seo_suggestions' );
    
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}

// Inject Tags into Front-end
add_action( 'wp_head', 'si_inject_tags', 1 );
add_filter( 'pre_get_document_title', 'si_filter_document_title', 20 );
add_filter( 'the_content', 'si_auto_image_seo', 20 );

function si_filter_document_title( $title ) {
    return SI_Search_Appearance::filter_document_title( $title );
}

function si_auto_image_seo( $content ) {
    if ( is_singular() && in_the_loop() && is_main_query() ) {
        $post_id = get_the_ID();
        $focus_keyword = get_post_meta( $post_id, '_si_focus_keywords', true );
        
        // Use first keyword or fallback to post title
        $keywords = explode(',', $focus_keyword);
        $injection_text = ! empty( trim($keywords[0]) ) ? trim($keywords[0]) : get_the_title();
        
        if ( empty( $injection_text ) ) return $content;

        // Simple Regex to find images without alt tags and inject them
        $content = preg_replace_callback('/<img([^>]*?)>/i', function($matches) use ($injection_text) {
            $img_tag = $matches[0];
            
            // If it already has an alt tag, leave it alone
            if ( preg_match('/alt=[\'"](.*?)[\'"]/i', $img_tag, $alt_match) ) {
                if ( ! empty( trim($alt_match[1]) ) ) {
                    return $img_tag; 
                }
            }

            // Inject the alt attribute
            if ( strpos($img_tag, 'alt=') === false ) {
                return str_replace('<img', '<img alt="' . esc_attr($injection_text) . '"', $img_tag);
            } else {
                return preg_replace('/alt=[\'"][\'"]/i', 'alt="' . esc_attr($injection_text) . '"', $img_tag);
            }
        }, $content);
    }
    return $content;
}

function si_inject_tags() {
    // 1. Google Integration Tags
    $gsc_id = get_option( 'si_gsc_id' );
    $ga_id  = get_option( 'si_ga_id' );
    
    if ( $gsc_id ) {
        echo '<meta name="google-site-verification" content="' . esc_attr( $gsc_id ) . '" />' . "\n";
    }
    if ( $ga_id ) {
        echo "<!-- Google Analytics -->\n";
        echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . esc_attr( $ga_id ) . '"></script>' . "\n";
        echo "<script>\n";
        echo "  window.dataLayer = window.dataLayer || [];\n";
        echo "  function gtag(){dataLayer.push(arguments);}\n";
        echo "  gtag('js', new Date());\n";
        echo "  gtag('config', '" . esc_js( $ga_id ) . "');\n";
        echo "</script>\n";
    }

    // 2. Global Social & SEO Settings
    $global_twitter = get_option( 'si_twitter_id' );
    $global_og_img  = get_option( 'si_og_image' );

    // Base Meta Defaults
    $current_url = esc_url( home_url( $_SERVER['REQUEST_URI'] ?? '/' ) );
    $meta_desc   = SI_Search_Appearance::get_meta_description();
    $robots_tags = array();
    
    $og_type     = 'website';
    $og_title    = SI_Search_Appearance::filter_document_title( get_bloginfo( 'name' ) );
    $og_desc     = $meta_desc;
    $og_url      = $current_url;
    $og_image    = $global_og_img;
    
    $tw_title    = $og_title;
    $tw_desc     = $og_desc;

    // Handle Global Robots Visibility
    if ( is_singular() ) {
        $post_id = get_the_ID();
        $post_type = get_post_type( $post_id );
        if ( get_option( "si_{$post_type}_meta_robots_noindex" ) === '1' ) {
            $robots_tags[] = 'noindex';
        }
    } elseif ( is_category() || is_tag() || is_tax() ) {
        $term = get_queried_object();
        if ( $term && get_option( "si_tax_{$term->taxonomy}_meta_robots_noindex" ) === '1' ) {
            $robots_tags[] = 'noindex';
        }
    }

    // Post-Specific Overrides
    if ( is_singular() ) {
        $post_id    = get_the_ID();
        $seo_title  = get_post_meta( $post_id, '_si_seo_title', true ) ?: get_the_title();
        $seo_title  = SI_Search_Appearance::resolve_tokens( $seo_title, $post_id );
        $post_desc  = get_post_meta( $post_id, '_si_meta_description', true );
        $canonical  = get_post_meta( $post_id, '_si_canonical_url', true );
        
        $post_robots_index = get_post_meta( $post_id, '_si_robots_index', true );
        $post_robots_follow = get_post_meta( $post_id, '_si_robots_follow', true );
        $robots_adv = get_post_meta( $post_id, '_si_robots_advanced', true ) ?: array();
        
        if ( $post_robots_index === 'noindex' ) {
            if ( ! in_array( 'noindex', $robots_tags ) ) {
                $robots_tags[] = 'noindex';
            }
        } elseif ( $post_robots_index === 'index' ) {
            // Remove 'noindex' if it was added globally
            $robots_tags = array_diff( $robots_tags, array( 'noindex' ) );
            $robots_tags[] = 'index';
        }
        
        if ( $post_robots_follow === 'nofollow' ) {
            $robots_tags[] = 'nofollow';
        }
        foreach ( $robots_adv as $adv ) {
            $robots_tags[] = $adv;
        }

        // OG / Twitter overrides
        $og_type   = 'article';
        $og_title  = get_post_meta( $post_id, '_si_fb_title', true ) ?: $seo_title;
        $og_desc   = get_post_meta( $post_id, '_si_fb_desc', true ) ?: $meta_desc;
        $og_url    = $canonical ?: get_permalink();
        
        $post_thumb = get_the_post_thumbnail_url( $post_id, 'full' );
        if ( $post_thumb ) {
            $og_image = $post_thumb;
        }

        $tw_title  = get_post_meta( $post_id, '_si_tw_title', true ) ?: $seo_title;
        $tw_desc   = get_post_meta( $post_id, '_si_tw_desc', true ) ?: $meta_desc;
    }

    // --- Output SEO Tags ---
    
    if ( $meta_desc ) {
        echo '<meta name="description" content="' . esc_attr( $meta_desc ) . '" />' . "\n";
    }

    if ( ! empty( $robots_tags ) ) {
        echo '<meta name="robots" content="' . esc_attr( implode( ', ', $robots_tags ) ) . '" />' . "\n";
    }

    // Canonical
    if ( is_singular() && ! empty( $canonical ) ) {
        echo '<link rel="canonical" href="' . esc_url( $canonical ) . '" />' . "\n";
    } else {
        echo '<link rel="canonical" href="' . esc_url( $current_url ) . '" />' . "\n";
    }

    // Open Graph
    echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '" />' . "\n";
    echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
    echo '<meta property="og:url" content="' . esc_url( $og_url ) . '" />' . "\n";
    if ( $og_desc ) {
        echo '<meta property="og:description" content="' . esc_attr( $og_desc ) . '" />' . "\n";
    }
    if ( $og_image ) {
        echo '<meta property="og:image" content="' . esc_url( $og_image ) . '" />' . "\n";
    }

    // Twitter Card
    echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
    if ( $global_twitter ) {
        echo '<meta name="twitter:site" content="' . esc_attr( $global_twitter ) . '" />' . "\n";
        echo '<meta name="twitter:creator" content="' . esc_attr( $global_twitter ) . '" />' . "\n";
    }
    echo '<meta name="twitter:title" content="' . esc_attr( $tw_title ) . '" />' . "\n";
    if ( $tw_desc ) {
        echo '<meta name="twitter:description" content="' . esc_attr( $tw_desc ) . '" />' . "\n";
    }
    if ( $og_image ) {
        echo '<meta name="twitter:image" content="' . esc_url( $og_image ) . '" />' . "\n";
    }

    // Custom Schema
    if ( is_singular() ) {
        $custom_schema = get_post_meta( get_the_ID(), '_si_custom_schema', true );
        if ( ! empty( $custom_schema ) ) {
            echo "<!-- SEO Inspector Custom JSON-LD -->\n";
            echo '<script type="application/ld+json" class="si-custom-schema-output">' . $custom_schema . '</script>' . "\n";
        }
    } else {
        // Global basic Schema for homepage check
        echo "<!-- SEO Inspector Global JSON-LD -->\n";
        echo '<script type="application/ld+json">' . json_encode([
            "@context" => "https://schema.org",
            "@type" => "WebSite",
            "name" => get_bloginfo('name'),
            "url" => esc_url(home_url('/'))
        ]) . '</script>' . "\n";
    }
}
